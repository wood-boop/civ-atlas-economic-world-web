# Software Inc 本地源码参考

本目录用于本地研究 Software Inc **Beta 1.8.12** 的 C# 参考资料。浏览器采用按功能规格独立实现的JavaScript模块。

导入时由使用者显式提供来源目录。本地 `source/` 保留两个程序集的相对目录，仅处理 `.cs` 文件。

这些文件是供阅读和定位的反编译参考，**不是可编译的 Unity 工程**。它们不参与浏览器模拟加载或站点部署。原件、完整文件清单、逐文件哈希及本机来源位置均仅保留在本地，`source/` 和 `manifest.json` 已加入 Git 忽略。发布仓库只包含通用导入器和本说明；导入行为不意味着原实现获得开源许可。

在项目根目录重新导入：

```powershell
node scripts/import-software-inc-reference.mjs '<source-directory>'
```

在另一台机器指定含两个程序集目录的来源根目录：

```powershell
node scripts/import-software-inc-reference.mjs '<directory-containing-both-assemblies>'
```

导入器只读取原件，只复制上述两个目录中的 `.cs`；新建文件使用排他写入，并比较复制后的 SHA-256。已有目标内容相同则保留，字节不同时停止，不覆盖或删除任何原件、目标。导入器拒绝符号链接/目录联接，不清理历史目标；中断时可能留下已复制的同字节文件，重跑可以继续。

独立 JavaScript 实现位于 `public/economic-world/reuse/`，与这些本地参考文件分开；接入与整合范围见 `docs/ECONOMIC_MIGRATION.md`。
