/** Bounded native-history benchmark; run with node --import tsx. */
import { createHash } from 'node:crypto';
import { mkdirSync, writeFileSync } from 'node:fs';
import { cpus } from 'node:os';
import { dirname, resolve } from 'node:path';
import { performance } from 'node:perf_hooks';
import { DEFAULT_PARAMS, generateWorld } from '../src/gen/world';
import { continueCiv, generateCiv, type Civ } from '../src/gen/civ';
import { packValue, unpackValue } from '../src/gen/snapshot';
import { populationAt } from '../src/gen/civ/growth';
import { ECONOMY_GOODS, ECONOMY_SECTORS } from '../src/gen/civ/economy';

const args = process.argv.slice(2);
const option = (key: string, fallback: string) => {
  const at = args.indexOf(`--${key}`);
  return at >= 0 ? args[at + 1] ?? fallback : fallback;
};
const output = resolve(option('output', 'docs/performance/native-economy-benchmark.json'));
const scenario = { seeds: [7, 2024], cells: 3000, endYear: 400, continuationCut: 237.5 };

// Polity lifecycle fields can be inserted in a different order by continuation.
// Keep every numerical value and typed-array byte while sorting plain keys.
function canonical(value: unknown): unknown {
  if (!value || typeof value !== 'object') return value;
  if (ArrayBuffer.isView(value)) return value;
  if (Array.isArray(value)) return value.map(canonical);
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonical((value as Record<string, unknown>)[key])]));
}
function historyBytes(civ: Civ): Uint8Array {
  return packValue(canonical({
    endYear: civ.endYear,
    development: civ.development,
    settlements: civ.settlements,
    polities: civ.polities,
    annals: civ.annals,
    culture: civ.culture,
    polity: civ.polity,
  }));
}
const hash = (bytes: Uint8Array) => createHash('sha256').update(bytes).digest('hex');
const sum = (numbers: ArrayLike<number>) => Array.from(numbers).reduce((a, b) => a + b, 0);
const goodsTotals = (numbers: ArrayLike<number>, labels: readonly string[] = ECONOMY_GOODS) => Object.fromEntries(labels.map((name, g) => {
  let total = 0;
  for (let i = g; i < numbers.length; i += ECONOMY_GOODS.length) total += numbers[i];
  return [name, total];
}));
const runs = [];
for (const seed of scenario.seeds) {
  const terrainStart = performance.now();
  const w = generateWorld({ ...DEFAULT_PARAMS, cells: scenario.cells, seed });
  const worldGenerationMs = performance.now() - terrainStart;

  const wholeStart = performance.now();
  const whole = generateCiv(w, { endYear: scenario.endYear });
  const uninterruptedMs = performance.now() - wholeStart;
  const economy = whole.development?.economy;
  if (!economy) throw new Error('Native Development.economy was not installed');

  const prefixStart = performance.now();
  const prefix = generateCiv(w, { endYear: scenario.continuationCut });
  const prefixMs = performance.now() - prefixStart;
  const packed = packValue(prefix);
  const saved = unpackValue(packed) as Civ;
  const resumeStart = performance.now();
  const resumed = continueCiv(w, saved, { endYear: scenario.endYear });
  const continuationMs = performance.now() - resumeStart;

  // Serialization and hashing are excluded from the simulation timers.
  const wholeBytes = historyBytes(whole);
  const resumedBytes = historyBytes(resumed);
  const uninterruptedHash = hash(wholeBytes);
  const continuationHash = hash(resumedBytes);
  const inputUnchanged = hash(packValue(saved)) === hash(packed);
  const rural = whole.development?.rural?.at(-1) ?? [];
  const urban = whole.settlements.reduce((n, city) => n + populationAt(city, whole.endYear), 0);
  const snapshot = economy.result.snapshot;
  const population = sum(snapshot.population);
  runs.push({
    seed,
    nativeRegions: whole.regions.count,
    nativeCities: whole.settlements.length,
    nativePolities: whole.polities.length,
    nativeWarDeclarations: whole.annals.filter((annal) => annal.kind === 'war').length,
    nativeFiscalStressEvents: whole.annals.filter((annal) => annal.kind === 'fiscal').length,
    nativeRuralPopulationThousands: sum(rural),
    nativeUrbanPopulationThousands: urban,
    finalEconomicNativeYear: economy.state.year,
    retainedEconomicSnapshots: economy.history.length,
    populationWeightedFoodAdequacy: population > 0 ? snapshot.population.reduce((n, pop, r) => n + pop * snapshot.foodAdequacy[r], 0) / population : 1,
    sampledFoodHistory: economy.history.map((sample) => {
      const inhabitants = sum(sample.population);
      return { year: sample.year, nativePopulationThousands: inhabitants,
        populationWeightedFoodAdequacy: inhabitants > 0 ? sample.population.reduce((n, pop, r) => n + pop * sample.foodAdequacy[r], 0) / inhabitants : 1,
        annualFoodOutput: goodsTotals(sample.output)[ECONOMY_GOODS[0]] };
    }),
    annualOutputByGood: goodsTotals(snapshot.output),
    annualProductionLaborThousands: sum(snapshot.labor),
    annualConstructionLaborThousands: sum(snapshot.investmentLabor),
    currentInventoryByGood: goodsTotals(snapshot.inventory),
    currentCapitalBySector: goodsTotals(snapshot.capital, ECONOMY_SECTORS),
    annualDeliveredTradeByGood: goodsTotals(snapshot.imports),
    annualTransportLossByGood: goodsTotals(snapshot.transportLoss),
    nativeTreasuryTotal: sum(whole.development?.state?.tables?.data['国库'] ?? []),
    annualEconomicUpdatesExpected: scenario.endYear + 1,
    worldGenerationMs,
    uninterruptedMs,
    prefixMs,
    continuationMs,
    splitSimulationMs: prefixMs + continuationMs,
    serializedHistoryBytes: wholeBytes.byteLength,
    serializedEconomyBytes: packValue(economy).byteLength,
    uninterruptedHash,
    continuationHash,
    exactReplay: uninterruptedHash === continuationHash,
    continuationInputUnchanged: inputUnchanged,
  });
}
const report = {
  date: new Date().toISOString(),
  scope: 'Native Civ Atlas population, settlements, polities, annual economy and fiscal history',
  comparison: 'Uninterrupted and serialized continuation runs use the same native map, seed and 400-year history.',
  timing: 'Terrain generation, save packing and hashing are excluded from simulation timers. Final native history assembly is included.',
  hashing: 'SHA-256 of every selected native field, with plain object keys sorted and typed-array bytes retained; no rounding or omitted economic fields.',
  node: process.version,
  cpu: cpus()[0]?.model,
  scenario,
  runs,
  exactReplay: runs.every((run) => run.exactReplay && run.continuationInputUnchanged),
};
mkdirSync(dirname(output), { recursive: true });
writeFileSync(output, `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({ output, exactReplay: report.exactReplay, runs: runs.map(({ seed, nativeRegions, uninterruptedMs, splitSimulationMs }) => ({ seed, nativeRegions, uninterruptedMs, splitSimulationMs })) }));
if (!report.exactReplay) process.exitCode = 1;
