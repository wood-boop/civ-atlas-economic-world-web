// Publish corresponding source for a clean, committed release. Does not change game rules.
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
const root = resolve(import.meta.dirname, '..');
const git = (...args) => execFileSync('git', ['-c', 'safe.directory=' + root.replaceAll('\\', '/'), ...args], { cwd: root, encoding: 'utf8', windowsHide: true });
if (git('status', '--porcelain').trim()) throw new Error('Commit the release source before packaging.');
const commit = git('rev-parse', 'HEAD').trim();
const tree = git('rev-parse', 'HEAD^{tree}').trim();
const out = resolve(root, 'public/source');
mkdirSync(out, { recursive: true });
// README promotional screenshots are not required to build or run the application.
const filename = 'civ-atlas-v46-source.zip';
git('archive', '--format=zip', '--output=' + resolve(out, filename), 'HEAD', '--', '.', ':(exclude).github/readme');
const bytes = readFileSync(resolve(out, filename));
if (bytes.length >= 25 * 1024 * 1024) throw new Error('Source archive exceeds the single static-asset budget.');
writeFileSync(resolve(out, 'release.json'), JSON.stringify({
  generatorVersion: 46, version: '1.3.0-economy.3', sourceCommit: commit, sourceTree: tree,
  economicBaseCommit: '9a29fe6a26313304ec95e919752e9ca0f0a81fa8',
  filename, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'),
  excluded: ['.github/readme promotional screenshots'],
  license: 'AGPL-3.0-only'
}, null, 2) + '\n');
console.log(JSON.stringify({ commit, tree, filename, bytes: bytes.length }));
