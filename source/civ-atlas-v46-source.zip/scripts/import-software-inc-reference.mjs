import { createHash } from 'node:crypto';
import { lstat, mkdir, readFile, readdir, realpath, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Local reference import only. Never execute or change any file in the source tree.
const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const referenceRoot = path.join(repoRoot, 'reference', 'software-inc');
const destinationRoot = path.join(referenceRoot, 'source');
const assemblies = ['Assembly-CSharp', 'Assembly-CSharp-firstpass'];
const sha256 = buffer => createHash('sha256').update(buffer).digest('hex');

async function statIfPresent(filePath) {
  try { return await lstat(filePath); }
  catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}

function inside(parent, child) {
  const relative = path.relative(parent, child);
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}

// Check each target path component before creating directories; reject junctions/symlinks.
async function ensureTargetDirectory(directory) {
  if (!inside(repoRoot, directory)) throw new Error(`Target escapes repository: ${directory}`);
  let current = repoRoot;
  const rootStat = await lstat(current);
  if (rootStat.isSymbolicLink() || !rootStat.isDirectory()) throw new Error(`Unsafe repository root: ${current}`);
  for (const segment of path.relative(repoRoot, directory).split(path.sep).filter(Boolean)) {
    current = path.join(current, segment);
    const stat = await statIfPresent(current);
    if (stat && (stat.isSymbolicLink() || !stat.isDirectory())) throw new Error(`Unsafe target directory: ${current}`);
    if (!stat) await mkdir(current);
  }
}

async function collectCSharp(directory, relativeDirectory, files) {
  const directoryStat = await lstat(directory);
  if (directoryStat.isSymbolicLink() || !directoryStat.isDirectory()) throw new Error(`Unsafe source directory: ${directory}`);
  const entries = await readdir(directory, { withFileTypes: true });
  entries.sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0);
  for (const entry of entries) {
    const sourcePath = path.join(directory, entry.name);
    const relativePath = `${relativeDirectory}/${entry.name}`;
    if (entry.isSymbolicLink()) throw new Error(`Source symlinks are not imported: ${sourcePath}`);
    if (entry.isDirectory()) await collectCSharp(sourcePath, relativePath, files);
    else if (entry.isFile() && /\.cs$/i.test(entry.name)) files.push({ sourcePath, relativePath });
  }
}

async function main() {
  if (process.argv.length > 3) throw new Error('Usage: node scripts/import-software-inc-reference.mjs [decompiled-directory]');
  if (!process.argv[2]) throw new Error('Usage: node scripts/import-software-inc-reference.mjs <source-directory>');
  const sourceRoot = await realpath(path.resolve(process.argv[2]));
  if (inside(sourceRoot, destinationRoot) || inside(destinationRoot, sourceRoot)) {
    throw new Error('Source and destination directories must not overlap.');
  }

  const selectedFiles = [];
  for (const assembly of assemblies) await collectCSharp(path.join(sourceRoot, assembly), assembly, selectedFiles);
  if (selectedFiles.length === 0) throw new Error('No C# source files found in the two expected assemblies.');
  selectedFiles.sort((a, b) => a.relativePath < b.relativePath ? -1 : a.relativePath > b.relativePath ? 1 : 0);
  await ensureTargetDirectory(destinationRoot);

  const files = [];
  let copiedCount = 0;
  for (const { sourcePath, relativePath } of selectedFiles) {
    const destinationPath = path.resolve(destinationRoot, ...relativePath.split('/'));
    if (!inside(destinationRoot, destinationPath)) throw new Error(`Invalid relative path: ${relativePath}`);
    await ensureTargetDirectory(path.dirname(destinationPath));
    const sourceStat = await lstat(sourcePath);
    if (sourceStat.isSymbolicLink() || !sourceStat.isFile()) throw new Error(`Unsafe source file: ${sourcePath}`);
    const buffer = await readFile(sourcePath);
    const sourceHash = sha256(buffer);
    const existing = await statIfPresent(destinationPath);
    if (existing && (existing.isSymbolicLink() || !existing.isFile())) throw new Error(`Unsafe target file: ${destinationPath}`);
    if (existing) {
      const existingBuffer = await readFile(destinationPath);
      if (!existingBuffer.equals(buffer)) throw new Error(`Refusing to overwrite different bytes: ${destinationPath}`);
    } else {
      await writeFile(destinationPath, buffer, { flag: 'wx' });
      const copiedBuffer = await readFile(destinationPath);
      if (sha256(copiedBuffer) !== sourceHash) throw new Error(`Copy hash mismatch: ${relativePath}`);
      copiedCount += 1;
    }
    files.push({ relativePath, bytes: buffer.length, sha256: sourceHash });
  }

  const manifest = {
    schema: 'software-inc-local-reference/1',
    sourceRoot,
    game: 'Software Inc',
    gameVersion: 'Beta 1.8.12',
    versionEvidence: 'Source research reports/reuse-economy-review.md; not independently detected from game binaries.',
    importedAt: new Date().toISOString(),
    assemblies,
    scope: 'Only .cs files from the two named assemblies; local decompiled reference, not a buildable Unity project.',
    fileCount: files.length,
    totalBytes: files.reduce((sum, file) => sum + file.bytes, 0),
    files,
  };
  const manifestPath = path.join(referenceRoot, 'manifest.json');
  const manifestStat = await statIfPresent(manifestPath);
  if (manifestStat && (manifestStat.isSymbolicLink() || !manifestStat.isFile())) throw new Error(`Unsafe manifest target: ${manifestPath}`);
  await writeFile(manifestPath, `${JSON.stringify(manifest)}\n`);
  console.log(JSON.stringify({ fileCount: manifest.fileCount, totalBytes: manifest.totalBytes, copiedCount, existingIdenticalCount: files.length - copiedCount, destinationRoot, manifestPath }));
}

main().catch(error => { console.error(error.message); process.exitCode = 1; });
