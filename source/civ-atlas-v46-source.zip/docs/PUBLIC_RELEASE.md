# v46 公开发布

本次发布对应已完成的 v46 自运行原生经济。后续五阶段的账户、产权与市场架构仅为规划，未作为新经济功能上线。

- 主要站点：https://wood-boop.github.io/civ-atlas-economic-world-web/
- 示例入口：https://wood-boop.github.io/civ-atlas-economic-world-web/?seed=7&cells=3000&play=0&gen=46
- 对应源码：https://wood-boop.github.io/civ-atlas-economic-world-web/source/
- 公开静态发布仓库：https://github.com/wood-boop/civ-atlas-economic-world-web
- 原 Sites 站点：https://civ-atlas-economic-world.fairvine1.chatgpt.site （仍为 public；部分访客报告域名前置安全防护拦截）
- Sites 项目标识：见 [托管配置](../.openai/hosting.json)。
- 经济功能基线：生成器 46，应用 1.3.0-economy.3；GitHub 原经济实现提交 9a29fe6a26313304ec95e919752e9ca0f0a81fa8。

本轮程序改动仅为公开发布所需的源码入口和打包脚本；经济规则与人口、地图、时钟保持 v46。GitHub 仓库访问权限独立于网站的公开访问权限；网站提供无需 GitHub 登录即可获取的对应源代码。两份来源仓库与其原部署保持原状。

## 构建与源码提供

2026-11-01 增加独立 GitHub Pages 入口。原因是原 Sites 链接虽已设为 public、且多次匿名请求成功，另一设备仍遇到安全服务拦截。不能从成功样本推断所有网络都可访问。新入口不使用 ChatGPT 身份服务或邀请名单，主要程序、Worker、字体与对应源码由同一 GitHub Pages 站点提供；源码链接改为相对路径，以支持子目录和不同托管域名。未改经济算法。

GitHub Pages 发布步骤：完成下面的源码归档与 Vite 构建后，将 dist 的静态文件放入公开发布仓库根目录，添加 .nojekyll 并保留 LICENSE、源码包及 release.json；以 main 分支根目录作为 Pages 来源，等待 GitHub 构建成功，再用无登录请求和浏览器检查地图、Worker 与源码。预压缩的 .gz/.br 副本可以省略，实际 JS/CSS/字体文件必须保留。来源仓库保持原访问范围。

1. 将计划和发布元数据提交到本仓库，确保工作区干净。
2. 运行 TypeScript 检查以及与本次发布变化相关的验证。
3. 执行 `node scripts/package-public-source.mjs`，从当前 Git 提交生成源码 ZIP 与 `public/source/release.json`。ZIP 包含全部构建所需源码和运行素材，仅省略 README 营销截图以满足静态文件大小预算。
4. 执行 `node node_modules/vite/bin/vite.js build`。其生成的源码链接、源码包和校验信息一同进入 `dist`。
5. 将该构建的 `dist` 与相同 Sites 身份配置放入独立静态发布检出，保存构建来源和文件摘要。Sites 的源仓库存储这份不可变静态发布快照；使用 Sites source helper 提交、推送、打包并发布。
6. 以 Sites 返回的版本、部署状态及 `access_mode=public` 为准记录结果，并检查匿名 HTTP、静态资源、源码下载和浏览器地图。

源码 ZIP 与校验 JSON 是构建产物，不重复纳入 Git。源码包内的程序可独立重建。静态快照与开发源仓库是同一程序的发布产物和源码，不运行另一套经济系统。

## 可用功能与边界

公开网页提供地图生成、文明与经济推演、原生国家/地区/城市详情、时间轴和本地存档。经济统计是地区聚合模型，人口数不是独立人物对象数；财政仍为千石等值预算，完整家庭货币账户尚未实现。

此静态部署不包含上游账号服务器、云同步或官方 AI 后端。部署成功不代表这些外部服务已配置。后续更新应保持用户可见的功能边界清楚。
