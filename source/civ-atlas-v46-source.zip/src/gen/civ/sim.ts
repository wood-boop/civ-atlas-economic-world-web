/**
 * 文明推演引擎(民族扩张;战争、分裂、合并等也在这上面加事件):
 *
 * - **事件堆**:按时间排序(复用 util.ts 的 MinHeap)。每个事件是 {时间, 类型, 对象 a, 对象 b, 版本号}。
 *   时间精度 1/256 年;"时间 + 同一刻里的次序"拼成一个整数当优先级,保证确定性:同一时刻最先处理地形大事,
 *   再处理航海时代、发展度、政局的数表、看王朝、新君即位、迁都后重看边地(按国家号,见 earlyOrder),再处理别的事件(按预约先后),最后处理民族、国家的到达
 *   (按"民族先、国家后,再按州号、民族 / 国家号"排,见 arrivalOrder)。头尾这两类和预约先后无关 —— 接着推时它们是
 *   按日志重新预约 / 重放的,预约先后和一口气推完时不一样,同一刻撞上了也要按同样的次序处理。
 *   中间那一类(看邻国、看内政、下一仗、建城、立国……)接着推时由各层补上,补的时候说明一口气推时它是哪一刻预约的
 *   (schedule 的 booked),fromCiv 按预约的时刻排好先后再放进事件堆:同一刻撞上的几件,先后和一口气推完一样。
 * - **州的版本号**:州的归属(任何一层)一变就 +1。事件预约时记下州 a 的版本号,弹出时对不上就是过期了,
 *   直接丢掉 —— 不用去堆里找、删事件。哪些类型要核对版本号,见 EVENT_INFO。
 * - **唯一改归属的入口** setOwner(层, 州, 新值, 原因):写变化日志、版本号 +1、通知这一层的监听者
 *   (民族层的监听者负责"预约邻州的到达",见 cultures.ts)。
 * - **变化日志**:只记"哪一年、哪个州、哪一层、新值、原因"。回放 = 翻日志(timeline.ts 的 ownersAt)。
 * - **史事**(阶段 3):record(种类, …) 记"发生了什么事"(立国、升格、宣战、攻占、灭亡……),编年史只读它。
 *   各字段的含义见 types.ts 的 AnnalKind。
 * - **检查点**:每 100 年存一份各州的归属,时间轴一下跳到很远时不用从头翻。
 * - **不保存事件堆**:CivSim.fromCiv(world, civ) 由 Civ 数据本身重建"接下来该发生什么",从 civ.endYear 接着推。
 *   进行中的战争、厌战、停战冷却也一样(由史事 + 日志 + 国家表重建,见 wars.ts 的 resumeWars);
 *   分裂、合并、复国、主动迁都的冷却同样(见 politics.ts 的 resumePolitics);王朝更替也一样(dynasty.ts 的 resumeDynasty);
 *   同化与迁徙同样(见 assimilation.ts 的 resumeAssimilation);
 *   城市兴衰(毁城后的重建、旧都衰落)也一样(cities.ts 的 resumeCities)。
 *   发展度是例外:各州能力的全精度状态存在 Civ.development.state 里,接着推时从那里接上(development.ts 的 resumeDevelopment);
 *   政局的数表也存在那里(state.tables,control.ts 的 resumeControl);议事定下的规矩由史事重建(council.ts 的 resumeCouncil)。
 *   阶段 4 的干预不存进事件堆:fromCiv(world, civ, 干预列表)按列表补上还没到的干预(interventions.ts 的 resumeInterventions)。
 *
 * 纯计算,不碰 DOM。
 */
import type { World } from '../world';
import { MinHeap } from '../util';
import { Layer, type Annal, type AnnalKind, type ChangeLog, type Checkpoint, type Civ, type Year } from './types';
import { resumeCultures } from './cultures';
import { resumePolities } from './polities';
import { resumeWars } from './wars';
import { resumePolitics } from './politics';
import { resumeDynasty } from './dynasty';
import { resumeAssimilation } from './assimilation';
import { resumeCities } from './cities';
import { resumeDiplomacy } from './diplomacy';
import { resumeDevelopment } from './development';
import { resumeUnrest } from './unrest';
import { resumeControl } from './control';
import { resumeCouncil } from './council';
import { resumeRegency } from './regency';
import { resumeMarriage } from './marriage';
import { resumePlague } from './plague';
import { resumePandemic } from './pandemic';
import type { Calamity } from './calamity';
import { resumeTreaties } from './treaties';
import { resumeInterventions, scheduleInterventions } from './interventions';
import type { Intervention } from '../edits';

// ---------------------------------------------------------------------------
// 事件类型编号表(变化日志的 cause 用同一套编号;阶段 3 从 7 往下接着编:战争 7–9,分合 10–14,王朝更替 15–19(新君即位 16),
// 民族同化与迁徙 20–24,城市兴衰 25–29;阶段 4 干预 30–35;邦交 40–44)

export const enum Ev {
  /** 没有原因(初始状态) */
  None = 0,
  /** 民族诞生:a = 发源州,b = 民族。发源州已被别族占了,就近找一个空的可居州 */
  CultureBorn = 1,
  /** 民族到达:a = 州,b = 民族。州还没人住就归属这个民族;不可居的州只是路过 */
  CultureArrive = 2,
  /** 建城(polities.ts):a = 州,b = 城镇 */
  SettlementFound = 3,
  /** 立国(polities.ts):a = 国都所在州,b = 国家 */
  PolityFound = 4,
  /** 国家到达(polities.ts):a = 州,b = 国家。州有人住、还没归别国,就归这个国家 */
  PolityArrive = 5,
  /** 升格(polities.ts):a = 国都所在州,b = 国家。国土跨过一档(部 → 国 → 王国 → 帝国),国号升一级,记进 Polity.titles */
  PolityRank = 6,
  /**
   * 看邻国(阶段 3 战争,wars.ts):a = 立国后第几次看(按年份段编号),b = 国家。
   * 国家隔几十年看一眼接壤的邻国:国力比、扩张性、是不是异族、上次议和过了多久,决定要不要宣战
   */
  WarCheck = 7,
  /**
   * 战役(wars.ts):a = 这场战争的第几仗,b = 战争编号。攻方打一个和自己国土接壤的敌州,
   * 打不下来守方可能反攻、夺回这场战争里丢的州;打完看要不要议和,不议和就预约下一仗
   */
  Campaign = 8,
  /** 攻占(wars.ts):不单独预约,是战役里改归属(setOwner)时变化日志记的原因 */
  Conquer = 9,
  /**
   * 看内政(阶段 3 分合,politics.ts):a = 立国后第几次看(按年份段编号),b = 国家。
   * 国家隔几十年看一眼自己:边远的州会不会起兵自立(分裂)、国都要不要迁到国土中部(主动迁都)、
   * 小国会不会并入接壤的同族大国(合并)
   */
  PoliticsCheck = 10,
  /** 分裂 / 复国(politics.ts):不单独预约,是起兵自立的州改归新国家时变化日志记的原因 */
  Split = 11,
  /** 合并(politics.ts):不单独预约,是小国的州并入大国时变化日志记的原因 */
  Merge = 12,
  /**
   * 看复国(politics.ts):a = 亡国后第几次看,b = 亡国的国家。故国国都一带仍是同族人住、
   * 当前的宗主又弱(在打仗 / 刚分裂 / 刚迁都)时,遗民举旗复国
   */
  RestoreCheck = 13,
  /**
   * 看部落地带(politics.ts):a = 第几次看。阶段 2 里因为离别国国都太近没能立国的城,
   * 那个国都灭亡 / 迁走以后,在这里再试一次立国
   */
  TribalCheck = 14,
  /**
   * 看王朝(阶段 3 王朝更替,dynasty.ts):a = 立国后第几次看(按年份段编号),b = 国家。
   * 大国隔几十年看一眼:当朝立了多久(越久越容易亡)、国势动荡(战败失地、国都失守、刚分裂),决定会不会改朝换代。
   * 改朝换代不改归属(同一个国家编号),新朝定都根据地时迁都
   */
  DynastyCheck = 15,
  /**
   * 新君即位(polities.ts;在位表见 rulers.ts):a = 本国第几位君主,b = 国家。门槛比上一位低的(扩张算账),
   * 从现有国土往外重新看一遍边上的部落地带;再预约下一位。改朝换代后在位表重排,对不上的丢掉
   */
  Reign = 16,
  /** 迁都的下一刻(polities.ts 的 moveCapital):b = 国家。按新国都的路程从现有国土往外重新预约扩张 */
  Respread = 17,
  /**
   * 航海时代(polities.ts):这一刻起,有港口的普通国家也能沿航线往海外扩张(海洋国家从来就能)。
   * 在世的普通国家这一刻从现有国土往外重新预约一遍扩张(同一刻里排在地形大事后面、别的事件前面)
   */
  AgeOfSail = 18,
  /**
   * 看民族(阶段 3 同化与迁徙,assimilation.ts;编号 20–24):a = 立国后第几次看(按年份段编号),b = 国家。
   * 国家隔几十年看一眼治下的各州:异族州被统治久了、离核心近、四周同族多,就改换成统治民族(同化);
   * 统治民族太少时反过来被多数民族同化;这些年打下来的州,游牧民族会迁人进来,被征服的民族会外迁
   */
  CultureCheck = 20,
  /** 同化(assimilation.ts):不单独预约,是一州改换民族时变化日志记的原因 */
  Assimilate = 21,
  /** 迁徙(assimilation.ts):不单独预约,是迁入的州改换民族时变化日志记的原因 */
  Migrate = 22,
  /**
   * 看孤地(assimilation.ts):a = 第几次看。每隔几十年看一眼部落地带(没有国家的州)里被别族团团围住的孤地:
   * 久了会被四邻同化(日志原因记 Assimilate)
   */
  EnclaveCheck = 23,
  /**
   * 看重建(阶段 3 城市兴衰,cities.ts):a = 城被毁后第几次看,b = 被毁的城。
   * 州里有人住、战火已息,就有机会在故址上重建一座新城;看够次数都没建 = 就此荒废
   */
  CityRebuild = 25,
  /**
   * 看旧都(cities.ts):a = 这座城的第几段国都(Settlement.capitalSpans 的下标),b = 城。
   * 失去国都之位约一百多年后,人口明显回落的记一条"旧都渐衰"
   */
  CityDecline = 26,
  /**
   * 干预(阶段 4,interventions.ts;编号 30–35):a = 第几条干预(干预列表的下标)。在它的年份(from)那一刻生效:
   * 记一条史事 intervene,结盟时正在交战的两国当即议和,宣战的强制开战,划州、立国、迁都当即改归属 / 国都,
   * 不许扩张的国家挑起的战争当即议和。在所有别的事件之前预约(同一刻里只排在 earlyOrder 那几类后面)
   */
  Intervene = 30,
  /** 划州(interventions.ts):不单独预约,是干预"划州"(和立国时带走的余州)改归属时变化日志记的原因 */
  Cede = 31,
  /**
   * 不许扩张到期(interventions.ts):a = 第几条干预。到 until 那一刻,这国从现有国土重新预约往外扩张
   * (禁令期间的"国家到达"都丢掉了)。在所有别的事件之前预约(同一刻里比干预事件还早)
   */
  HaltEnd = 32,
  /**
   * 地形大事(upheaval.ts):a = 第几件大事。在它的年份那一刻(同一刻里最先)处理后果:城沉入海 / 毁于火山,
   * 淹掉的州国家和民族撤出(变化日志原因也记这个),国都没了的迁都、亡国
   */
  Upheaval = 33,
  /**
   * 多看一眼(interventions.ts):a = 第几条干预(照大纲顺着引的方针,带 look),b = 它的第几眼。
   * 到那一年的年中替那国多看一眼邻国 / 内政 / 王朝(随机数按 LOOK_K 往上的"第几次"取,不接着预约)。装各层时就预约
   */
  Look = 34,
  /**
   * 看邦交(diplomacy.ts;编号 40–44):a = 立国后第几次看(按年份段编号),b = 国家。
   * 国家隔几十年看一眼:藩属要不要自立、宗主收不收藩属的国土、盟约废不废、畏不畏强邻(称臣 / 结盟)
   */
  DiplomacyCheck = 40,
  /**
   * 约满(立约,treaties.ts):a = 约的编号。立约 / 续约那一刻预约在期满那一刻:看几国续不续约,不续就约废、中立地撤销
   */
  TreatyEnd = 41,
  /** 中立地(treaties.ts):不单独预约,是一州划为中立地(归属 → −1)、中立地撤销还给原主时变化日志记的原因 */
  Neutral = 42,
  /** 中立地到期(treaties.ts):a = 中立地的编号。作者下令划的中立地选了"到某一年",划的那一刻预约在那一年:撤销 */
  ZoneEnd = 43,
  /**
   * 看分化(民族分化,assimilation.ts;编号 45–49):a = 第几次看。每隔一百年看一眼各民族:被海峡、山脉隔开,
   * 或分属不同国家几百年的一支,有机会分化成新民族(亲缘民族,族名带母族的名字)
   */
  DivergeCheck = 45,
  /** 分化(assimilation.ts):不单独预约,是分出去的州改换成新民族时变化日志记的原因 */
  Diverge = 46,
  /**
   * 发展度(development.ts;编号 50):每 20 年一刻,算各州的五种能力、时代、物产,再让它们影响推演
   * (城的人口上限、打仗的军力、普通国家能不能远洋)。同一刻里排在地形大事、航海时代后面,别的事件前面(见 earlyOrder)
   */
  DevTick = 50,
  /**
   * 政局的数表(control.ts;编号 51):每年一刻,按此刻的归属、国都、行政能力、危机……算各州管得到几成、离国都多远、各国的动荡,
   * 这一年里的事件读它。同一刻里排在发展度后面(读这一刻刚算的行政能力),别的事件前面(见 earlyOrder)
   */
  TableTick = 51,
  /**
   * 掌实权(regency.ts;编号 52):b = 国家。到那一刻办这国的事:掌着权的人到期了办结局(还政、伏诛、篡位、卒),
   * 君主晚年该有的引兵入朝、太子监国看成不成。重复预约、预约了却对不上的什么都不做。
   * 同一刻里排在看王朝、新君即位、迁都后重看边地后面(同一国),别的事件前面(见 earlyOrder)
   */
  Regency = 52,
  /**
   * 看年景(动荡、饥荒、民变、大崩解,unrest.ts;编号 55–57):a = 第几次看。每隔十来年,世上几处闹灾年(干旱、寒冷的地方多),
   * 人口顶到上限的城闹饥荒、人口掉一截;闹了饥荒又动荡的大国,饥民可能起事(民变)
   */
  FamineCheck = 55,
  /** 散回部落(unrest.ts 的大崩解):不单独预约,是大国崩解时散回部落地带的州(国家归属 → −1)变化日志记的原因 */
  Collapse = 57,
  /**
   * 看疫情(瘟疫,plague.ts;编号 58–59):a = 第几次看。每隔几十年看一次,偶尔从一座大城或港口起疫
   */
  PlagueCheck = 58,
  /** 疫情传开(plague.ts):a = 第几场瘟疫(起疫那次看疫情的编号),b = 起疫后第几年。染疫的州往外传一圈,预约下一年 */
  PlagueStep = 59,
  /**
   * 看全球大疫(pandemic.ts;编号 60–62):a = 第几次看。只有「天灾」设成多、很多的世界才有:世上有国家能远洋以后,
   * 隔几十年看一次,偶尔从一座大港起一场全球大疫
   */
  PandemicCheck = 60,
  /** 疫后凋敝(pandemic.ts):这一刻有全球大疫"疫气复作"(人口再掉一截、村镇荒废)。同一刻几场一起处理 */
  SlumpStep = 61,
  /** 看地震水旱(pandemic.ts):a = 第几次看。只有「天灾」设成多、很多的世界才有:各国偶尔闹一场地震、大水、大旱 */
  QuakeCheck = 62,
}

export interface EventInfo {
  id: number;
  name: string;
  /** 弹出时是否核对州 a 的版本号(预约之后州 a 的归属变过 → 过期丢掉) */
  watch: boolean;
}

/** 事件类型表。阶段 3 在末尾往下加(宣战、战役、攻占、分裂、合并、灭亡、迁都、瘟疫……) */
export const EVENT_INFO: EventInfo[] = [
  { id: Ev.None, name: '无', watch: false },
  { id: Ev.CultureBorn, name: '民族诞生', watch: false },
  { id: Ev.CultureArrive, name: '民族到达', watch: true },
  { id: Ev.SettlementFound, name: '建城', watch: false },
  { id: Ev.PolityFound, name: '立国', watch: false },
  { id: Ev.PolityArrive, name: '国家到达', watch: true },
  { id: Ev.PolityRank, name: '升格', watch: false },
  { id: Ev.WarCheck, name: '看邻国', watch: false },
  { id: Ev.Campaign, name: '战役', watch: false },
  { id: Ev.Conquer, name: '攻占', watch: false },
  { id: Ev.PoliticsCheck, name: '看内政', watch: false },
  { id: Ev.Split, name: '分裂', watch: false },
  { id: Ev.Merge, name: '合并', watch: false },
  { id: Ev.RestoreCheck, name: '看复国', watch: false },
  { id: Ev.TribalCheck, name: '看部落地带', watch: false },
  { id: Ev.DynastyCheck, name: '看王朝', watch: false },
  { id: Ev.Reign, name: '新君即位', watch: false },
  { id: Ev.AgeOfSail, name: '航海时代', watch: false },
  { id: Ev.CultureCheck, name: '看民族', watch: false },
  { id: Ev.Assimilate, name: '同化', watch: false },
  { id: Ev.Migrate, name: '迁徙', watch: false },
  { id: Ev.EnclaveCheck, name: '看孤地', watch: false },
  { id: Ev.CityRebuild, name: '看重建', watch: false },
  { id: Ev.CityDecline, name: '看旧都', watch: false },
  { id: Ev.Intervene, name: '干预', watch: false },
  { id: Ev.Cede, name: '划州', watch: false },
  { id: Ev.HaltEnd, name: '解除禁扩', watch: false },
  { id: Ev.Upheaval, name: '地形大事', watch: false },
  { id: Ev.Look, name: '多看一眼', watch: false },
  { id: Ev.DiplomacyCheck, name: '看邦交', watch: false },
  { id: Ev.TreatyEnd, name: '约满', watch: false },
  { id: Ev.Neutral, name: '中立地', watch: false },
  { id: Ev.ZoneEnd, name: '中立地到期', watch: false },
  { id: Ev.DivergeCheck, name: '看分化', watch: false },
  { id: Ev.Diverge, name: '分化', watch: false },
  { id: Ev.DevTick, name: '发展度', watch: false },
  { id: Ev.TableTick, name: '政局', watch: false },
  { id: Ev.Regency, name: '掌实权', watch: false },
  { id: Ev.FamineCheck, name: '看年景', watch: false },
  { id: Ev.Collapse, name: '散回部落', watch: false },
  { id: Ev.PlagueCheck, name: '看疫情', watch: false },
  { id: Ev.PlagueStep, name: '疫情传开', watch: false },
  { id: Ev.PandemicCheck, name: '看全球大疫', watch: false },
  { id: Ev.SlumpStep, name: '疫后凋敝', watch: false },
  { id: Ev.QuakeCheck, name: '看地震水旱', watch: false },
];

/** 检查点间隔(年) */
export const CHECKPOINT_EVERY = 100;

/** 事件时间精度:1/256 年(约一天半) */
const TICKS_PER_YEAR = 256;
/**
 * 优先级 = 时刻 × TICK_SPAN + 同一刻里的次序:地形大事、看王朝、新君即位、迁都后重看边地 = earlyOrder(< EARLY_SPAN,排在最前);
 * 别的事件 = EARLY_SPAN + 编号(预约先后,< SEQ_SPAN);民族、国家到达 = SEQ_SPAN + arrivalOrder(排在最后)。
 * 都是整数,拼起来不超过 2^53 − 1,Float64 里精确
 */
const EARLY_SPAN = 2 ** 15;
const SEQ_SPAN = 2 ** 28;
const TICK_SPAN = 2 ** 29;
/** 能预约的最远时刻:65536 年(Float32 的变化日志在这个范围内也能精确存下 1/256 年) */
const MAX_TICK = 2 ** 24;

/**
 * 民族、国家到达在同一刻里的次序(0 起,< SEQ_SPAN):民族先、国家后,再按州号、民族 / 国家号。
 * 不是到达、或州号 / 编号超出能编的范围(极大的世界),返回 −1(按预约先后)
 */
function arrivalOrder(kind: number, a: number, b: number): number {
  if (kind !== Ev.CultureArrive && kind !== Ev.PolityArrive) return -1;
  if (!(a >= 0 && a < 2 ** 15 && b >= 0 && b < 2 ** 12)) return -1;
  return (kind === Ev.PolityArrive ? 2 ** 27 : 0) + a * 2 ** 12 + b;
}

/**
 * 排在同一刻最前面的事件的次序(0 起,< EARLY_SPAN):
 * - 地形大事 = 0:同一刻的别的事都按大事以后的地形和归属算(一次推演里只有一件,见 index.ts)
 * - 航海时代 = 1:同一刻的别的事都按"已经能走航线"算(polities.ts 的 sailsOcean)
 * - 发展度 = 2:只读这一刻以前的事;它改的人口上限、军力、远洋,同一刻的别的事都按改过的算(接着推时按 Civ 里存的状态接上)
 * - 政局的数表 = 3:按发展度刚算的行政能力算;同一刻的别的事都读它算出来的值
 * - 看王朝、新君即位、迁都后重看边地、掌实权 = 4 起:按国家号,同一国依次是看王朝、即位、重看、掌实权。
 *   看王朝在前:同一刻改朝换代了,旧朝原定这一刻即位的那位就不即位了(在位表重排,Ev.Reign 对不上就丢掉);
 *   即位、重看只从现有国土往外预约扩张、不改归属,排在别的事件前面 —— 接着推时 resumePolities 也是在同一刻的日志
 *   (大事改的归属除外)之前重放。掌实权的事从下一刻起才算数(regents.ts),同一国同一刻预约几次也只办一回
 * - 看地震水旱、看全球大疫、疫后凋敝、看疫情、疫情传开 = EARLY_SPAN − 5 … − 1(这几类之后、别的事件之前):接着推时它们最后才补进引擎,
 *   排在固定的位置,同一刻的别的事件(攻占、毁城)在它前还是在它后,和一口气推完一样(同一刻每类至多一件)
 * 不是这几类、或国家号超出能编的范围,返回 −1(按预约先后)
 */
const EARLY_KINDS: Partial<Record<number, number>> = { [Ev.DynastyCheck]: 0, [Ev.Reign]: 1, [Ev.Respread]: 2, [Ev.Regency]: 3 };
function earlyOrder(kind: number, b: number): number {
  if (kind === Ev.Upheaval) return 0;
  if (kind === Ev.AgeOfSail) return 1;
  if (kind === Ev.DevTick) return 2;
  if (kind === Ev.TableTick) return 3;
  if (kind === Ev.QuakeCheck) return EARLY_SPAN - 5;
  if (kind === Ev.PandemicCheck) return EARLY_SPAN - 4;
  if (kind === Ev.SlumpStep) return EARLY_SPAN - 3;
  if (kind === Ev.PlagueCheck) return EARLY_SPAN - 2;
  if (kind === Ev.PlagueStep) return EARLY_SPAN - 1;
  const i = EARLY_KINDS[kind];
  if (i === undefined || !(b >= 0 && b < (EARLY_SPAN - 12) / 4 - 1)) return -1;
  return 4 + b * 4 + i;
}

/** 多看一眼(Ev.Look)用的"第几次"从这里往上数(看邻国、内政、王朝的寻常第几次到不了这么大) */
export const LOOK_K = 1 << 20;

/** schedule 的 booked:一口气推时在装各层的时候(第 0 年的事件处理之前)就预约了的事件 */
export const BOOKED_AT_START = -1;

/** 预约链最多记几层(见 bookChain) */
const BOOK_DEPTH = 3;

/**
 * 隔一阵子一次的事件(看邻国、看内政、看年景、下一仗……)第 k 次的预约链,给 schedule 的 booked:
 * 第 k 次是第 k − 1 次那一刻预约的,第 k − 1 次又是第 k − 2 次那一刻预约的……第 0 次是 first 那一刻(立国、宣战、开头……)预约的。
 * at(j) = 第 j 次的时刻。两件事预约的那一刻相同(上一次也撞在同一刻)时,按上一次是哪一刻预约的定先后,和一口气推完一样
 */
export function bookChain(k: number, at: (j: number) => number, first: number): number[] {
  const out: number[] = [];
  for (let j = k - 1; j >= -1 && out.length < BOOK_DEPTH; j--) out.push(j >= 0 ? quantize(at(j)) : first);
  return out;
}

/** 接着推时攒着的一件事件(见 CivSim.releaseHeld):tick = 时刻(1/256 年为单位),booked = 预约链(同样的单位),i = 补上的先后 */
interface HeldEvent {
  tick: number;
  kind: number;
  a: number;
  b: number;
  ver: number;
  booked: number[];
  sub: number;
  i: number;
}

/** 两条预约链比先后:一层层比,比到短的那条用完还一样 = 0 */
function compareChain(x: readonly number[], y: readonly number[]): number {
  const n = Math.min(x.length, y.length);
  for (let i = 0; i < n; i++) if (x[i] !== y[i]) return x[i] - y[i];
  return 0;
}

/** 把时间取整到引擎的精度(1/256 年)。引擎里所有事件时间、日志年份都是这样的值 */
export function quantize(t: number): number {
  return Math.round(t * TICKS_PER_YEAR) / TICKS_PER_YEAR;
}

export type EventHandler = (a: number, b: number, t: number) => void;
export type ChangeListener = (region: number, value: number, prev: number, cause: number) => void;

/** 可增长的变化日志(结构数组) */
class LogBuffer {
  size = 0;
  year: Float32Array;
  region: Int32Array;
  layer: Uint8Array;
  value: Int16Array;
  cause: Uint8Array;
  constructor(cap = 1024) {
    this.year = new Float32Array(cap);
    this.region = new Int32Array(cap);
    this.layer = new Uint8Array(cap);
    this.value = new Int16Array(cap);
    this.cause = new Uint8Array(cap);
  }
  static from(log: ChangeLog): LogBuffer {
    const b = new LogBuffer(Math.max(1024, log.size * 2));
    b.size = log.size;
    b.year.set(log.year.subarray(0, log.size));
    b.region.set(log.region.subarray(0, log.size));
    b.layer.set(log.layer.subarray(0, log.size));
    b.value.set(log.value.subarray(0, log.size));
    b.cause.set(log.cause.subarray(0, log.size));
    return b;
  }
  push(year: number, region: number, layer: number, value: number, cause: number) {
    if (this.size === this.year.length) {
      const cap = this.size * 2;
      const grow = <T extends Float32Array | Int32Array | Uint8Array | Int16Array>(a: T, make: (n: number) => T): T => {
        const b = make(cap);
        b.set(a);
        return b;
      };
      this.year = grow(this.year, (n) => new Float32Array(n));
      this.region = grow(this.region, (n) => new Int32Array(n));
      this.layer = grow(this.layer, (n) => new Uint8Array(n));
      this.value = grow(this.value, (n) => new Int16Array(n));
      this.cause = grow(this.cause, (n) => new Uint8Array(n));
    }
    const i = this.size++;
    this.year[i] = year;
    this.region[i] = region;
    this.layer[i] = layer;
    this.value[i] = value;
    this.cause[i] = cause;
  }
  /** 裁成正好 size 条的副本(发给主线程用) */
  toChangeLog(): ChangeLog {
    const n = this.size;
    return {
      size: n,
      year: this.year.slice(0, n),
      region: this.region.slice(0, n),
      layer: this.layer.slice(0, n),
      value: this.value.slice(0, n),
      cause: this.cause.slice(0, n),
    };
  }
}

/** 推演结果:写回 Civ 的那几项 */
export interface SimResult {
  endYear: Year;
  log: ChangeLog;
  checkpoints: Checkpoint[];
  /** endYear 时各州的民族 */
  culture: Int16Array;
  /** endYear 时各州的国家 */
  polity: Int16Array;
  /** 史事(按发生先后) */
  annals: Annal[];
}

export class CivSim {
  /** 州数 */
  readonly R: number;
  /** 当前时间(年) */
  now: Year = 0;
  /**
   * 预约的事件最早在这一刻(默认不限)。地形大事接着推时 = 大事那一刻:按新地形重算出来的、本该更早发生的事(新海路上的到达……)
   * 一律从大事那一刻起,排在大事后面(gen/civ/index.ts)
   */
  floor: Year = -Infinity;
  /** 「天灾」设定(calamity.ts;平常 = undefined):瘟疫、饥荒更多,会自己闹地震水旱、全球大疫。装各层之前定下 */
  calamity: Calamity | undefined = undefined;
  /** 各层的当前归属(按 Layer 下标);只读,改归属一律走 setOwner */
  readonly owners: [Int16Array, Int16Array];
  /** 各州的版本号:归属(任何一层)每变一次 +1 */
  readonly version: Int32Array;

  private log = new LogBuffer();
  private annals: Annal[] = [];
  private checkpoints: Checkpoint[] = [];
  private nextCheckpoint = CHECKPOINT_EVERY;

  // 事件:结构数组 + 空槽回收;堆里放槽号,优先级 = 时刻 × TICK_SPAN + 同一刻里的次序(见 SEQ_SPAN)
  private heap = new MinHeap(1024);
  private evT = new Float64Array(1024);
  private evKind = new Uint8Array(1024);
  private evA = new Int32Array(1024);
  private evB = new Int32Array(1024);
  private evVer = new Int32Array(1024);
  private evCount = 0;
  private free: number[] = [];
  private seq = 0;
  /** 接着推时各层补上的、同一刻里按预约先后排的事件(fromCiv 补完以后按一口气推时的预约先后放进事件堆,见 releaseHeld);平常 = null */
  private held: HeldEvent[] | null = null;

  private handlers: (EventHandler | undefined)[] = [];
  private watch = new Uint8Array(256);
  private listeners: ChangeListener[][] = [[], []];

  /** 推演过程中处理了多少个事件(含过期丢掉的),调参 / 测试用 */
  processed = 0;

  constructor(regionCount: number) {
    this.R = regionCount;
    this.owners = [new Int16Array(regionCount).fill(-1), new Int16Array(regionCount).fill(-1)];
    this.version = new Int32Array(regionCount);
    for (const e of EVENT_INFO) this.watch[e.id] = e.watch ? 1 : 0;
  }

  /**
   * 由 Civ 数据重建推演状态(各层归属、版本号、日志、检查点),再让各层重建待发生的事件,
   * 然后就能从 civ.endYear 接着推:sim.run(更晚的年份)。不需要保存事件堆,阶段 4 的存档也只存 Civ。
   * interventions = 接着推时带着的干预(阶段 4;默认 = 这份历史推出来时带着的 civ.interventions):
   * 已经过了的只影响之后的决定(规则),还没到的补上它们的事件。后面可以接上几条比 civ.endYear 晚的(逐年推演时下的新命令,civ/play.ts)。
   * first = 最先预约的事件(地形大事那一刻接着推时:大事本身)
   */
  static fromCiv(world: World, civ: Civ, interventions: readonly Intervention[] = civ.interventions ?? [], first?: (sim: CivSim) => void): CivSim {
    const sim = new CivSim(civ.regions.count);
    sim.owners[Layer.Culture].set(civ.culture);
    sim.owners[Layer.Polity].set(civ.polity);
    sim.log = LogBuffer.from(civ.log);
    sim.annals = civ.annals.map((e) => ({ ...e }));
    for (let i = 0; i < civ.log.size; i++) sim.version[civ.log.region[i]]++;
    sim.checkpoints = civ.checkpoints.slice();
    sim.now = civ.endYear;
    sim.calamity = civ.calamity;
    // 下一个检查点:最后一个检查点之后的那个整百年(推到整百年的前一刻切开时,那个整百年的检查点还没存,接着推时补上)
    const cps = civ.checkpoints;
    sim.nextCheckpoint = cps.length ? cps[cps.length - 1].year + CHECKPOINT_EVERY : CHECKPOINT_EVERY;
    // 各层重建自己的事件(和 generateCiv 里 install 的顺序一样:先民族,再城镇和国家,再战争,再分合,再王朝,再同化与迁徙,
    // 再城市兴衰 —— 它要挂在战争模型上(攻城)、要国家模型的迁都回调;再邦交 —— 要挂在战争模型上)
    if (civ.viable && civ.cultures.length) {
      // 地形大事(first)、干预的事件最先预约(和 generateCiv 一样:同一刻里地形大事最先,干预只排在新君即位、迁都后重看边地后面)
      first?.(sim);
      const iv = scheduleInterventions(sim, civ.seed, interventions, true);
      // 各层补上的"按预约先后排"的事件先攒着,补完按一口气推时预约的时刻排好再放进事件堆(见 schedule 的 booked)。
      // 干预在一口气推时最先预约(generateCiv 里装各层之前),这里也在攒之前直接放进去,同一刻里排在补上的事件前面
      sim.held = [];
      // 地形大事以后补备的新民族(干预立国用):国家那一层也要认得它们(民族表接在后面)
      const extra = resumeCultures(sim, world, civ, interventions);
      resumePolities(sim, world, extra.length ? { ...civ, cultures: [...civ.cultures, ...extra] } : civ, iv);
      resumeWars(sim, world, civ);
      resumePolitics(sim, world, civ);
      resumeDynasty(sim, world, civ);
      resumeAssimilation(sim, world, civ);
      resumeCities(sim, world, civ);
      resumeDiplomacy(sim, world, civ);
      resumeDevelopment(sim, world, civ);
      resumeUnrest(sim, world, civ);
      resumeControl(sim, civ);
      resumeCouncil(sim, civ);
      resumeRegency(sim, civ);
      resumeMarriage(sim, civ);
      resumePlague(sim, world, civ, iv?.list);
      resumePandemic(sim, civ, iv?.list);
      resumeTreaties(sim, world, civ);
      if (iv) resumeInterventions(sim, iv);
      sim.releaseHeld();
    }
    return sim;
  }

  /**
   * 接着推时攒着的事件按一口气推时的预约先后放进事件堆:同一时刻的几件,先按预约链(预约的时刻;一样的再看预约它的那件事是哪一刻预约的……),
   * 还一样的按 sub(同一刻立的几国:按国家号,一国的几件挨在一起),最后按补上的先后(各层的先后和 generateCiv 里装各层的先后一样)
   */
  private releaseHeld(): void {
    const held = this.held;
    this.held = null;
    if (!held) return;
    held.sort((x, y) => x.tick - y.tick || compareChain(x.booked, y.booked) || x.sub - y.sub || x.i - y.i);
    for (const e of held) this.push(e.tick, e.kind, e.a, e.b, e.ver);
  }

  /** 登记某类事件的处理函数。watch 不给就按 EVENT_INFO 表 */
  on(kind: number, handler: EventHandler, opts: { watch?: boolean } = {}): void {
    this.handlers[kind] = handler;
    if (opts.watch !== undefined) this.watch[kind] = opts.watch ? 1 : 0;
  }

  /** 登记某一层归属变化的监听者(setOwner 之后同步调用) */
  onChange(layer: Layer, fn: ChangeListener): void {
    this.listeners[layer].push(fn);
  }

  /**
   * 预约一个事件。t 早于现在(或 floor)就按现在(floor)算;取整到 1/256 年;超出 65536 年或不是有限数就不预约。
   * 要核对版本号的类型,记下州 a 此刻的版本号。
   * booked、sub 只在接着推(fromCiv 里各层补事件)时用:一口气推完时这件事是哪一刻预约的(装各层时就预约的 = BOOKED_AT_START;
   * 隔一阵子一次的事件给预约链,见 bookChain),同一刻预约的几件按 sub、再按补上的先后排(见 releaseHeld)。推演中途预约的不用给(就是现在)
   */
  schedule(t: number, kind: number, a: number, b: number, booked: number | readonly number[] = BOOKED_AT_START, sub = 0): void {
    if (!(t < Infinity)) return; // Infinity / NaN
    const tick = Math.round(Math.max(t, this.now, this.floor) * TICKS_PER_YEAR);
    if (tick >= MAX_TICK) return;
    const ver = this.watch[kind] && a >= 0 && a < this.R ? this.version[a] : -1;
    // 接着推时补的、同一刻里按预约先后排的事件:先攒着(见 releaseHeld)
    if (this.held && earlyOrder(kind, b) < 0 && arrivalOrder(kind, a, b) < 0) {
      const chain = typeof booked === 'number' ? [booked] : booked;
      this.held.push({ tick, kind, a, b, ver, booked: chain.map((y) => Math.round(y * TICKS_PER_YEAR)), sub, i: this.held.length });
      return;
    }
    this.push(tick, kind, a, b, ver);
  }

  /** 放进事件堆(tick = 取整好的时刻;ver = 州 a 此刻的版本号,不核对 = −1) */
  private push(tick: number, kind: number, a: number, b: number, ver: number): void {
    if (EARLY_SPAN + this.seq >= SEQ_SPAN) throw new Error('CivSim:事件太多(超过 2^28 个)');
    let id: number;
    if (this.free.length) id = this.free.pop()!;
    else {
      id = this.evCount++;
      if (id === this.evT.length) this.growEvents();
    }
    this.evT[id] = tick / TICKS_PER_YEAR;
    this.evKind[id] = kind;
    this.evA[id] = a;
    this.evB[id] = b;
    this.evVer[id] = ver;
    const early = earlyOrder(kind, b);
    const order = arrivalOrder(kind, a, b);
    this.heap.push(id, tick * TICK_SPAN + (early >= 0 ? early : order >= 0 ? SEQ_SPAN + order : EARLY_SPAN + this.seq++));
  }

  /** 变化日志(只读;推演中会增长、换数组,用完就丢,不要存下来):发展度按它找大崩解里散出去的州 */
  get logView(): Readonly<ChangeLog> {
    return this.log;
  }

  /** 已经记了几条史事 */
  get annalCount(): number {
    return this.annals.length;
  }

  /** 第 i 条史事(只读) */
  annal(i: number): Readonly<Annal> {
    return this.annals[i];
  }

  /** 待处理的事件数(含已过期、还没弹出的) */
  get pending(): number {
    return this.heap.size;
  }

  /** 唯一改归属的入口:写日志、版本号 +1、通知这一层的监听者。新值等于旧值时什么都不做 */
  setOwner(layer: Layer, region: number, value: number, cause: number): void {
    const own = this.owners[layer];
    const prev = own[region];
    if (prev === value) return;
    own[region] = value;
    this.version[region]++;
    this.log.push(this.now, region, layer, value, cause);
    for (const fn of this.listeners[layer]) fn(region, value, prev, cause);
  }

  /**
   * 记一条史事(年份 = 现在)。没给的字段记 −1;各种类用哪些字段见 types.ts 的 AnnalKind。
   * 只记,不改归属;改归属还是走 setOwner。
   */
  record(kind: AnnalKind, f: Partial<Omit<Annal, 'year' | 'kind'>> = {}): void {
    const e: Annal = {
      year: this.now,
      kind,
      a: f.a ?? -1,
      b: f.b ?? -1,
      region: f.region ?? -1,
      settlement: f.settlement ?? -1,
      war: f.war ?? -1,
    };
    if (f.via !== undefined) e.via = f.via;
    if (f.cause !== undefined) e.cause = f.cause;
    if (f.foe !== undefined) e.foe = f.foe;
    if (f.n !== undefined) e.n = f.n;
    if (f.ps !== undefined) e.ps = f.ps.slice();
    if (f.by !== undefined) e.by = f.by;
    if (f.opt !== undefined) e.opt = f.opt;
    if (f.until !== undefined) e.until = f.until;
    this.annals.push(e);
  }

  /** 推演到 untilYear(含这一年的事件);途中每过一个整百年存一个检查点 */
  run(untilYear: Year): void {
    const untilTick = Math.floor(untilYear * TICKS_PER_YEAR + 1e-9);
    const limit = (untilTick + 1) * TICK_SPAN;
    const heap = this.heap;
    while (heap.size && heap.pri[0] < limit) {
      const id = heap.pop();
      const t = this.evT[id];
      while (this.nextCheckpoint <= untilYear && t > this.nextCheckpoint) this.checkpoint();
      if (t > this.now) this.now = t;
      const kind = this.evKind[id];
      const a = this.evA[id];
      const b = this.evB[id];
      const ver = this.evVer[id];
      this.free.push(id);
      this.processed++;
      if (ver >= 0 && this.version[a] !== ver) continue; // 过期
      this.handlers[kind]?.(a, b, t);
    }
    while (this.nextCheckpoint <= untilYear) this.checkpoint();
    if (untilYear > this.now) this.now = untilYear;
  }

  /** 推演结果(日志裁成正好的长度;归属数组是副本) */
  result(): SimResult {
    return {
      endYear: this.now,
      log: this.log.toChangeLog(),
      checkpoints: this.checkpoints.slice(),
      culture: this.owners[Layer.Culture].slice(),
      polity: this.owners[Layer.Polity].slice(),
      annals: this.annals.map((e) => ({ ...e })),
    };
  }

  private checkpoint() {
    this.checkpoints.push({
      year: this.nextCheckpoint,
      culture: this.owners[Layer.Culture].slice(),
      polity: this.owners[Layer.Polity].slice(),
    });
    this.nextCheckpoint += CHECKPOINT_EVERY;
  }

  private growEvents() {
    const n = this.evT.length * 2;
    const t = new Float64Array(n);
    t.set(this.evT);
    this.evT = t;
    const k = new Uint8Array(n);
    k.set(this.evKind);
    this.evKind = k;
    const a = new Int32Array(n);
    a.set(this.evA);
    this.evA = a;
    const b = new Int32Array(n);
    b.set(this.evB);
    this.evB = b;
    const v = new Int32Array(n);
    v.set(this.evVer);
    this.evVer = v;
  }
}
