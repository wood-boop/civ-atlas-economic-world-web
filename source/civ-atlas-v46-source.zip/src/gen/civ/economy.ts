/**
 * Annual aggregate production on Civ Atlas's native regions. The caller supplies
 * this year's actual rural/city populations and native clock. No people, polity
 * or treasury are created here. Work is O(regions + native adjacency), not cells.
 */
import { KM_PER_UNIT, REF_CELLS } from './geo';
import type { EconomyGeography, EconomySnapshot, EconomyState, EconomyTrade, EconomyYearInput, EconomyYearResult, NativeEconomy, NativeEconomyModel } from './economyTypes';

export const ECONOMY_GOODS = ['粮食', '木材', '矿石', '燃料', '金属', '工具', '制成品'] as const;
export const ECONOMY_SECTORS = ['农牧渔', '林业', '采矿', '燃料', '冶炼', '工具', '工坊'] as const;
export const ECONOMY_GOOD_COUNT = 7;
const G = ECONOMY_GOOD_COUNT;
export const ECONOMY_BASE_PRICE = [1, 0.6, 0.9, 0.5, 2.5, 4, 2.2] as const;
const BASE_PRICE = ECONOMY_BASE_PRICE;
const PRODUCTIVITY = [4, 2.2, 1.6, 2.5, 1.2, 0.7, 1.2];
/** Labor on natural land/forest and simple hand tools survives loss of equipment.
 * Mining, fuel plant, metalworking and manufacturing have no free throughput. */
const HAND_PRODUCTIVITY = [3.2, 0.55, 0, 0, 0, 0.5, 0];
const DEPRECIATION = [0.025, 0.035, 0.04, 0.045, 0.045, 0.04, 0.035];
const STORAGE_LOSS = [0.1, 0.025, 0.002, 0.015, 0.002, 0.015, 0.025];
const WORKING_SHARE = 0.52;
const HISTORY_LIMIT = 64;
const MAX_TRADE_DETAILS = 512;
const positive = (x: number | undefined) => Number.isFinite(x) && x! > 0 ? x! : 0;
const bound = (x: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, x));

function blankSnapshot(count: number, year: number): EconomySnapshot {
  const rg = () => new Float32Array(count * G), r = () => new Float32Array(count);
  return { year, count, owner: new Int16Array(count).fill(-1), population: r(), rural: r(), urban: r(), output: rg(), inputs: rg(), consumption: rg(), inventory: rg(), prices: rg(), capital: rg(), labor: rg(),
    imports: rg(), exports: rg(), endowment: rg(), investment: rg(), investmentLabor: r(), spoilage: rg(), transportLoss: rg(), unmetOutput: rg(), foodNeed: r(), foodAdequacy: r(), capacityFactor: r(),
    agriculturalTaxBase: r(), industrialTaxBase: r(), marketTaxBase: r(), outputValue: r(), desiredConsumption: rg(), needSatisfaction: rg(), operatingSurplus: rg(), unsoldStock: rg(),
    publicSpend: r(), transportCapital: r(), transportLabor: r(), livingStandard: r(), importDependence: r(), trade: [] };
}

function blankResult(count: number, year: number): EconomyYearResult {
  const r = () => new Float64Array(count);
  return { foodAdequacy: r().fill(1), capacityFactor: r().fill(1), agriculturalTaxBase: r(), industrialTaxBase: r(), marketTaxBase: r(), outputValue: r(), publicSpend: r(), shortage: r(), urbanPopulationFactor: r().fill(1), snapshot: blankSnapshot(count, year) };
}

function copyState(s: EconomyState, count: number): EconomyState {
  const sized = (src: Float64Array | undefined, length: number, fill = 0) => { const a = new Float64Array(length).fill(fill); if (src) a.set(src.subarray(0, length)); return a; };
  const activated = new Uint8Array(count); activated.set(s.activated.subarray(0, count));
  const prices = sized(s.prices, count * G);
  for (let i = s.count * G; i < prices.length; i++) prices[i] = BASE_PRICE[i % G];
  return { year: s.year, count, historyEvery: s.historyEvery ?? 20, inventory: sized(s.inventory, count * G), capital: sized(s.capital, count * G), prices,
    previousPopulation: sized(s.previousPopulation, count), activated, foodAdequacy: sized(s.foodAdequacy, count, 1), capacityFactor: sized(s.capacityFactor, count, 1),
    transportCapital: sized(s.transportCapital, count), operatingReturn: sized(s.operatingReturn, count * G), sellThrough: sized(s.sellThrough, count * G, 1), livingStandard: sized(s.livingStandard, count) };
}

/** Restore the exact physical state; snapshots alone are never used to resume. */
export function createEconomy(geography: EconomyGeography, saved?: NativeEconomy): NativeEconomyModel {
  const count = geography.count;
  if (!Number.isInteger(count) || count < 0) throw new Error('Invalid native economy region count');
  const prices = new Float64Array(count * G);
  for (let i = 0; i < prices.length; i++) prices[i] = BASE_PRICE[i % G];
  const state: EconomyState = saved ? copyState(saved.state, count) : {
    year: null, count, historyEvery: 20, inventory: new Float64Array(count * G), capital: new Float64Array(count * G), prices,
    previousPopulation: new Float64Array(count), activated: new Uint8Array(count), foodAdequacy: new Float64Array(count).fill(1), capacityFactor: new Float64Array(count).fill(1),
    transportCapital: new Float64Array(count), operatingReturn: new Float64Array(count * G), sellThrough: new Float64Array(count * G).fill(1), livingStandard: new Float64Array(count),
  };
  const result = saved && saved.state.count === count ? structuredClone(saved.result) : blankResult(count, state.year ?? -1);
  result.publicSpend ??= new Float64Array(count);
  return { geography, state, history: saved ? structuredClone(saved.history) : [], result };
}

/** Save owns its buffers: subsequent annual ticks cannot mutate an earlier save. */
export function exportEconomy(model: NativeEconomyModel): NativeEconomy {
  return { version: 1, units: 'thousand-shi grain-equivalent', state: copyState(model.state, model.state.count), history: structuredClone(model.history), result: structuredClone(model.result) };
}

/** Historical reads never leak future output into the selected native year. */
export function economyAt(civ: { development?: { economy?: NativeEconomy } }, year: number): EconomySnapshot | undefined {
  const history = civ.development?.economy?.history;
  if (!history?.length || year < history[0].year) return undefined;
  let lo = 0, hi = history.length;
  while (lo < hi) { const mid = (lo + hi) >>> 1; if (history[mid].year <= year) lo = mid + 1; else hi = mid; }
  return history[lo - 1];
}

function remember(model: NativeEconomyModel, snapshot: EconomySnapshot): void {
  const list = model.history, state = model.state;
  // Remove the preceding unsampled live tail; retain the first native year.
  if (list.length > 1 && list[list.length - 1].year % state.historyEvery) list.pop();
  list.push(snapshot);
  if (list.length > HISTORY_LIMIT) {
    state.historyEvery *= 2;
    model.history = list.filter((x, i) => i === 0 || i === list.length - 1 || x.year % state.historyEvery === 0);
  }
}

/** Local resource rates are available native grades, not invented geological tonnes. */
function resource(x: EconomyYearInput, r: number, k: number): number {
  return bound(positive(x.available[r * 11 + k]), 0, positive(x.resources[r * 11 + k]));
}

function advantages(x: EconomyYearInput, geo: EconomyGeography, r: number, out: Float64Array): void {
  const grain = resource(x, r, 0), stock = resource(x, r, 1), wood = resource(x, r, 5), fish = resource(x, r, 7);
  const soil = x.soil ? bound(positive(x.soil[r]), 0, 1) : 1;
  const biome = geo.biome[r];
  const habitat = geo.capacity[r] > 0 && geo.area[r] > 0 ? 1 : 0;
  // Broad subsistence land exists outside the native map's best-resource grades.
  const climate = biome === 3 || biome === 2 ? 0 : biome === 11 || biome === 6 || biome === 7 ? 0.65 : biome === 4 ? 0.5 : 1;
  out[0] = habitat * soil * climate * (0.78 + 0.12 * grain + 0.08 * stock + 0.09 * fish);
  out[1] = wood > 0 ? 0.3 + 0.35 * wood : 0;
  out[2] = 0.32 * (resource(x, r, 2) + resource(x, r, 3)) + 0.1 * resource(x, r, 9);
  out[3] = 0.3 * wood + 0.5 * resource(x, r, 4) + 0.6 * resource(x, r, 8);
  const production = positive(x.capabilities[r * 5]);
  out[4] = production >= 0.6 ? bound((production + 0.4) / 2, 0.25, 2) : 0;
  // Stone/wood tools are possible before metalworking; later recipes require metal.
  out[5] = 0.7 + production * 0.12;
  out[6] = 0.65 + production * 0.15;
}

function recipe(sector: number, production: number, coal: boolean): readonly (readonly [number, number])[] {
  if (sector === 3) return coal ? [] : [[1, 0.45]]; // Coal/oil extraction vs charcoal.
  if (sector === 4) return [[2, 1.25], [3, 0.7]];
  if (sector === 5) return production >= 1.5 ? [[4, 0.45], [1, 0.2], [3, 0.12]] : production >= 0.6 ? [[2, 0.2], [1, 0.35]] : [[1, 0.5]];
  if (sector === 6) return [[1, 0.35], [5, 0.06], [3, 0.15]];
  return [];
}

/** Land potential uses exactly the native rural-capacity geography/scale. */
function landFoodLimit(geo: EconomyGeography, r: number): number {
  const area = positive(geo.area[r]);
  if (!area) return 0;
  const suit = positive(geo.capacity[r]) * ((2048 * 1024) / REF_CELLS) / area;
  return area * KM_PER_UNIT * KM_PER_UNIT * 10 * Math.pow(suit / 20, 3) / 1000 * 1.8;
}

/**
 * Resolve one native TableTick. Same year is idempotent; gaps are an integration
 * error, since repeating the last observed population for missing years is false.
 */
export function stepEconomy(model: NativeEconomyModel, x: EconomyYearInput): EconomyYearResult {
  const state = model.state, geo = model.geography, R = geo.count;
  if (!Number.isSafeInteger(x.year) || x.year < 0) throw new Error('Economy requires a native integer year');
  if (state.year === x.year) return model.result;
  if (state.year !== null && x.year !== state.year + 1) throw new Error(`Native economy clock gap: ${state.year} → ${x.year}`);
  if (state.count !== R) throw new Error('Native geography changed without economy state resize');
  for (const [name, values, length] of [['rural', x.rural, R], ['urban', x.urban, R], ['owner', x.owner, R], ['capabilities', x.capabilities, R * 5], ['resources', x.resources, R * 11], ['available', x.available, R * 11]] as const) {
    if (values.length < length) throw new Error(`Native economy input ${name} is shorter than its regional dimension`);
  }
  for (const [name, values] of [['publicBudget', x.publicBudget], ['publicPriority', x.publicPriority]] as const) if (values && values.length < R) throw new Error(`Native economy input ${name} is shorter than its regional dimension`);
  if (x.edgeOpenness && x.edgeOpenness.length < geo.adj.length) throw new Error('Native economy edgeOpenness is shorter than native adjacency');
  const result = blankResult(R, x.year), snap = result.snapshot, stocks = state.inventory, capital = state.capital, prices = state.prices;
  const target = new Float64Array(R * G), planned = new Float64Array(R * G), output = new Float64Array(R * G);
  const advantage = new Float64Array(G), weights = new Float64Array(G), productivity = new Float64Array(G), hand = new Float64Array(G), expected = new Float64Array(G);
  const workers = new Float64Array(R), population = new Float64Array(R);
  const forecast = new Float64Array(R * G), laborWanted = new Float64Array(G), sectorInputCost = new Float64Array(R * G), startPrice = prices.slice();
  const constructionClaim = new Float64Array(R * G);
  const transport = state.transportCapital ??= new Float64Array(R), returns = state.operatingReturn ??= new Float64Array(R * G);
  const sellThrough = state.sellThrough ??= new Float64Array(R * G).fill(1), living = state.livingStandard ??= new Float64Array(R);
  // Desired consumption depends on observed native production/living standards,
  // not an invented household income balance. Reverse recipes turn final demand
  // into input orders, bounded by existing usable throughput and real labor.
  for (let r = 0; r < R; r++) {
    const o = r * G, pop = positive(x.rural[r]) + positive(x.urban[r]), tech = positive(x.capabilities[r * 5]);
    const lastValue = positive(model.result.outputValue[r]);
    const discretionary = bound(0.15 + tech * 0.12 + (pop ? lastValue / pop : 0) * 0.18 + living[r] * 0.08, 0.1, 1.6) * bound(state.foodAdequacy[r], 0.1, 1);
    const norms = [1, 0.012 + discretionary * 0.012, 0, 0.016 + discretionary * 0.028, 0, 0.01 + discretionary * 0.018, 0.035 + discretionary * 0.16];
    advantages(x, geo, r, advantage);
    const coal = resource(x, r, 4) + resource(x, r, 8) > 0;
    const materialWork = pop * WORKING_SHARE * 0.08;
    const publicWork = Math.min(materialWork * 1.6, positive(x.publicBudget?.[r]) / Math.max(0.01, 0.5 * prices[o + 1] + 0.09 * prices[o + 5] + 0.625));
    for (let g = 0; g < G; g++) {
      const i = o + g, household = pop * norms[g]; snap.desiredConsumption![i] = household;
      target[i] = household * (g === 0 ? 1.18 : 1.12);
      const approximateCapacity = state.activated[r] ? capital[i] : pop * WORKING_SHARE * (g === 0 ? 0.6 : 0.1) * PRODUCTIVITY[g];
      const rate = PRODUCTIVITY[g] * (1 + tech * 0.1) * advantage[g] * (0.55 + 0.45 * bound(state.foodAdequacy[r], 0, 1));
      forecast[i] = Math.min(rate * pop * WORKING_SHARE * (g === 0 ? 0.9 : 0.18), HAND_PRODUCTIVITY[g] * advantage[g] * pop * WORKING_SHARE + approximateCapacity * (1 + tech * 0.14));
      if (g === 0) forecast[i] = Math.min(forecast[i], landFoodLimit(geo, r) * advantage[g] * (1 + tech * 0.1));
    }
    // Repair orders are actual desired wood/tools, never extra inventory. Old
    // plant with no customers does not generate endless replacement orders.
    let replacement = 0;
    for (let g = 0; g < G; g++) replacement += capital[o + g] * DEPRECIATION[g] * (g === 0 ? 1 : sellThrough[o + g]) / PRODUCTIVITY[g];
    const repair = Math.min(materialWork, replacement + materialWork * 0.2);
    constructionClaim[o + 1] = repair * 0.8 + publicWork * 0.65;
    constructionClaim[o + 5] = repair * 0.14 + publicWork * 0.11;
    target[o + 1] += constructionClaim[o + 1];
    target[o + 5] += constructionClaim[o + 5];
    if (tech >= 1.5) target[o + 4] += repair * 0.04 + publicWork * 0.06;
    for (let g = G - 1; g > 0; g--) {
      // A bounded trial order survives loss of equipment. This is a REQUEST for
      // inputs, never output: actual mines/plant still need paid construction.
      const trialThroughput = PRODUCTIVITY[g] * advantage[g] * materialWork * 0.1;
      const needed = Math.min(Math.max(0, target[o + g] - positive(stocks[o + g])), Math.max(forecast[o + g], trialThroughput));
      for (const [good, amount] of recipe(g, tech, coal)) target[o + good] += needed * amount;
      // A low-tech recovery path must still order real wood when the modern
      // recipe is unavailable; the fallback consumes it at execution time.
      if (g === 5 && tech >= 0.6 && !(resource(x, r, 2) + resource(x, r, 3) + positive(stocks[o + 4]) > 0)) target[o + 1] += needed * 0.7;
    }
  }

  for (let r = 0; r < R; r++) {
    const o = r * G, rural = positive(x.rural[r]), urban = positive(x.urban[r]), pop = rural + urban;
    population[r] = pop; workers[r] = pop * WORKING_SHARE;
    snap.owner[r] = x.owner[r]; snap.rural[r] = rural; snap.urban[r] = urban; snap.population[r] = pop; snap.foodNeed[r] = pop;
    advantages(x, geo, r, advantage);
    const production = positive(x.capabilities[r * 5]), conflict = 1 / (1 + positive(x.war?.[r]) * 0.2);
    const foodLast = bound(state.foodAdequacy[r], 0, 1);
    const health = (0.55 + 0.45 * foodLast) * conflict;
    for (let g = 0; g < G; g++) {
      productivity[g] = PRODUCTIVITY[g] * (1 + 0.1 * production) * advantage[g] * health;
      hand[g] = HAND_PRODUCTIVITY[g] * advantage[g] * health;
    }
    if (pop > 0 && !state.activated[r]) {
      // An explicit initial household endowment. Never repeated when population
      // grows or returns after abandonment; all later capital must be built.
      state.activated[r] = 1;
      const initial = [0.3, 0.05, 0.025, 0.04, 0.012, 0.025, 0.02];
      const farmShare = 0.15 + 0.55 * rural / pop;
      const share = [farmShare, ...[0.15, 0.13, 0.15, 0.09, 0.15, 0.23].map((v) => v * (1 - farmShare) / 0.9)];
      for (let g = 0; g < G; g++) {
        const amount = pop * initial[g]; stocks[o + g] += amount; snap.endowment[o + g] = amount;
        capital[o + g] = Math.max(0.001, workers[r] * share[g] * PRODUCTIVITY[g] * (g === 0 ? 1.25 : 1));
      }
    }
    for (let g = 0; g < G; g++) capital[o + g] *= Math.max(0, 1 - DEPRECIATION[g] * (1 + positive(x.war?.[r]) * 0.15));
    transport[r] *= Math.max(0, 1 - 0.025 * (1 + positive(x.war?.[r]) * 0.2));
    if (!pop) { for (let g = 0; g < G; g++) capital[o + g] = Math.max(0, capital[o + g]); continue; }
    // Subsistence has priority; remaining workers respond to last year's prices,
    // local yields, feasible capital and actual recipe costs (comparative advantage).
    let weightSum = 0;
    const coal = resource(x, r, 4) + resource(x, r, 8) > 0;
    const productionWorkers = workers[r] * 0.90; // 8% construction, 2% hauling.
    for (let g = 0; g < G; g++) {
      expected[g] = Math.min(productivity[g], hand[g] + capital[o + g] * (1 + 0.14 * production) / Math.max(0.001, productionWorkers));
    }
    for (let g = 1; g < G; g++) {
      let cost = 0;
      for (const [good, amount] of recipe(g, production, coal)) cost += prices[o + good] * amount;
      const margin = Math.max(0.03, prices[o + g] - cost);
      let feasible = 1;
      for (const [good, amount] of recipe(g, production, coal)) {
        const supply = Math.max(0, stocks[o + good]) + Math.min(productivity[good] * productionWorkers * 0.1, hand[good] * productionWorkers * 0.1 + capital[o + good] * (1 + 0.14 * production));
        feasible = Math.min(feasible, supply / Math.max(0.001, productionWorkers * 0.1 * PRODUCTIVITY[g] * amount));
      }
      if (g === 5 && production >= 0.6) {
        const wood = Math.max(0, stocks[o + 1]) + Math.min(productivity[1] * productionWorkers * 0.1, hand[1] * productionWorkers * 0.1 + capital[o + 1] * (1 + 0.14 * production));
        feasible = Math.max(feasible, Math.min(1, wood / Math.max(0.001, productionWorkers * 0.1 * 0.7)) * 0.45);
      }
      let exportDemand = 0;
      for (let j = geo.adjStart[r]; j < geo.adjStart[r + 1]; j++) {
        const n = geo.adj[j]; if (n < 0 || n >= R) continue;
        const openness = x.edgeOpenness ? bound(positive(x.edgeOpenness[j]), 0, 1.5) : 1;
        // Only actual neighbor supply gaps create export orders; superior local
        // productivity can also displace inefficient neighbor production.
        const shortage = Math.max(0, target[n * G + g] - positive(stocks[n * G + g]) - forecast[n * G + g] * 0.6);
        exportDemand += shortage * 0.4 * openness / (1 + positive(geo.adjLen[j]) / 80);
      }
      const gap = Math.max(0, target[o + g] + Math.min(pop * 0.1, exportDemand) - positive(stocks[o + g]));
      laborWanted[g] = expected[g] > 0 ? Math.min(productionWorkers, gap / Math.max(0.001, productivity[g])) : 0;
      // Unsold inventories and last year's realized return affect next year's
      // hiring. Essential tool/forest recovery retains a small viable path.
      const feedback = bound(0.75 + 0.4 * returns[o + g], 0.2, 1.3) * (0.35 + 0.65 * sellThrough[o + g]);
      weights[g] = expected[g] > 0 && gap > 0 ? margin * expected[g] * bound(feasible, 0, 1) * feedback * (0.25 + capital[o + g] / (capital[o + g] + workers[r])) : 0;
      weightSum += weights[g];
    }
    const maxFarm = productionWorkers * (0.1 + 0.85 * rural / pop);
    let exportDemand = 0;
    for (let j = geo.adjStart[r]; j < geo.adjStart[r + 1]; j++) {
      const n = geo.adj[j];
      const openness = x.edgeOpenness ? bound(positive(x.edgeOpenness[j]), 0, 1.5) : 1;
      if (n >= 0 && n < R) exportDemand += Math.max(0, target[n * G] - positive(stocks[n * G]) - forecast[n * G] * (0.1 + 0.85 * positive(x.rural[n]) / Math.max(1, positive(x.rural[n]) + positive(x.urban[n])))) * 0.4 * openness / (1 + positive(geo.adjLen[j]) / 60);
    }
    const neededFarm = Math.max(0, pop * 1.18 + Math.min(pop * 0.4, exportDemand) - stocks[o]) / Math.max(0.001, expected[0]);
    const farmLabor = Math.min(maxFarm, neededFarm);
    snap.labor[o] = farmLabor;
    let rest = productionWorkers - farmLabor;
    // Capped water filling leaves workers idle when customers already have
    // everything they need; high prices cannot force output into full stores.
    for (let pass = 0; pass < G - 1 && rest > 1e-8 && weightSum > 0; pass++) {
      let allocated = 0;
      for (let g = 1; g < G; g++) {
        const added = Math.min(Math.max(0, laborWanted[g] - snap.labor[o + g]), rest * weights[g] / weightSum);
        snap.labor[o + g] += added; allocated += added;
      }
      rest = Math.max(0, rest - allocated); weightSum = 0;
      for (let g = 1; g < G; g++) { if (snap.labor[o + g] + 1e-7 >= laborWanted[g]) weights[g] = 0; weightSum += weights[g]; }
    }
    for (let g = 0; g < G; g++) {
      planned[o + g] = snap.labor[o + g] * productivity[g];
      // Capital is a physical throughput ceiling; technology improves its use.
      if (g === 0) planned[o] = Math.min(planned[o], landFoodLimit(geo, r) * advantage[0] * (1 + production * 0.1));
      output[o + g] = Math.min(planned[o + g], snap.labor[o + g] * hand[g] + capital[o + g] * (1 + 0.14 * production));
      if (g === 1) output[o + g] = Math.min(output[o + g], landFoodLimit(geo, r) / 1.8 * 0.12 * resource(x, r, 5) / 3);
    }
    // Extraction precedes processing; inputs can come from carried stocks or this
    // year's local extraction. Imports arrive later and can be used next year.
    let repairWood = 0, repairTools = 0, toolFeedstock = 0;
    for (let g = 0; g < G; g++) {
      let made = output[o + g];
      if (g === 3) {
        // Match real wood to available/feasibly hand-made tools before charcoal
        // and workshops can consume all of either material. Nothing is removed
        // from the ledger here; any unexecuted claim returns to consumption.
        const wantedWood = constructionClaim[o + 1], wantedTools = constructionClaim[o + 5];
        const woodPerTool = production >= 0.6 ? 0.7 : 0.5;
        const match = Math.min(1,
          positive(stocks[o + 1]) / Math.max(0.001, wantedWood + Math.max(0, wantedTools - stocks[o + 5]) * woodPerTool),
          (positive(stocks[o + 5]) + output[o + 5] * (production >= 0.6 ? 0.45 : 1)) / Math.max(0.001, wantedTools));
        repairWood = wantedWood * match; repairTools = wantedTools * match;
        toolFeedstock = Math.max(0, repairTools - positive(stocks[o + 5])) * woodPerTool;
      }
      const ingredients = recipe(g, production, coal);
      const spendable = (good: number) => Math.max(0, stocks[o + good] - (good === 1 ? repairWood + (g < 5 ? toolFeedstock : 0) : good === 5 ? repairTools : good === 3 ? pop * 0.016 : 0));
      for (const [good, amount] of ingredients) made = Math.min(made, spendable(good) / amount);
      for (const [good, amount] of ingredients) {
        const used = made * amount; stocks[o + good] = Math.max(0, stocks[o + good] - used); snap.inputs[o + good] += used;
        sectorInputCost[o + g] += used * startPrice[o + good];
      }
      if (g === 5 && production >= 0.6 && made < output[o + g]) {
        // Learning metalworking does not erase the ability to make wooden
        // implements. The unused workshop/labor can use a slower old process;
        // this never fabricates missing ore or metal for the advanced chain.
        const wooden = Math.min((output[o + g] - made) * 0.45, spendable(1) / 0.7);
        stocks[o + 1] = Math.max(0, stocks[o + 1] - wooden * 0.7); snap.inputs[o + 1] += wooden * 0.7; made += wooden;
        sectorInputCost[o + g] += wooden * 0.7 * startPrice[o + 1];
      }
      made = positive(made); stocks[o + g] += made; snap.output[o + g] = made;
      snap.unmetOutput[o + g] = Math.max(0, planned[o + g] - made);
    }
  }

  // Bilateral physical barter clears along existing native edges. A shipment
  // requires an actual counter-shipment: no money faucet or unbacked trade bank.
  const details: EconomyTrade[] = [];
  const tradeTarget = new Float64Array(R * G), basicReserve = new Float64Array(R * G);
  const basicNorm = [1.03, 0.012, 0, 0.016, 0, 0.01, 0.035];
  for (let r = 0; r < R; r++) for (let g = 0; g < G; g++) {
    const i = r * G + g;
    // This year's intermediate orders have already been consumed. Keep a
    // working reserve rather than demanding the same full input twice.
    const nextInputs = Math.max(0, target[i] - snap.desiredConsumption![i]) * 0.3;
    tradeTarget[i] = snap.desiredConsumption![i] + nextInputs;
    basicReserve[i] = population[r] * basicNorm[g] + nextInputs * 0.5;
  }
  const transfer = (from: number, to: number, good: number, shipped: number, lossRate: number) => {
    const a = from * G + good, b = to * G + good, delivered = shipped * (1 - lossRate), lost = shipped - delivered;
    stocks[a] = Math.max(0, stocks[a] - shipped); stocks[b] += delivered; snap.exports[a] += delivered; snap.imports[b] += delivered; snap.transportLoss[a] += lost;
    const value = delivered * prices[a]; result.marketTaxBase[from] += value;
    details.push({ from, to, good, quantity: delivered, value, cost: lost * prices[a] });
  };
  for (let a = 0; a < R; a++) {
    if (!population[a]) continue;
    for (let j = geo.adjStart[a]; j < geo.adjStart[a + 1]; j++) {
      const b = geo.adj[j];
      if (b <= a || b >= R || !population[b]) continue;
      const openness = x.edgeOpenness ? bound(positive(x.edgeOpenness[j]), 0, 1.5) : 1;
      if (openness === 0) continue;
      const kind = geo.adjKind[j], move = Math.min(positive(x.capabilities[a * 5 + 1]), positive(x.capabilities[b * 5 + 1]));
      if (kind >= 3 && !(x.port?.[a] && x.port?.[b]) && move < 1.7) continue;
      const terrain = kind === 2 ? 2.8 : kind === 4 ? 0.55 : kind === 3 ? 0.9 : kind === 1 ? 0.7 : 1;
      const road = x.road?.[a] && x.road?.[b] ? 0.65 : 1;
      const frontier = x.owner[a] !== x.owner[b] ? 1.4 : 1;
      const travel = positive(geo.adjLen[j]) * terrain * road * frontier / (1 + 0.25 * move);
      const infrastructure = 1 + Math.min(3, (transport[a] / Math.max(1, population[a]) + transport[b] / Math.max(1, population[b])) * 2);
      const lossRate = bound(0.015 + travel / (4000 * infrastructure), 0.015, 0.65);
      const disruption = 1 + positive(x.war?.[a]) + positive(x.war?.[b]);
      const haulProductivity = 12 * (1 + move * 0.25) * infrastructure / ((1 + travel / 60) * disruption);
      const availableHaulers = Math.min(Math.max(0, workers[a] * 0.02 - snap.transportLabor![a]), Math.max(0, workers[b] * 0.02 - snap.transportLabor![b]));
      let capacity = Math.min(Math.min(population[a], population[b]) * (0.05 + 0.025 * move) * infrastructure * openness / ((1 + travel / 60) * disruption), availableHaulers * haulProductivity * 2);
      for (let g = 0; g < G && capacity > 1e-9; g++) {
        const ai = a * G + g, bi = b * G + g;
        const as = stocks[ai] - tradeTarget[ai], bs = stocks[bi] - tradeTarget[bi];
        const from = as > 0 && bs < 0 ? a : bs > 0 && as < 0 ? b : -1;
        if (from < 0) continue;
        const to = from === a ? b : a, so = from * G, bo = to * G;
        let wanted = Math.min(stocks[so + g] - tradeTarget[so + g], (tradeTarget[bo + g] - stocks[bo + g]) / (1 - lossRate), capacity);
        if (!(wanted > 0)) continue;
        // The recipient pays with a real surplus that the supplier actually
        // lacks. Counter-good value equals original value before transport loss.
        for (let pay = G - 1; pay >= 0 && wanted > 1e-9; pay--) {
          if (pay === g) continue;
          // A hungry buyer may exchange discretionary consumption above a
          // basic basket. This avoids requiring two full-reserve surpluses to
          // coincide, while both parties still receive goods they can use.
          const surplus = stocks[bo + pay] - basicReserve[bo + pay], need = tradeTarget[so + pay] - stocks[so + pay];
          if (!(surplus > 0 && need > 0)) continue;
          const ratio = prices[so + g] / prices[bo + pay];
          const quantity = Math.min(wanted, surplus / ratio, need / ((1 - lossRate) * ratio), capacity / (1 + ratio));
          if (!(quantity > 1e-9)) continue;
          transfer(from, to, g, quantity, lossRate); transfer(to, from, pay, quantity * ratio, lossRate);
          const hauling = quantity * (1 + ratio) / (2 * haulProductivity);
          snap.transportLabor![a] += hauling; snap.transportLabor![b] += hauling;
          wanted -= quantity; capacity -= quantity * (1 + ratio);
        }
      }
    }
  }
  // Display retention is bounded, aggregate ledgers include every delivery.
  details.sort((a, b) => b.value - a.value || a.from - b.from || a.to - b.to || a.good - b.good);
  snap.trade = details.slice(0, MAX_TRADE_DETAILS);

  for (let r = 0; r < R; r++) {
    const o = r * G, pop = population[r];
    const eaten = Math.min(Math.max(0, stocks[o]), pop);
    stocks[o] = Math.max(0, stocks[o] - eaten); snap.consumption[o] = eaten;
    const adequacy = pop > 0 ? bound(eaten / pop, 0, 1) : 1;
    result.foodAdequacy[r] = adequacy; result.shortage[r] = 1 - adequacy;
    state.foodAdequacy[r] = adequacy;
    // Absolute native capacity adjusts to actual delivered food per observed
    // inhabitant. No floor maintains an unfed 30% population indefinitely.
    const foodAvailable = eaten + stocks[o];
    const capacityChange = pop > 0 ? bound(1 + 0.10 * (foodAvailable / pop - 1.05), 0.90, 1.01) : 1;
    result.capacityFactor[r] = state.capacityFactor[r] = bound(state.capacityFactor[r] * capacityChange, 0, 1);
    result.urbanPopulationFactor[r] = result.capacityFactor[r];
    // Food and basic heating precede investment. Tools, durable wood goods and
    // discretionary consumption can be deferred for executable maintenance.
    const basicHeating = Math.min(positive(stocks[o + 3]), pop * 0.016);
    stocks[o + 3] -= basicHeating; snap.consumption[o + 3] = basicHeating;
    // Replacement and expansion consume actual wood, tools and (for advanced
    // plant) metal. There is no interest, free capital growth or guaranteed profit.
    const production = positive(x.capabilities[r * 5]);
    advantages(x, geo, r, advantage);
    let buildingLabor = workers[r] * 0.08 * adequacy;
    const budget = positive(x.publicBudget?.[r]), priority = Math.floor(positive(x.publicPriority?.[r]));
    if (budget > 0 && buildingLabor > 0 && pop > 0) {
      // Public works purchase actual local materials and construction time.
      // Infrastructure affects existing edges next year; it creates no route.
      let sector = 0;
      if (priority === 2 || priority === 0) {
        let best = -Infinity;
        for (let g = 1; g < G; g++) {
          if (!(advantage[g] > 0)) continue;
          // Choose an executable engineering process, rather than repeatedly
          // requesting an impossible advanced mill while upstream can recover.
          if (production >= 1.5 && g === 6 && !(stocks[o + 4] > 0)) continue;
          if (g === 4 && !(stocks[o + 4] > 0 || stocks[o + 2] > 0)) continue;
          const gap = Math.max(0, target[o + g] - stocks[o + g]);
          const score = advantage[g] * gap / Math.max(1, target[o + g]) * bound(1 + returns[o + g], 0.1, 2);
          if (score > best) { best = score; sector = g; }
        }
      } else if (priority === 4 && adequacy >= 0.99) sector = resource(x, r, 5) > 0 ? 1 : 0;
      const viable = priority === 3 || advantage[sector] > 0;
      const metalPlant = production >= 1.5 && priority !== 3 && sector === 6;
      const basicCost = 0.65 * prices[o + 1] + 0.11 * prices[o + 5] + 1;
      const basicWork = Math.min(budget / basicCost, buildingLabor, positive(stocks[o + 1]) / 0.65, positive(stocks[o + 5]) / 0.11);
      // Native high technology never erases earth/wood construction. A full
      // metal set improves efficiency; smelters/advanced mills must have it.
      const equipped = production >= 1.5 && (metalPlant || positive(stocks[o + 4]) >= Math.max(0.001, basicWork * 0.06));
      const earthenFurnace = priority !== 3 && sector === 4 && !equipped;
      const wood = equipped ? 0.5 : earthenFurnace ? 0.8 : 0.65, tools = equipped ? 0.09 : earthenFurnace ? 0.12 : 0.11;
      const metal = equipped ? 0.06 : 0, ore = earthenFurnace ? 0.3 : 0, constructionRate = equipped ? 1.6 : earthenFurnace ? 0.6 : 1;
      const unitCost = wood * prices[o + 1] + tools * prices[o + 5] + metal * prices[o + 4] + ore * prices[o + 2] + 1 / constructionRate;
      const work = viable ? Math.min(budget / unitCost, buildingLabor * constructionRate, positive(stocks[o + 1]) / wood, positive(stocks[o + 5]) / tools, metal ? positive(stocks[o + 4]) / metal : Infinity, ore ? positive(stocks[o + 2]) / ore : Infinity) : 0;
      if (work > 0) {
        for (const [good, amount] of [[1, wood], [5, tools], [4, metal], [2, ore]]) {
          const used = work * amount; stocks[o + good] = Math.max(0, stocks[o + good] - used); snap.investment[o + good] += used;
        }
        if (priority === 3) transport[r] += work;
        else if (advantage[sector] > 0) capital[o + sector] += work * PRODUCTIVITY[sector] * (earthenFurnace ? 0.35 : 1);
        const labor = work / constructionRate; buildingLabor -= labor; snap.investmentLabor[r] += labor;
        result.publicSpend[r] = Math.min(budget, work * unitCost); snap.publicSpend![r] = result.publicSpend[r];
      }
    }
    if (adequacy > 0.05 && pop > 0) {
      const trial = new Float64Array(G), prospective = new Float64Array(G);
      const coal = resource(x, r, 4) + resource(x, r, 8) > 0;
      for (let g = 0; g < G; g++) {
        const rate = PRODUCTIVITY[g] * (1 + production * 0.1) * advantage[g] * (0.55 + 0.45 * adequacy);
        let unitCost = rate > 0 ? 1 / rate : Infinity, feasible = 1;
        for (const [good, amount] of recipe(g, production, coal)) {
          unitCost += prices[o + good] * amount;
          const actualOrRenewable = positive(stocks[o + good]) + snap.output[o + good];
          feasible = Math.min(feasible, actualOrRenewable / Math.max(0.001, workers[r] * 0.002 * PRODUCTIVITY[g] * amount));
        }
        // Retained wooden-tool knowledge provides a genuine expected recipe.
        if (g === 5 && production >= 0.6 && feasible < 1 && positive(stocks[o + 1]) > 0) {
          const oldCost = 0.7 * prices[o + 1] + 1 / Math.max(0.001, rate * 0.45);
          if (oldCost < unitCost) { unitCost = oldCost; feasible = Math.min(1, stocks[o + 1] / Math.max(0.001, workers[r] * 0.002 * 0.7)); }
        }
        const gap = Math.max(0, target[o + g] - positive(stocks[o + g]));
        prospective[g] = rate > 0 ? bound((prices[o + g] - unitCost) / Math.max(0.01, prices[o + g]), 0, 1) * bound(feasible, 0, 1) : 0;
        trial[g] = gap > 0 ? Math.min(gap, workers[r] * 0.002 * PRODUCTIVITY[g]) * prospective[g] : 0;
      }
      // Prefer scarce capacity with realized demand and operating returns.
      const order = Array.from({ length: G }, (_, g) => g).sort((a, b) => {
        if (adequacy < 0.98 && (a === 0 || b === 0)) return a === 0 ? -1 : 1;
        const score = (g: number) => (prices[o + g] / BASE_PRICE[g]) * advantage[g] * (0.2 + snap.unmetOutput[o + g] / (1 + capital[o + g])) * Math.max(prospective[g], bound(1 + returns[o + g], 0.15, 2) * (0.2 + sellThrough[o + g]));
        return score(b) - score(a) || a - b;
      });
      for (const g of order) {
        if (!(advantage[g] > 0)) continue;
        // Capital units are sector output units. Farm output per worker is much
        // larger than tool output: an identical numerical build cap would make
        // farm replacement permanently smaller than its depreciation.
        let desired = Math.min(workers[r] * 0.08 * PRODUCTIVITY[g], capital[o + g] * 0.08 + workers[r] * 0.002);
        const excess = positive(stocks[o + g] - target[o + g]);
        const realizedDemand = g === 0 ? 1 : sellThrough[o + g] * bound(1 + returns[o + g], 0, 1.5);
        desired *= realizedDemand / (1 + excess / Math.max(0.01, target[o + g]));
        desired = Math.max(desired, trial[g]);
        if (g > 0 && stocks[o + g] >= target[o + g] * 2) desired = 0;
        // Low-tech necessities can be rebuilt with actual hand-made tools.
        // Hungry regions maintain other plant but do not expand its throughput.
        if (adequacy < 0.95 && g !== 0 && g !== 1 && g !== 3 && g !== 5) desired = Math.min(desired, capital[o + g] * DEPRECIATION[g] / (1 - DEPRECIATION[g]));
        const earthenFurnace = g === 4 && stocks[o + 4] < Math.max(0.001, desired * 0.1);
        const wood = earthenFurnace ? 0.6 : 0.35, tools = earthenFurnace ? 0.08 : 0.06;
        const constructionRate = PRODUCTIVITY[g] * (earthenFurnace ? 0.6 : 1);
        let build = Math.min(desired, buildingLabor * constructionRate, Math.max(0, stocks[o + 1] - pop * 0.005) / wood, Math.max(0, stocks[o + 5] - pop * 0.003) / tools);
        const metalPlant = production >= 1.5 && (g === 6 || (g === 4 && !earthenFurnace));
        if (metalPlant) build = Math.min(build, stocks[o + 4] / 0.1);
        if (earthenFurnace) build = Math.min(build, positive(stocks[o + 2]) / 0.25);
        if (!(build > 0)) continue;
        for (const [good, amount] of [[1, wood], [5, tools], ...(metalPlant ? [[4, 0.1]] : []), ...(earthenFurnace ? [[2, 0.25]] : [])]) {
          const used = build * amount; stocks[o + good] = Math.max(0, stocks[o + good] - used); snap.investment[o + good] += used;
        }
        capital[o + g] += build * (earthenFurnace ? 0.35 : 1);
        const labor = build / constructionRate; buildingLabor -= labor; snap.investmentLabor[r] += labor;
      }
    }
    // Claims which could not assemble all materials were never deducted.
    // Remaining goods now serve this same year's deferrable household demand.
    for (const g of [1, 3, 5, 6]) {
      const use = Math.min(positive(stocks[o + g]), Math.max(0, snap.desiredConsumption![o + g] - snap.consumption[o + g]));
      stocks[o + g] = Math.max(0, stocks[o + g] - use); snap.consumption[o + g] += use;
    }
    let totalValue = 0, industrialValue = 0, householdValue = 0, desiredValue = 0, importsValue = 0, actualUse = 0;
    for (let g = 0; g < G; g++) {
      const i = o + g;
      const uses = snap.inputs[i] + snap.consumption[i] + snap.investment[i] + snap.exports[i];
      // Attribution is proportional between carried stock, local output and
      // imports. No inventory revaluation is booked as realized sales/return.
      const supply = Math.max(0, stocks[i]) + uses;
      const realizedShare = supply > 0 ? bound(uses / supply, 0, 1) : 0;
      const usedOutputValue = snap.output[i] * realizedShare * startPrice[i];
      const replacementCost = capital[i] * DEPRECIATION[g] * (0.35 * startPrice[o + 1] + 0.06 * startPrice[o + 5]) / PRODUCTIVITY[g];
      const surplus = usedOutputValue - sectorInputCost[i] - snap.labor[i] - replacementCost - snap.transportLoss[i] * startPrice[i];
      snap.operatingSurplus![i] = surplus;
      returns[i] = bound(surplus / Math.max(0.01, snap.output[i] * startPrice[i]), -2, 2);
      sellThrough[i] = realizedShare;
      const desired = snap.desiredConsumption![i];
      snap.needSatisfaction![i] = desired > 0 ? bound(snap.consumption[i] / desired, 0, 1) : 1;
      householdValue += snap.consumption[i] * BASE_PRICE[g];
      desiredValue += desired * BASE_PRICE[g];
      importsValue += snap.imports[i] * BASE_PRICE[g];
      actualUse += (snap.consumption[i] + snap.inputs[i] + snap.investment[i]) * BASE_PRICE[g];
      stocks[i] = Math.max(0, stocks[i]);
      const lost = stocks[i] * STORAGE_LOSS[g]; stocks[i] -= lost; snap.spoilage[i] = lost;
      // Price is an annual clearing signal in native grain-equivalent units.
      // Food fixes the numeraire, quantities still clear physically by barter.
      const scarcity = (target[i] + 0.01) / (stocks[i] + snap.output[i] * 0.35 + 0.01);
      const wantedPrice = BASE_PRICE[g] * bound(Math.sqrt(scarcity), 0.25, 6);
      prices[i] = g === 0 ? 1 : prices[i] * 0.75 + wantedPrice * 0.25;
      const value = snap.output[i] * BASE_PRICE[g]; totalValue += value; if (g > 0) industrialValue += value;
      snap.inventory[i] = stocks[i]; snap.capital[i] = capital[i]; snap.prices[i] = prices[i];
      snap.unsoldStock![i] = Math.max(0, stocks[i] - tradeTarget[i] * 0.2);
    }
    living[r] = desiredValue > 0 ? bound(householdValue / desiredValue, 0, 1) : 0; snap.livingStandard![r] = living[r];
    snap.importDependence![r] = actualUse > 0 ? bound(importsValue / actualUse, 0, 1) : 0;
    snap.transportCapital![r] = transport[r];
    result.agriculturalTaxBase[r] = snap.output[o];
    // Intermediate inputs use the same constant grain-equivalent valuation as
    // output: a regional value-added tax base cannot mint value from price moves.
    let inputValue = 0;
    for (let g = 0; g < G; g++) inputValue += snap.inputs[o + g] * BASE_PRICE[g];
    result.industrialTaxBase[r] = Math.max(0, industrialValue - inputValue);
    result.outputValue[r] = Math.max(0, totalValue - inputValue);
    snap.foodAdequacy[r] = adequacy; snap.capacityFactor[r] = result.capacityFactor[r]; snap.agriculturalTaxBase[r] = result.agriculturalTaxBase[r];
    snap.industrialTaxBase[r] = result.industrialTaxBase[r]; snap.marketTaxBase[r] = result.marketTaxBase[r]; snap.outputValue[r] = result.outputValue[r];
    state.previousPopulation[r] = pop;
  }
  state.year = x.year; model.result = result; remember(model, snap);
  return result;
}
