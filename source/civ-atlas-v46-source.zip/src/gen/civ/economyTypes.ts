/** Native annual regional economy. No independent clock, inhabitants or treasury. */
export interface EconomyGeography {
  count: number;
  capacity: ArrayLike<number>;
  area: ArrayLike<number>;
  biome: ArrayLike<number>;
  elevation: ArrayLike<number>;
  adjStart: ArrayLike<number>;
  adj: ArrayLike<number>;
  adjKind: ArrayLike<number>;
  adjLen: ArrayLike<number>;
}

export interface EconomyYearInput {
  year: number;
  /** Native observed inhabitants, in thousands; never written by this module. */
  rural: ArrayLike<number>;
  urban: ArrayLike<number>;
  owner: ArrayLike<number>;
  /** Native development capabilities, R × 5. */
  capabilities: ArrayLike<number>;
  /** Native resource grades and currently usable availability, R × 11. */
  resources: ArrayLike<number>;
  available: ArrayLike<number>;
  soil?: ArrayLike<number>;
  war?: ArrayLike<number>;
  road?: ArrayLike<number>;
  port?: ArrayLike<number>;
  /** Native treasury grant ceiling, grain-equivalent; only actual work is spent. */
  publicBudget?: ArrayLike<number>;
  /** 0 ordinary, 1 food, 2 industry, 3 logistics, 4 resilience. */
  publicPriority?: ArrayLike<number>;
  /** Native directed adjacency openness: 0 blockade, 1 normal, up to 1.5. */
  edgeOpenness?: ArrayLike<number>;
}

export interface EconomyTrade {
  from: number;
  to: number;
  good: number;
  /** Actual delivered quantity; exports/imports both record this quantity. */
  quantity: number;
  /** Grain-equivalent value at the producer's annual market price. */
  value: number;
  /** Grain-equivalent transport loss, not newly created money. */
  cost: number;
}

export interface EconomySnapshot {
  year: number;
  count: number;
  population: Float32Array;
  owner: Int16Array;
  rural: Float32Array;
  urban: Float32Array;
  /** R × 7 goods: food/timber/ore/fuel/metal/tools/manufactures. */
  output: Float32Array;
  inputs: Float32Array;
  consumption: Float32Array;
  inventory: Float32Array;
  prices: Float32Array;
  /** R × 7 sectors, in annual physical output capacity. */
  capital: Float32Array;
  /** Employed native population, thousands. Sum ≤ 52% of total inhabitants. */
  labor: Float32Array;
  /** R, construction/repair workforce already reserved from the 52% total. */
  investmentLabor: Float32Array;
  imports: Float32Array;
  exports: Float32Array;
  /** Explicit once-only pioneer stock additions, never an annual subsidy. */
  endowment: Float32Array;
  investment: Float32Array;
  spoilage: Float32Array;
  transportLoss: Float32Array;
  /** R × 7 unfilled desired output because inputs, capital or labor were scarce. */
  unmetOutput: Float32Array;
  /** R arrays. Food need is thousand shi; annual food norm = 1 shi/person. */
  foodNeed: Float32Array;
  foodAdequacy: Float32Array;
  capacityFactor: Float32Array;
  agriculturalTaxBase: Float32Array;
  industrialTaxBase: Float32Array;
  marketTaxBase: Float32Array;
  outputValue: Float32Array;
  /** Optional only for legacy snapshots; current ticks always record these. */
  desiredConsumption?: Float32Array;
  needSatisfaction?: Float32Array;
  /** Realized grain-equivalent operating-return estimate, NOT monetary profit. */
  operatingSurplus?: Float32Array;
  /** Physical inventory above the next year's working reserve. */
  unsoldStock?: Float32Array;
  publicSpend?: Float32Array;
  transportCapital?: Float32Array;
  transportLabor?: Float32Array;
  /** Actual / desired constant-price household consumption, bounded 0..1. */
  livingStandard?: Float32Array;
  /** Delivered imports / actual household+input+investment use, constant value, 0..1. */
  importDependence?: Float32Array;
  /** Largest 512 physical deliveries for display; aggregates above include ALL. */
  trade: EconomyTrade[];
}

export interface EconomyYearResult {
  foodAdequacy: Float64Array;
  capacityFactor: Float64Array;
  agriculturalTaxBase: Float64Array;
  industrialTaxBase: Float64Array;
  marketTaxBase: Float64Array;
  outputValue: Float64Array;
  /** Actual public construction outflow, <= the supplied treasury ceiling. */
  publicSpend: Float64Array;
  shortage: Float64Array;
  /** Absolute sustainable city-capacity multiplier, NOT an annual survival rate. */
  urbanPopulationFactor: Float64Array;
  snapshot: EconomySnapshot;
}

export interface EconomyState {
  /** Last native integer year actually consumed, null before first annual tick. */
  year: number | null;
  count: number;
  historyEvery: number;
  inventory: Float64Array;
  capital: Float64Array;
  prices: Float64Array;
  /** Observed last native population, a diagnostic; not a simulated population. */
  previousPopulation: Float64Array;
  activated: Uint8Array;
  foodAdequacy: Float64Array;
  capacityFactor: Float64Array;
  /** Optional for old v1 saves; restored as zero physical infrastructure. */
  transportCapital?: Float64Array;
  /** Last realized sector return per output-value unit; no money balances. */
  operatingReturn?: Float64Array;
  sellThrough?: Float64Array;
  livingStandard?: Float64Array;
}

export interface NativeEconomy {
  version: 1;
  units: 'thousand-shi grain-equivalent';
  state: EconomyState;
  history: EconomySnapshot[];
  /** Exact last result, including fiscal bases; retained across continuation. */
  result: EconomyYearResult;
}

export interface NativeEconomyModel {
  geography: EconomyGeography;
  state: EconomyState;
  history: EconomySnapshot[];
  result: EconomyYearResult;
}
