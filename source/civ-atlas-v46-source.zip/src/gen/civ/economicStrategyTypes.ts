import type { EconomySnapshot } from './economyTypes';

/** Project codes consumed by the native annual physical economy. */
export type EconomicPriority = 0 | 1 | 2 | 3 | 4;
export type EconomicReason = 'food_shortage' | 'tool_bottleneck' | 'material_shortage' | 'trade_dependence' | 'fiscal_stress' | 'industry_opportunity' | 'logistics_gap' | 'war_risk' | 'manual_policy' | 'no_observation' | 'idle_capacity';

export interface EconomicStrategyInput {
  year: number;
  owner: ArrayLike<number>;
  /** Last completed native annual observation only, never the year being planned. */
  snapshot?: EconomySnapshot;
  /** All following arrays use native country IDs. No treasury is held here. */
  treasury: ArrayLike<number>;
  income: ArrayLike<number>;
  committedExpenses: ArrayLike<number>;
  war?: ArrayLike<number>;
  rulerTrade?: ArrayLike<number>;
  rulerWar?: ArrayLike<number>;
  rulerDevelop?: ArrayLike<number>;
  /** Explicit native development Cap focus: -1 none, 0 production, 1 transport,
   * 2 information, 3 administration, 4 mobilization. Takes precedence over AI. */
  focus?: ArrayLike<number>;
  /** Explicit native signed policy knobs, -50..50. */
  policyWar?: ArrayLike<number>;
  policyPeace?: ArrayLike<number>;
}

export interface EconomicStrategyDecision {
  country: number;
  year: number;
  sourceYear: number | null;
  priority: EconomicPriority;
  reasons: EconomicReason[];
  posture: 'relief' | 'investment' | 'trade' | 'austerity' | 'resilience';
  plannedBudget: number;
  /** Actual native physical project cost, populated by finishEconomicStrategy. */
  publicSpend: number;
  freeTreasury: number;
  fiscalStress: number;
  foodAdequacy: number;
  importDependence: number;
  /** Economic ability to sustain offensive war, 0.05..1; not military power. */
  warReadiness: number;
  topScarceGood: number;
  /** Partner and region refer only to recorded actual native deliveries. */
  tradePartner?: number;
  supplyRegion?: number;
  /** Seven goods; cached for constant-size candidate valuation. */
  scarcity: Float32Array;
  demand: Float64Array;
  supply: Float64Array;
}

/** Directional economic ties from the recorded delivery detail. Missing records
 * do not mean no imports: country importDependence uses ALL aggregate imports. */
export interface EconomicRelation {
  from: number;
  to: number;
  importValue: number;
  exportValue: number;
  scarceImportValue: number;
  importDependence: number;
  complementarity: number;
  warOpportunity: number;
  warOpportunityCost: number;
  peaceValue: number;
  allianceValue: number;
}

export interface EconomicStrategySnapshot {
  year: number;
  sourceYear: number | null;
  publicBudget: Float64Array;
  publicPriority: Uint8Array;
  publicSpend: Float64Array;
  countries: EconomicStrategyDecision[];
  relations: EconomicRelation[];
  /** R × 7 observed output + surviving stocks; no fabricated resource grades. */
  regionSupply: Float32Array;
  /** R observed war damage / food stress, used in candidate expansion valuation. */
  regionRisk: Float32Array;
}

export interface NativeEconomicStrategy {
  version: 1;
  count: number;
  year: number | null;
  historyEvery: number;
  latest?: EconomicStrategySnapshot;
  history: EconomicStrategySnapshot[];
}

/** Contains no separate people, clock, money or physical production state. The
 * observed native year merely guards duplicate annual planning. */
export type EconomicStrategyState = NativeEconomicStrategy;

export interface EconomicStrategyPlan {
  publicBudget: Float64Array;
  publicPriority: Uint8Array;
  decisions: EconomicStrategyDecision[];
}
