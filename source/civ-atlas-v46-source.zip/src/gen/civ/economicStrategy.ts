/**
 * Native annual economic statecraft. This module observes the LAST completed
 * physical economy and allocates only prior native treasury after commitments.
 * It never manufactures money, goods, labor, population or future tax receipts.
 * Projects remain requests: the annual economy must find actual inputs/workers,
 * and finishEconomicStrategy records only the expenditure it really executed.
 *
 * Cost is O(R * 7 + recorded deliveries); no global country-pair matrix. Country
 * and directional relation lookups are cached outside exported plain data.
 * Shortages and prices influence choices without imposing prosperity: famine
 * can coexist with zero budget, failed construction and a shrinking economy.
 */
import type { EconomySnapshot } from './economyTypes';
import type { EconomicPriority, EconomicReason, EconomicRelation, EconomicStrategyDecision, EconomicStrategyInput, EconomicStrategyPlan, EconomicStrategySnapshot, EconomicStrategyState, NativeEconomicStrategy } from './economicStrategyTypes';

const G = 7;
const BASE_PRICE = [1, 0.6, 0.9, 0.5, 2.5, 4, 2.2];
const LIMIT = 64;
const pos = (x: number | undefined): number => Number.isFinite(x) && x! > 0 ? x! : 0;
const unit = (x: number): number => Math.min(1, Math.max(0, x));
const validCountry = (x: number): boolean => Number.isSafeInteger(x) && x >= 0;
const read = (a: ArrayLike<number> | undefined, i: number): number => pos(a?.[i]);
const preference = (a: ArrayLike<number> | undefined, i: number): number => a && Number.isFinite(a[i]) ? unit(a[i] / 100) : 0.5;

interface Lookup { latest: EconomicStrategySnapshot; countries: Map<number, EconomicStrategyDecision>; relations: Map<number, Map<number, EconomicRelation>> }
const lookups = new WeakMap<EconomicStrategyState, Lookup>();

function lookup(state: EconomicStrategyState): Lookup | undefined {
  const latest = state.latest;
  if (!latest) return undefined;
  const old = lookups.get(state);
  if (old?.latest === latest) return old;
  const out: Lookup = { latest, countries: new Map(), relations: new Map() };
  for (const c of latest.countries) out.countries.set(c.country, c);
  for (const r of latest.relations) {
    let from = out.relations.get(r.from);
    if (!from) out.relations.set(r.from, from = new Map());
    from.set(r.to, r);
  }
  lookups.set(state, out);
  return out;
}

/** Deep copy restoration: planning/finishing a resumed simulation cannot mutate
 * its source save, including the current unsampled decision tail. */
export function createEconomicStrategy(saved?: NativeEconomicStrategy, count = saved?.count ?? 0): EconomicStrategyState {
  if (!Number.isSafeInteger(count) || count < 0) throw new Error('Invalid economic strategy region count');
  if (!saved) return { version: 1, count, year: null, historyEvery: 20, history: [] };
  const out = structuredClone(saved);
  out.count = count;
  out.historyEvery = saved.historyEvery || 20;
  return out;
}

/** No Map/Set or live input buffers escape into native saves. */
export function exportEconomicStrategy(state: EconomicStrategyState): NativeEconomicStrategy {
  return structuredClone(state);
}

/** Discrete historical observation; never interpolates future decisions. */
export function economicStrategyAt(civ: { development?: { economicStrategy?: NativeEconomicStrategy } }, year: number): EconomicStrategySnapshot | undefined {
  const saved = civ.development?.economicStrategy;
  if (!saved) return undefined;
  const latest = saved.latest;
  if (latest && latest.year <= year) return latest;
  const list = saved.history;
  let lo = 0, hi = list.length;
  while (lo < hi) { const m = (lo + hi) >>> 1; if (list[m].year <= year) lo = m + 1; else hi = m; }
  return lo ? list[lo - 1] : undefined;
}

function remember(state: EconomicStrategyState, next: EconomicStrategySnapshot): void {
  const list = state.history;
  if (list.length > 1 && list[list.length - 1].year % state.historyEvery) list.pop();
  list.push(next);
  if (list.length > LIMIT) {
    state.historyEvery *= 2;
    state.history = list.filter((x, i) => i === 0 || i === list.length - 1 || x.year % state.historyEvery === 0);
  }
}

interface RegionSignal {
  observed: boolean;
  population: number;
  food: number;
  dependence: number;
  tool: number;
  material: number;
  idle: number;
  logistics: number;
  industry: number;
  risk: number;
  scarcity: Float64Array;
  demand: Float64Array;
  supply: Float64Array;
}

/** These optional observations were added after the original native saves. */
type ObservedSnapshot = EconomySnapshot & {
  importDependence?: ArrayLike<number>;
  operatingSurplus?: ArrayLike<number>;
  transportCapital?: ArrayLike<number>;
};

function observe(s: ObservedSnapshot | undefined, r: number, war: boolean): RegionSignal {
  const scarcity = new Float64Array(G), demand = new Float64Array(G), supply = new Float64Array(G);
  const empty: RegionSignal = { observed: false, population: 0, food: 1, dependence: 0, tool: 0, material: 0, idle: 0, logistics: 0, industry: 0, risk: war ? 1 : 0, scarcity, demand, supply };
  if (!s || r >= s.count) return empty;
  const population = read(s.population, r), need = read(s.foodNeed, r);
  if (!population) return empty;
  const food = need ? unit(read(s.foodAdequacy, r)) : 1;
  let imports = 0, uses = 0, workers = 0, stockValue = 0, unmet = 0, activity = 0, operatingSurplus = 0;
  for (let g = 0; g < G; g++) {
    const i = r * G + g, price = read(s.prices, i) || BASE_PRICE[g];
    const use = read(s.inputs, i) + read(s.consumption, i) + read(s.investment, i);
    const stock = read(s.inventory, i), output = read(s.output, i), gap = read(s.unmetOutput, i);
    demand[g] = Math.max(g === 0 ? need : 0, use, population * (g === 0 ? 1 : 0.005));
    supply[g] = stock + output;
    const shortage = unit(gap / Math.max(1, output + gap));
    const thinStock = 1 - unit(stock / Math.max(1, demand[g] * 0.35));
    const expensive = unit((price / BASE_PRICE[g] - 1) / 2);
    // Prices alone signal pressure, not actual physical scarcity. Lack of stock
    // receives weight only when there is real use or foregone output.
    scarcity[g] = unit(0.5 * shortage + 0.3 * expensive + 0.2 * thinStock * unit((use + gap) / Math.max(1, population * 0.02)));
    if (g === 0) scarcity[g] = Math.max(scarcity[g], 1 - food);
    imports += read(s.imports, i) * price;
    uses += use * price;
    workers += read(s.labor, i);
    operatingSurplus += read(s.operatingSurplus, i);
    if (g > 0) { stockValue += stock * price; unmet += gap * price; activity += output * price; }
  }
  // Aggregate imports include domestic transfers: cross-country dependence is
  // calculated nationally below from owner-aware regional trade accounting.
  const dependence = s.importDependence ? unit(read(s.importDependence, r)) : unit(imports / Math.max(1, uses));
  const idle = unit(1 - (workers + read(s.investmentLabor, r)) / Math.max(1, population * 0.52));
  const tool = unit(scarcity[5] * (0.5 + 0.5 * unit(unmet / Math.max(1, activity + unmet))));
  const material = Math.max(scarcity[1], scarcity[2], scarcity[3], scarcity[4]);
  const stockOpportunity = unit(stockValue / Math.max(1, population * 0.25));
  const logistics = unit(0.6 * dependence + 0.4 * material * (0.4 + 0.6 * food));
  const surplus = s.operatingSurplus ? unit(operatingSurplus / Math.max(1, activity)) : unit((food - 0.85) / 0.15);
  const industry = unit(food * (0.35 * stockOpportunity + 0.35 * idle + 0.3 * surplus) * (1 - 0.6 * material));
  return { observed: true, population, food, dependence, tool, material, idle, logistics, industry, risk: Math.max(war ? 1 : 0, 1 - food), scarcity, demand, supply };
}

interface CountryWork {
  decision: EconomicStrategyDecision;
  regions: number[];
  people: number;
  food: number;
  imports: number;
  uses: number;
  observed: boolean;
  priorityWeight: Float64Array;
  budgetWeight: number;
}

function newCountry(country: number, x: EconomicStrategyInput, sourceYear: number | null): CountryWork {
  const treasury = read(x.treasury, country), income = read(x.income, country), committed = read(x.committedExpenses, country), war = read(x.war, country) > 0;
  // Reserve an entire committed native annual bill (1.5 at war), PLUS the
  // observed operating deficit. Income can reduce a buffer; it is never spent.
  const reserve = committed * (war ? 1.5 : 1) + Math.max(0, committed - income);
  const freeTreasury = Math.max(0, treasury - reserve);
  const fiscalStress = unit(Math.max(0, committed - income) / Math.max(1, committed) + 0.75 * Math.max(0, reserve - treasury) / Math.max(1, reserve));
  const decision: EconomicStrategyDecision = { country, year: x.year, sourceYear, priority: 0, reasons: [], posture: 'austerity', plannedBudget: 0, publicSpend: 0, freeTreasury, fiscalStress,
    foodAdequacy: 1, importDependence: 0, warReadiness: 1, topScarceGood: 0, scarcity: new Float32Array(G), demand: new Float64Array(G), supply: new Float64Array(G) };
  return { decision, regions: [], people: 0, food: 0, imports: 0, uses: 0, observed: false, priorityWeight: new Float64Array(5), budgetWeight: 0 };
}

function addReason(d: EconomicStrategyDecision, reason: EconomicReason): void {
  if (!d.reasons.includes(reason)) d.reasons.push(reason);
}

function priority(c: CountryWork, signal: RegionSignal, x: EconomicStrategyInput): { code: EconomicPriority; urgency: number } {
  const d = c.decision, country = d.country, war = read(x.war, country) > 0;
  const trade = preference(x.rulerTrade, country), develop = preference(x.rulerDevelop, country);
  const hawkish = unit(preference(x.rulerWar, country) + (x.policyWar?.[country] ?? 0) / 100);
  const settle = unit(hawkish + (x.policyPeace?.[country] ?? 0) / 100);
  const scores = [0.08, 4.5 * (1 - signal.food) + 0.35 * signal.tool,
    0.5 * signal.tool + signal.industry * (0.8 + develop) + signal.idle * 0.2,
    signal.logistics * (0.5 + trade) + signal.material * 0.3,
    (war ? 0.8 + 0.6 * settle : 0.25 * hawkish) + signal.dependence * (1 - trade) * 0.5 + d.fiscalStress * 0.25];
  if (signal.food < 0.9) addReason(d, 'food_shortage');
  if (signal.tool > 0.3) addReason(d, 'tool_bottleneck');
  if (signal.material > 0.4) addReason(d, 'material_shortage');
  if (signal.dependence > 0.25) addReason(d, 'trade_dependence');
  if (signal.logistics > 0.3) addReason(d, 'logistics_gap');
  if (signal.industry > 0.35) addReason(d, 'industry_opportunity');
  if (signal.idle > 0.3) addReason(d, 'idle_capacity');
  if (war) addReason(d, 'war_risk');
  const focus = x.focus?.[country];
  let code: EconomicPriority = 0;
  for (let k = 1; k < scores.length; k++) if (scores[k] > scores[code]) code = k as EconomicPriority;
  if (focus !== undefined && focus >= 0 && focus <= 4) {
    // Native author interventions win. They do not bypass food/material/labor
    // constraints: impossible industry still spends zero in the physical core.
    code = focus === 1 ? 3 : focus >= 3 ? 4 : 2;
    addReason(d, 'manual_policy');
  }
  return { code, urgency: Math.max(0.1, scores[code], 1 - signal.food) };
}

/** Observe prior supply and choose an actual native annual project request.
 * Same native year is idempotent; skipped/reversed years are integration errors. */
export function planEconomicStrategy(state: EconomicStrategyState, x: EconomicStrategyInput): EconomicStrategyPlan {
  if (!Number.isSafeInteger(x.year) || x.year < 0) throw new Error('Economic strategy requires a native integer year');
  if (state.year === x.year && state.latest) return { publicBudget: state.latest.publicBudget, publicPriority: state.latest.publicPriority, decisions: state.latest.countries };
  if (state.year !== null && x.year !== state.year + 1) throw new Error(`Native economic strategy clock gap: ${state.year} → ${x.year}`);
  if (x.owner.length < state.count) throw new Error('Economic strategy owner input is shorter than its regional dimension');
  if (x.snapshot && x.snapshot.year >= x.year) throw new Error('Economic strategy cannot observe current or future output');
  const R = state.count, sourceYear = x.snapshot?.year ?? null;
  const next: EconomicStrategySnapshot = { year: x.year, sourceYear, publicBudget: new Float64Array(R), publicPriority: new Uint8Array(R), publicSpend: new Float64Array(R), countries: [], relations: [], regionSupply: new Float32Array(R * G), regionRisk: new Float32Array(R) };
  const countries = new Map<number, CountryWork>(), signals: RegionSignal[] = new Array(R), urgency = new Float64Array(R);
  for (let r = 0; r < R; r++) {
    const p = x.owner[r];
    const signal = observe(x.snapshot, r, read(x.war, p) > 0);
    signals[r] = signal;
    next.regionSupply.set(signal.supply, r * G);
    next.regionRisk[r] = signal.risk;
    if (!validCountry(p)) continue;
    let c = countries.get(p);
    if (!c) countries.set(p, c = newCountry(p, x, sourceYear));
    c.regions.push(r);
    c.observed ||= signal.observed;
    c.people += signal.population;
    c.food += signal.population * signal.food;
    for (let g = 0; g < G; g++) {
      const d = c.decision, i = r * G + g;
      d.scarcity[g] += signal.scarcity[g] * signal.population;
      d.demand[g] += signal.demand[g];
      d.supply[g] += signal.supply[g];
      if (x.snapshot && signal.observed) {
        const price = read(x.snapshot.prices, i) || BASE_PRICE[g];
        c.imports += read(x.snapshot.imports, i) * price;
        c.uses += signal.demand[g] * price;
      }
    }
    if (!signal.observed) continue;
    const selected = priority(c, signal, x);
    next.publicPriority[r] = selected.code;
    urgency[r] = selected.urgency;
    c.priorityWeight[selected.code] += signal.population * selected.urgency;
    c.budgetWeight += signal.population * selected.urgency;
  }
  // Native imports also include domestic shipments. Remove every KNOWN domestic
  // delivery from the all-delivery aggregate; unrecorded detail remains unknown,
  // and cannot be assigned to a foreign partner with invented precision.
  for (const t of x.snapshot?.trade ?? []) {
    if (!(t.quantity > 0) || t.from < 0 || t.to < 0 || t.from >= R || t.to >= R) continue;
    const a = x.owner[t.from], b = x.owner[t.to];
    if (x.snapshot!.owner[t.from] !== a || x.snapshot!.owner[t.to] !== b) continue;
    if (a !== b) continue;
    const c = countries.get(a);
    if (c) c.imports = Math.max(0, c.imports - t.quantity * (read(x.snapshot?.prices, t.to * G + t.good) || BASE_PRICE[t.good] || 1));
  }
  for (const c of [...countries.values()].sort((a, b) => a.decision.country - b.decision.country)) {
    const d = c.decision, p = d.country;
    d.foodAdequacy = c.people ? c.food / c.people : 1;
    d.importDependence = unit(c.imports / Math.max(1, c.uses));
    for (let g = 0; g < G; g++) {
      d.scarcity[g] /= Math.max(1, c.people);
      if (d.scarcity[g] > d.scarcity[d.topScarceGood]) d.topScarceGood = g;
    }
    if (!c.observed) addReason(d, 'no_observation');
    if (d.fiscalStress > 0.1 || !d.freeTreasury) addReason(d, 'fiscal_stress');
    if (d.importDependence > 0.25) addReason(d, 'trade_dependence');
    for (let k = 1; k < 5; k++) if (c.priorityWeight[k] > c.priorityWeight[d.priority]) d.priority = k as EconomicPriority;
    d.warReadiness = Math.max(0.05, (0.12 + 0.88 * d.foodAdequacy ** 2) * (1 - 0.65 * d.fiscalStress));
    const develop = preference(x.rulerDevelop, p), war = read(x.war, p) > 0;
    const urgencyRate = Math.min(3, c.budgetWeight / Math.max(1, c.people));
    const spendingFraction = (0.10 + 0.16 * develop + 0.04 * urgencyRate) * (1 - 0.65 * d.fiscalStress) * (war ? 0.65 : 1);
    // Each local request has a physical-scale demand ceiling; unlimited native
    // savings do not cause unlimited spending on a tiny province.
    let ceiling = 0;
    for (const r of c.regions) ceiling += signals[r].population * (0.015 + 0.055 * Math.min(3, urgency[r]));
    const envelope = c.observed ? Math.min(d.freeTreasury * spendingFraction, ceiling) : 0;
    let remaining = envelope, remainingWeight = c.budgetWeight;
    for (const r of c.regions) {
      const weight = signals[r].population * urgency[r];
      if (!weight || !remainingWeight) continue;
      const amount = Math.min(remaining, remaining * (weight / remainingWeight));
      next.publicBudget[r] = amount;
      d.plannedBudget += amount;
      remaining -= amount;
      remainingWeight = Math.max(0, remainingWeight - weight);
    }
    d.posture = d.plannedBudget <= 0 ? (d.importDependence > 0.15 ? 'trade' : 'austerity') : d.priority === 1 ? 'relief' : d.priority === 4 ? 'resilience' : d.priority === 3 ? 'trade' : 'investment';
    next.countries.push(d);
  }
  next.relations = buildRelations(next.countries, x.snapshot, x.owner, R);
  state.latest = next;
  state.year = x.year;
  remember(state, next);
  return { publicBudget: next.publicBudget, publicPriority: next.publicPriority, decisions: next.countries };
}

function complement(from: EconomicStrategyDecision, supply: ArrayLike<number>): number {
  let score = 0, scarcity = 0;
  for (let g = 0; g < G; g++) {
    const weight = from.scarcity[g] * (g === 0 ? 2 : 1);
    scarcity += weight;
    score += weight * unit(read(supply, g) / Math.max(1, from.demand[g]));
  }
  return scarcity ? unit(score / scarcity) : 0;
}

function buildRelations(countries: EconomicStrategyDecision[], s: EconomySnapshot | undefined, owner: ArrayLike<number>, R: number): EconomicRelation[] {
  const byCountry = new Map(countries.map(c => [c.country, c]));
  const pairs = new Map<number, Map<number, EconomicRelation>>();
  const row = (a: number, b: number): EconomicRelation => {
    let from = pairs.get(a);
    if (!from) pairs.set(a, from = new Map());
    let relation = from.get(b);
    if (!relation) from.set(b, relation = { from: a, to: b, importValue: 0, exportValue: 0, scarceImportValue: 0, importDependence: 0, complementarity: 0, warOpportunity: 0, warOpportunityCost: 0, peaceValue: 1, allianceValue: 1 });
    return relation;
  };
  const bestPartner = new Map<number, number>();
  for (const t of s?.trade ?? []) {
    if (!(t.quantity > 0) || t.good < 0 || t.good >= G || t.from < 0 || t.to < 0 || t.from >= R || t.to >= R) continue;
    const a = owner[t.from], b = owner[t.to];
    // A conquest can transfer the observed stocks and works to a new owner,
    // but cannot retrospectively give that polity the former owner's trading
    // relationship. Until another native delivery occurs the tie is unknown.
    if (s!.owner[t.from] !== a || s!.owner[t.to] !== b) continue;
    if (a === b || !byCountry.has(a) || !byCountry.has(b)) continue;
    const producer = byCountry.get(a)!, consumer = byCountry.get(b)!;
    // The recorded delivered value is the only bilateral observation. Country
    // aggregate imports may include more trades than these 512 detail records.
    const value = pos(t.value), incoming = row(b, a), outgoing = row(a, b);
    incoming.importValue += value;
    incoming.scarceImportValue += value * consumer.scarcity[t.good] * (t.good === 0 ? 2 : 1);
    outgoing.exportValue += value;
    const needValue = value * consumer.scarcity[t.good] * (t.good === 0 ? 2 : 1);
    if (needValue > (bestPartner.get(b) ?? -1)) { consumer.tradePartner = a; consumer.supplyRegion = t.from; bestPartner.set(b, needValue); }
    if (!producer.tradePartner && producer.tradePartner !== 0) producer.tradePartner = b;
  }
  const out: EconomicRelation[] = [];
  for (const [a, targets] of pairs) for (const [b, r] of targets) {
    const from = byCountry.get(a)!, to = byCountry.get(b)!;
    let demandValue = 0;
    for (let g = 0; g < G; g++) demandValue += from.demand[g] * BASE_PRICE[g];
    r.importDependence = unit(r.importValue / Math.max(1, demandValue));
    r.complementarity = complement(from, to.supply);
    r.warOpportunity = r.complementarity * from.warReadiness;
    r.warOpportunityCost = unit((r.importValue + 2 * r.scarceImportValue + 0.25 * r.exportValue) / Math.max(1, demandValue));
    r.peaceValue = 1 + Math.min(2, 1.2 * r.warOpportunityCost + 0.4 * r.complementarity + 0.4 * (1 - from.warReadiness));
    r.allianceValue = 1 + Math.min(2, r.warOpportunityCost + 0.6 * r.complementarity);
    out.push(r);
  }
  return out.sort((a, b) => a.from - b.from || a.to - b.to);
}

/** Atomic audit: an impossible core expenditure is an integration error, never
 * hidden by silently clamping its fiscal bill. Repeated finish is idempotent. */
export function finishEconomicStrategy(state: EconomicStrategyState, year: number, actualPublicSpend: ArrayLike<number>, owner: ArrayLike<number>): void {
  const latest = state.latest;
  if (!latest || latest.year !== year || state.year !== year) throw new Error('Economic strategy finish has no matching native annual plan');
  if (actualPublicSpend.length < state.count || owner.length < state.count) throw new Error('Economic strategy finish regional dimension mismatch');
  const totals = new Map<number, number>();
  for (let r = 0; r < state.count; r++) {
    const actual = actualPublicSpend[r];
    if (!Number.isFinite(actual) || actual < 0 || actual > latest.publicBudget[r] + 1e-7 * Math.max(1, latest.publicBudget[r])) throw new Error(`Native public project overspend in region ${r}`);
    if (actual > 0 && !validCountry(owner[r])) throw new Error(`Native public project without country in region ${r}`);
    totals.set(owner[r], (totals.get(owner[r]) ?? 0) + actual);
  }
  for (let r = 0; r < state.count; r++) latest.publicSpend[r] = actualPublicSpend[r];
  for (const d of latest.countries) d.publicSpend = totals.get(d.country) ?? 0;
}

export function economicCountry(state: EconomicStrategyState, country: number): EconomicStrategyDecision | undefined {
  return lookup(state)?.countries.get(country);
}

export function economicRelation(state: EconomicStrategyState, from: number, to: number): EconomicRelation | undefined {
  return lookup(state)?.relations.get(from)?.get(to);
}

/** Offensive economic feasibility multiplier, bounded 0.05..1.4. Food readiness
 * (0.12 + 0.88*adequacy²) and fiscal runway constrain war even when a neighbor
 * has wanted goods. Actual scarce imports add an opportunity cost; an absent
 * detail record contributes no invented partner dependence. */
export function economicWarScale(state: EconomicStrategyState, attacker: number, defender: number): number {
  const a = economicCountry(state, attacker);
  if (!a || a.reasons.includes('no_observation')) return 1;
  const b = economicCountry(state, defender), tie = economicRelation(state, attacker, defender);
  const opportunity = b ? complement(a, b.supply) * a.warReadiness : 0;
  const cost = tie?.warOpportunityCost ?? 0;
  return Math.min(1.4, Math.max(0.05, a.warReadiness * (1 + 0.4 * opportunity - 0.75 * cost)));
}

/** 1..3 multiplier for native peace/alliance candidate evaluation. Fiscal/food
 * distress values peace generally; actual complementary imports value the
 * particular partner. No new pact or war is created by these pure queries. */
export function economicPeaceValue(state: EconomicStrategyState, from: number, to: number): number {
  const a = economicCountry(state, from);
  return economicRelation(state, from, to)?.peaceValue ?? (a && !a.reasons.includes('no_observation') ? 1 + 0.4 * (1 - a.warReadiness) : 1);
}

export function economicAllianceValue(state: EconomicStrategyState, from: number, to: number): number {
  const tie = economicRelation(state, from, to);
  if (tie) return tie.allianceValue;
  const a = economicCountry(state, from), b = economicCountry(state, to);
  return a && b && !a.reasons.includes('no_observation') ? 1 + 0.4 * complement(a, b.supply) : 1;
}

/** Constant seven-good valuation of an ALREADY considered native expansion
 * candidate, 0.8..1.6. Wanted observed output/stocks raise its value, stress and
 * food/war damage lower it; no scan of every foreign region is required. */
export function economicRegionValue(state: EconomicStrategyState, country: number, region: number): number {
  const a = economicCountry(state, country), latest = state.latest;
  if (!a || !latest || region < 0 || region >= state.count || a.reasons.includes('no_observation')) return 1;
  const supply = latest.regionSupply.subarray(region * G, region * G + G);
  return Math.max(0.8, Math.min(1.6, 1 + 0.6 * complement(a, supply) * a.warReadiness - 0.2 * latest.regionRisk[region]));
}
