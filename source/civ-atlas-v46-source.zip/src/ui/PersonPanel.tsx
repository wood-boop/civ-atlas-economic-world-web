/**
 * 人物卡片(和国家卡片同一套样子,零件见 panelParts.tsx):点编年史、卡片、人物页、搜索里的人名打开。
 * 地图上亮出他的国家(civView.ts 的 MapSelection、flyTo.ts 的 mapTarget);点人名不挪时间轴,按"即位那年 / 出征那年"才跳。
 *
 *   顶部  头像(Portrait.tsx:眨眼、呼吸,按那一年的事换表情;去世以后成了画像)、称呼("圣宗柳玄""阿尔德里克三世""楚尧")、"大景皇帝，2485–2519 年在位" / "大景将领，2478–2509 年领兵"
 *         / "大景丞相，2501–2537 年在朝" / "大景宗室，2428–2467"(没即位的宗室:世系图里补上的父辈)
 *   按钮  即位那年 / 出征那年 / 入仕那年(主操作:时间轴跳过去;宗室换成「世系图」)、编年史(这国的编年史,滚到他在台上那段)、
 *         复制生平(纯文字,写设定用;带上「生平」那一段)、关注他(导播只讲他这一辈子,镜头跟着他;正跟着他时是「不关注」;宗室没有,
 *         见 Follow.tsx)、更多(加一个和他有关的作者人物:亲友里先填上他)。
 *         「更多」最上面:让他去世…(那年在位的君主、将领、名臣)、改他的倾向…(那年在位的君主),点了卡片换成那一页(PersonIvPage.tsx);
 *         接着让他掌权…(那年在世、成年、没在位的太子、君主的兄弟叔伯、在朝的名臣、领过兵的将领)、为他联姻…(那年在位的君主、
 *         在世成年的宗室),点了换成那一页(RegentIvPage.tsx);演一国时别国的人这几项变灰,写"切回造物主才能改别国"
 *   概况  君主:事迹(名人才有)、国家、生卒、在位、前任、继任(后面的小字是亲属,和编年史的"其子 / 其侄"同一个算法:按世系;
 *         作者立的君主:名字前面是作者人物的圆头像,小字写「作者的人物」,点了开作者的人物卡;让位给他的,结局写"让位 给某某")、
 *         父亲(收养的写「养父」;父亲在别国的,小字写那一国)、子嗣(世系图里有的人,没即位的写"未即位")、
 *         争储(即位时诸子争储怎么得的位:以军功越过兄长、举兵、谮杀……,对手能点)/ 争位(据地自立的:不服谁即位、据哪里自立)、
 *         结局、即位前领兵(做王子时领的兵)、亲征(在位时)、将领(在位时本国领兵的)、名臣(在位时在朝的);
 *         右上「世系图」打开这国的世系图,停在他那一朝、圈出他。共和国写"在任""执政",没有父亲、子嗣、世系图
 *         将领:事迹、国家、字号、籍贯、生卒、官职、历任、领兵(伐谁 / 抗谁)、效力(那几年在位的君主)、对手(同一场仗对面的统帅)、结局
 *         名臣:事迹(经手的事)、国家、字号、籍贯、生卒、官职(做到最高的那个官和任期)、历任(之前的官和年份)、效力、结局
 *         宗室:国家、生卒、父亲、子嗣、领兵(替父兄出征打的仗)、效力(派他出征的君主,小字写父 / 兄)、结局(战死、争储被杀)、
 *         对手(杀他的那位新君,小字写亲属和怎么回事)
 *         (字号:西幻、汗国这类名字没有姓的不起字号,这一行不出)
 *         放逐到中立地的(争储失势的宗室、被废的君主)多「放逐」一行("星河域 2303 年起，桓王所徙"),亡国出奔的写「出奔」;
 *         卒于中立地的结局写"卒于星河域"(宗室的「放逐」「结局」排在子嗣前面)
 *         掌过实权的(regentInfo.ts):「掌权」一行("2585–2587 年  父亲在位时""2602–2609 年  辅政懿公胡炜，还政";君主排在在位下面,
 *         宗室在生卒下面,名臣、将领在官职下面);引兵入朝的「争储」写"引兵还朝，杀其兄某某，不即位"、叔父篡位的写"废其侄某某自立";
 *         被架空过的君主:「实权」一行(在位下面:"彭继桓  子，2585–2587",掌权的人能点)。
 *         联姻(宗室女只写一行、不能点):「母亲」「配偶」排在父亲下面("风氏  大澜德宗之女，2610 年娶",国名能点;没有姓的语感写"某国公主")
 *   掌权时 / 联姻  掌权、了结那几条(幼主即位时的摄政、篡位改朝换代、即位接着先君的那一条也算)/ 结亲那一条和那以后两国本为姻亲的结盟,新的在上
 *   放逐 / 出奔  徙居(出奔)那一条、卒于中立地(或中立地撤销、回了本国那一条),新的在上
 *   倾向  君主、执政官才有:开拓、好战、发展、重商一项一行(名字、灰色细条、0–100 的数值),下面一句说明;
 *         那年在位的君主右上多一个「改」(同「更多」里的改他的倾向);改过倾向的右上写"1500 年起改过",点了看原来的;
 *         被架空过的,上面一句"2585–2587 年政出于彭继桓：这几年开战、议和照彭继桓的倾向，不照下面这几条。"
 *   生平  将领、名臣的一段生平(officialText.ts 的 personBio);写到的君主是蓝字
 *   作者的人物  亲友里有他、经历里勾了他的作者人物(characterInfo.ts 的 charactersOfPerson),没有就不显示
 *   在位时 / 领兵时 / 在朝时  他在台上那几年本国的事(将领 = 他经手的那几仗),新的在上;点一条跳到那一年。
 *         宗室:领兵时(他经手的那几仗)/ 争储(杀他的那位新君即位那一条),都没有就不显示
 */
import { Fragment, useMemo, useState, type ReactNode } from 'react';
import type { Civ, Person, PersonSpouse, RulerLeanings } from '../gen/civ/types';
import { polityName } from '../gen/civ/growth';
import { buildChronicle, filterChronicle, reignEntries, type ChronicleEntry } from '../gen/civ/chronicle';
import { commandFoes, peopleIndex, personFame, personSpan, rulerNeighbors, type Foe } from '../gen/civ/peopleInfo';
import { LEANING_KEYS, LEANING_TEXT, ageAt, generalRole, isConsul, kinOf, leaningsText, ministerRole, personName, princeRef, princeRole, rulerBare, rulerFateWord, rulerRef, rulerRole, rulerShort } from '../gen/civ/peopleText';
import { REGENCY_END, REGENCY_VERB, brideName, heldOver, kinAt, overlapOf, polityShort, type Held } from '../gen/civ/regentInfo';
import { treatyBook } from '../gen/civ/treatyInfo';
import { fullChronicle } from '../gen/civ/religionText';
import { diedInExile, treatyEntries } from './treatyRows';
import { evType } from './timelineLayout';
import { regionLabel } from '../gen/civ/display';
import { deedsShort, ministerFate, personArt, personBio } from '../gen/civ/officialText';
import { fatherOf, hasLineage, kidsOf } from '../gen/civ/lineageInfo';
import { personKey } from '../gen/characters';
import { personPortrait, portraitMood } from '../gen/portrait';
import { PortraitView } from './Portrait';
import { openLineage, openOverview } from './overviewStore';
import { getEdits, useEdits, useEra } from './editsStore';
import { eraText, spaced, yearAt, yearShort, yearShortAt, yearSpan, yearSpanAt, type Era } from '../gen/era';
import { newCharacterDraft } from './characterStore';
import { charactersOfPerson } from './characterInfo';
import { CharAvatar, CharacterRefs } from './CharacterPanel';
import type { AuthorCharacter } from '../gen/characters';
import { MenuItem } from './PopMenu';
import { Icon } from './icons';
import { NameEdit } from './NameEdit';
import { FollowAct } from './Follow';
import { Act, Acts, EntryText, EventList, Link, MoreAct, PanelHead, Row, Stats, SubLine, copyText, jumpTo, rgb, type DetailProps } from './panelParts';
import { leanRows, peaceRow, policyLabel, roleLock, rulerPolicy } from './policyInfo';
import { openPolicyPage } from './PolicyPage';
import { nameAt } from './Interventions';
import { useRole } from './roleStore';
import { ROLE_LOCK_NOTE } from './RoleBar';
import { pickChronicleEntry, setSelection } from './civView';
import { PersonIvPage, type PersonIvKind } from './PersonIvPage';
import { leaningsThen, marryChoice, moodSince, personIvRange, regentChoice, rulerOnThrone } from './newIvInfo';
import { MarryIvPage, RegentIvPage } from './RegentIvPage';
import './policy.css';
import './newIv.css';

const F = Math.floor;

/** 一行概况:k 名目、node 显示的、text 复制生平时的纯文字 */
interface Line {
  k: string;
  node: ReactNode;
  text: string;
}

/** 一串人名(都能点);多于 max 个只列前面的,后面写"等 N 位" */
function peopleLine(civ: Civ, list: readonly Person[], max = 6): { node: ReactNode; text: string } {
  const shown = list.slice(0, max);
  const more = list.length - shown.length;
  return {
    node: (
      <>
        {shown.map((g, i) => (
          <Fragment key={g.id}>
            {i > 0 && '、'}
            <Link to={{ kind: 'person', id: g.id }}>{personName(civ, g)}</Link>
          </Fragment>
        ))}
        {more > 0 && <em className="cp-num-note">等 {list.length} 位</em>}
      </>
    ),
    text: shown.map((g) => personName(civ, g)).join('、') + (more > 0 ? ` 等 ${list.length} 位` : ''),
  };
}

/** 子嗣:人名都能点,没即位的后面小字"未即位";多于 max 个只列前面的 */
function kidsLine(civ: Civ, list: readonly Person[], max = 6): { node: ReactNode; text: string } {
  const shown = list.slice(0, max);
  const more = list.length - shown.length;
  // 没即位的:争储被杀的写"被杀",摄政时伏诛的写"伏诛"
  const note = (k: Person) => (k.role !== 'prince' ? '' : k.fate !== 'purged' ? '未即位' : regentPurged(k) ? '伏诛' : '被杀');
  return {
    node: (
      <>
        {shown.map((k, i) => (
          <Fragment key={k.id}>
            {i > 0 && '、'}
            <Link to={{ kind: 'person', id: k.id }}>{personName(civ, k)}</Link>
            {note(k) && <em className="cp-num-note">{note(k)}</em>}
          </Fragment>
        ))}
        {more > 0 && <em className="cp-num-note">等 {list.length} 位</em>}
      </>
    ),
    text: shown.map((k) => personName(civ, k) + (note(k) ? `(${note(k)})` : '')).join('、') + (more > 0 ? ` 等 ${list.length} 位` : ''),
  };
}

/** 伐 / 抗哪国(国名能点)+ 年份 */
export function foesLine(civ: Civ, foes: readonly Foe[], era: Era | undefined): { node: ReactNode; text: string } {
  return {
    node: foes.map((f, i) => (
      <Fragment key={i}>
        {i > 0 && '、'}
        {f.verb}
        <Link to={{ kind: 'polity', id: f.polity }}>{polityName(civ.polities[f.polity], f.from)}</Link>
        <em className="cp-num-note">{yearSpan(f.from, f.until, era)}</em>
      </Fragment>
    )),
    text: foes.map((f) => `${f.verb}${polityName(civ.polities[f.polity], f.from)}(${yearSpan(f.from, f.until, era)})`).join('、'),
  };
}

/** 本国的纪事(战争拆成一件一件)+ 历代继位,按先后。亡国、毁城既折进战争里、又单列一条,拆开后只留一条 */
function polityEntries(civ: Civ, polity: number): ChronicleEntry[] {
  const out: ChronicleEntry[] = [];
  const seen = new Set<string>();
  const add = (e: ChronicleEntry) => {
    const k = `${e.kind}:${e.id}`;
    if (seen.has(k)) return;
    seen.add(k);
    out.push(e);
  };
  for (const e of filterChronicle(buildChronicle(civ), { polity })) {
    if (e.children?.length) e.children.forEach(add);
    else add(e);
  }
  filterChronicle(reignEntries(civ), { polity }).forEach(add);
  return out.sort((a, b) => a.year - b.year || a.id - b.id);
}

export function PersonPanel({ civ, id, year }: DetailProps) {
  const x = civ.people?.[id];
  const p = x ? civ.polities[x.polity] : undefined;
  const [copied, setCopied] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const { characters: chars, era, names } = useEdits();
  const lines = useMemo(() => (x && p ? personLines(civ, x, era) : []), [civ, x, p, era]);
  const events = useMemo(() => (x && p ? personEvents(civ, x) : []), [civ, x, p]);
  const heldEv = useMemo(() => (x && p ? heldEvents(civ, x) : []), [civ, x, p]);
  const wedEv = useMemo(() => (x && p ? marryEvents(civ, x) : []), [civ, x, p]);
  const overMe = useMemo(() => (x ? heldOver(civ, x) : []), [civ, x]);
  const bio = useMemo(() => (x && p ? personBio(civ, x, era) : ''), [civ, x, p, era]);
  const refs = useMemo(() => charactersOfPerson(civ, chars, id, era), [civ, chars, id, era]);
  // 头像按岁数变(年份取整),去世以后定在去世那年
  const age = x ? Math.floor((x.died !== undefined ? Math.min(year, x.died) : year) - x.born) : 0;
  const portrait = useMemo(() => (x ? personPortrait(civ, x.id, x.born + age) : null), [civ, x, age]);
  const mood = useMemo(() => (x ? portraitMood(civ, x, year) : undefined), [civ, x, year]);
  // 卡片换上的填写页(让他去世 / 改他的倾向 / 让他掌权 / 为他联姻);换了人就回到卡片
  const [ivPage, setIvPage] = useState<{ id: number; kind: PersonIvKind | 'regent' | 'marry' } | null>(null);
  const role = useRole();
  if (!x || !p) return null;
  const page = ivPage?.id === id ? ivPage.kind : null;
  // 演一国时别国的人:让他去世、改倾向变灰
  const locked = !!roleLock(civ, role, x.polity);
  // 让他去世:那年在位的君主(作者立的去人物卡改卒年)、还能下的将领名臣;改倾向:那年在位的君主
  const onThrone = rulerOnThrone(x, year);
  const range = personIvRange(civ, x);
  const canDie = x.killed === undefined && (x.role === 'ruler' ? onThrone : (x.role === 'general' || x.role === 'minister') && range.lo <= range.hi);
  // 让他掌权:那年在世、成年、没在位的太子、叔伯、名臣、将领;为他联姻:那年在位的君主、在世成年的宗室
  const canRule = !!regentChoice(civ, x, year);
  const canWed = marryChoice(civ, x, year);
  const ruler = x.role === 'ruler';
  const prince = x.role === 'prince';
  const minister = x.role === 'minister';
  const consul = isConsul(civ, x);
  const span = personSpan(x);
  const end = span.until ?? civ.endYear;
  const sub = prince
    ? `${princeRole(civ, x)}，${yearShort(x.born, era)}–${x.died !== undefined ? yearShort(x.died, era) : ''}`
    : ruler
      ? span.until === null
        ? `${rulerRole(civ, x)}，${yearAt(span.from, era)}${consul ? '就任' : '即位'}`
        : `${rulerRole(civ, x)}，${yearSpanAt(span.from, span.until, era)}${consul ? '在任' : '在位'}`
      : minister
        ? span.until === null
          ? `${ministerRole(civ, x)}，${yearAt(span.from, era)}起在朝`
          : `${ministerRole(civ, x)}，${yearSpanAt(span.from, span.until, era)}在朝`
        : `${generalRole(civ, x)}，${yearSpanAt(span.from, end, era)}领兵`;
  const name = personName(civ, x);
  // 改名:只改本名;前面的庙号、谥号不动(国家没了、算不出键的人不能改)
  const nameKey = personKey(civ, id);
  const fallbackName = x.defaultName ?? x.name;
  const lead = name.endsWith(x.name) ? name.slice(0, name.length - x.name.length) : '';
  const nameHint = `${lead ? `只改名字，${/[宗祖]$/.test(lead) ? '庙号' : '称号'}「${lead}」不变；` : '只改名字；'}留空 = 换回「${fallbackName}」。`;
  const head = ruler ? (consul ? '在任时' : '在位时') : minister ? '在朝时' : prince ? princeHead(x) : '领兵时';
  const lineage = () => openLineage(x.polity, { dynasty: x.dynasty ?? 0, focus: x.id });

  const copy = async () => {
    const out = [name, sub, ...lines.map((l) => `${l.k}：${l.text}`)];
    if (ruler && x.leanings) out.push(`倾向：${leaningsText(x.leanings)}`);
    if (bio) out.push('', `生平：${bio}`);
    if (events.length) out.push('', `${head}：`, ...events.map((e) => `${yearShort(e.year, era)} ${eraText(e.text.replace(/^【(?:干预|照大纲)】/, ''), era)}`));
    const text = out.join('\n');
    (window as unknown as { __wfPersonText: string }).__wfPersonText = text;
    await copyText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const headEl = (
      <PanelHead
        color={rgb(p.color)}
        icon={
          portrait && (
            <PortraitView
              p={portrait}
              size="card"
              color={rgb(p.color)}
              dead={x.died !== undefined && year > x.died}
              dark={x.fate === 'murdered' || x.fate === 'fell' || x.fate === 'battle'}
              mood={mood}
            />
          )
        }
      >
        {nameKey ? (
          <NameEdit
            k={nameKey}
            kind="person"
            shown={name}
            current={x.name}
            fallback={x.defaultName ?? x.name}
            names={names}
            big
            editing={renaming}
            onEditing={setRenaming}
            hint={nameHint}
            preview={(v) => personName(civ, { ...x, name: v })}
          />
        ) : (
          <div className="ins-name-row big">
            <span className="ins-name pp-title">{name}</span>
          </div>
        )}
        <SubLine parts={[sub]} />
      </PanelHead>
  );
  if (page)
    return (
      <div className="cp pp" data-person={id} data-pp-page={page}>
        {headEl}
        {page === 'regent' ? (
          <RegentIvPage key={`${id}-${page}`} civ={civ} x={x} year={year} onBack={() => setIvPage(null)} />
        ) : page === 'marry' ? (
          <MarryIvPage key={`${id}-${page}`} civ={civ} x={x} year={year} onBack={() => setIvPage(null)} />
        ) : (
          <PersonIvPage key={`${id}-${page}`} civ={civ} x={x} year={year} kind={page} onBack={() => setIvPage(null)} />
        )}
      </div>
    );

  return (
    <div className="cp pp" data-person={id}>
      {headEl}
      <Acts>
        {prince ? (
          <Act icon="lineage" primary act="person-lineage" onClick={lineage} title="看这一朝的世系图">
            世系图
          </Act>
        ) : (
          <Act icon="history" primary act="person-year" onClick={() => jumpTo(span.from)} title={`时间轴跳到${spaced(yearAt(span.from, era))}`}>
            {ruler ? (consul ? '就任那年' : '即位那年') : minister ? '入仕那年' : '出征那年'}
          </Act>
        )}
        <Act icon="scroll" act="person-chronicle" onClick={() => openOverview('chronicle', { polity: x.polity, major: false, at: end })}>
          编年史
        </Act>
        <Act icon="copy" act="person-copy" onClick={() => void copy()}>
          {copied ? '已复制' : '复制生平'}
        </Act>
        {!prince && <FollowAct civ={civ} x={x} year={year} />}
        <MoreAct>
          {canDie && (
            <MenuItem icon={<Icon name="close" size={16} className="iv-blank" />} act="person-death" disabled={locked} note={locked ? ROLE_LOCK_NOTE : undefined} onClick={() => setIvPage({ id, kind: 'death' })}>
              让他去世…
            </MenuItem>
          )}
          {onThrone && (
            <MenuItem icon={<Icon name="close" size={16} className="iv-blank" />} act="person-temper" disabled={locked} note={locked ? ROLE_LOCK_NOTE : undefined} onClick={() => setIvPage({ id, kind: 'temper' })}>
              改他的倾向…
            </MenuItem>
          )}
          {canRule && (
            <MenuItem icon={<Icon name="close" size={16} className="iv-blank" />} act="person-regent" disabled={locked} note={locked ? ROLE_LOCK_NOTE : undefined} onClick={() => setIvPage({ id, kind: 'regent' })}>
              让他掌权…
            </MenuItem>
          )}
          {canWed && (
            <MenuItem icon={<Icon name="close" size={16} className="iv-blank" />} act="person-marry" disabled={locked} note={locked ? ROLE_LOCK_NOTE : undefined} onClick={() => setIvPage({ id, kind: 'marry' })}>
              为他联姻…
            </MenuItem>
          )}
          {nameKey && (
            <MenuItem icon={<Icon name="rename" size={16} />} act="person-rename" onClick={() => setRenaming(true)}>
              改名
            </MenuItem>
          )}
          <MenuItem icon={<Icon name="person" size={16} />} act="person-add-character" onClick={() => newCharacterDraft({ kin: [{ rel: '', person: personKey(civ, id) }], year })}>
            加一个和他有关的人物
          </MenuItem>
        </MoreAct>
      </Acts>
      <div className="cp-body">
        <Stats
          items={[]}
          more={
            ruler &&
            hasLineage(civ, x.polity) && (
              <button className="ins-link cp-more" data-act="person-lineage" onClick={lineage}>
                世系图
              </button>
            )
          }
        >
          {lines.map((l) => (
            <Row key={l.k} k={l.k}>
              {l.node}
            </Row>
          ))}
        </Stats>
        {x.exile && x.exile.to === undefined && <ExileEvents civ={civ} x={x} />}
        {heldEv.length > 0 && (
          <EventList
            civ={civ}
            self={id}
            title="掌权时"
            upTo={heldEv}
            limit={8}
            more={
              <button className="ins-link cp-more" data-act="person-held-chronicle" onClick={() => openOverview('chronicle', { polity: x.polity, major: false, at: x.regencies![x.regencies!.length - 1].until ?? end })}>
                在编年史中查看
              </button>
            }
          />
        )}
        {wedEv.length > 0 && (
          <EventList
            civ={civ}
            self={id}
            title="联姻"
            upTo={wedEv}
            limit={8}
            more={
              <button className="ins-link cp-more" data-act="person-wed-chronicle" onClick={() => openOverview('chronicle', { polity: x.polity, major: false, at: wedEv[wedEv.length - 1].year })}>
                在编年史中查看
              </button>
            }
          />
        )}
        {ruler && x.leanings && <Leanings civ={civ} x={x} l={x.leanings} year={year} over={overMe} onEdit={onThrone ? () => setIvPage({ id, kind: 'temper' }) : undefined} locked={locked} />}
        {bio && (
          <section className="cp-sec">
            <div className="cp-sec-head">生平</div>
            <div className="oc-note" data-bio>
              <EntryText civ={civ} e={{ text: bio, people: bioPeople(civ, x), year: span.from }} self={id} />
            </div>
          </section>
        )}
        <CharacterRefs refs={refs} />
        {(!prince || events.length > 0) && (
        <EventList
          civ={civ}
          self={id}
          title={head}
          upTo={events}
          limit={12}
          empty="这几年本国无事可记"
          more={
            <button className="ins-link cp-more" data-act="person-chronicle-more" onClick={() => openOverview('chronicle', { polity: x.polity, major: false, at: end })}>
              在编年史中查看
            </button>
          }
        />
        )}
      </div>
    </div>
  );
}

/**
 * 君主的倾向:一项一行(名字、细条、数值),下面一句说明。
 * 他在位时国家定了方针(时间轴那一年,夹在他在位的年份里):右上"大澜王朝方针：扩张"(点了进那国的方针页);
 * 方针管到的那几项细条后面接一截蓝色、数写成"53＋25＝78",说明后面接"；方针「扩张」让他往外占";拧了和谈底线的多一行"和谈"
 */
function Leanings({ civ, x, l, year, over, onEdit, locked }: { civ: Civ; x: Person; l: RulerLeanings; year: number; over: readonly Held[]; onEdit?: () => void; locked: boolean }) {
  const era = useEra();
  const v = rulerPolicy(civ, x, year);
  // 改过倾向的:照时间轴那一年的(在位以前看即位时的);点"某年起改过"看原来的
  const t = Math.min(Math.max(year, x.from ?? year), (x.until ?? civ.endYear) - 1 / 256);
  const since = moodSince(x, t);
  const [orig, setOrig] = useState(false);
  const shownL = since !== null && !orig ? (leaningsThen(x, t) ?? l) : l;
  const rows = leanRows(shownL, v);
  const peace = peaceRow(v);
  const P = civ.polities[x.polity];
  const pol = v && P && (
    <button className="ins-link cp-more" data-act="person-policy" onClick={() => (locked ? setSelection({ kind: 'polity', id: x.polity }) : openPolicyPage(civ, x.polity))}>
      {nameAt(P, t)}方针：{policyLabel(v)}
    </button>
  );
  const head =
    pol || since !== null || onEdit ? (
      <span className="iv-head-acts">
        {pol}
        {since !== null && (
          <button className="ins-link cp-more" data-act="person-mood" aria-pressed={orig} onClick={() => setOrig(!orig)} title={orig ? '看改过的' : '看原来的'}>
            {orig ? '原来的（点了看改过的）' : `${yearShortAt(since, era)}起改过`}
          </button>
        )}
        {onEdit && (
          <button className="ins-link cp-more" data-act="person-temper-edit" disabled={locked} title={locked ? ROLE_LOCK_NOTE : '改他的倾向'} onClick={onEdit}>
            改
          </button>
        )}
      </span>
    ) : null;
  return (
    <section className="cp-sec" data-sec="leanings">
      <div className={`cp-sec-head${head ? ' cp-events-head' : ''}`}>
        <span>倾向</span>
        {head}
      </div>
      {over.map((h, i) => {
        // 被架空的那几年:推演照掌权的人的倾向
        const o = overlapOf(h.g, x);
        const when = o.until !== undefined ? yearSpanAt(o.from, o.until, era) : `${yearAt(o.from, era)}起`;
        return (
          <div key={i} className="iv-warn pp-held-note" data-held={h.x.id}>
            {when}政出于<Link to={{ kind: 'person', id: h.x.id }}>{h.x.name}</Link>：这几年开战、议和照{h.x.name}的倾向，不照下面这几条。
          </div>
        );
      })}
      <div className="cp-group">
        {rows.map((r) => (
          <div key={r.k} className="pp-lean" data-leaning={r.k} data-policy-add={r.add || undefined}>
            <div className="pp-lean-top">
              <span className="pp-lean-k">{LEANING_TEXT[r.k].name}</span>
              <span className={`pp-lean-bar${r.add ? ' pol-bar' : ''}`} aria-hidden="true">
                <i style={{ width: `${r.add < 0 ? r.actual : r.base}%` }} />
                {r.add > 0 && <i className="pol-add-bar" style={{ left: `${r.base}%`, width: `${r.actual - r.base}%` }} />}
                {r.add < 0 && <i className="pol-cut-bar" style={{ left: `${r.actual}%`, width: `${r.base - r.actual}%` }} />}
              </span>
              {r.add ? (
                <span className="pp-lean-num pol-wide">
                  <span className="pol-calc">
                    {r.base}
                    {r.add > 0 ? '＋' : '−'}
                    {Math.abs(r.add)}＝<b>{r.actual}</b>
                  </span>
                </span>
              ) : (
                <span className="pp-lean-num">{r.base}</span>
              )}
            </div>
            <div className="pp-lean-note">
              {LEANING_TEXT[r.k].note}
              {r.why}
            </div>
          </div>
        ))}
        {peace && (
          <div className="pp-lean" data-leaning="peace">
            <div className="pp-lean-top">
              <span className="pp-lean-k">和谈</span>
              <span className="pol-peace">{peace}</span>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

/** 概况的每一行 */
function personLines(civ: Civ, x: Person, era: Era | undefined): Line[] {
  const p = civ.polities[x.polity];
  const out: Line[] = [];
  const fame = personFame(civ, x);
  const deeds = x.role === 'minister' ? deedsShort(civ, x) : (fame?.deeds ?? '');
  if (deeds) out.push({ k: '事迹', node: deeds, text: deeds });
  const span = personSpan(x);
  // 宗室(可能生在立国之前):按卒年那会儿的国名
  const pn = polityName(p, x.role === 'prince' ? Math.max(p.founded, Math.min(x.died ?? x.born, p.ended ?? civ.endYear) - 1 / 512) : span.from);
  out.push({ k: '国家', node: <Link to={{ kind: 'polity', id: p.id }}>{pn}</Link>, text: pn });
  if (x.role === 'minister' || x.role === 'general') styleLines(civ, x, out);
  if (x.died !== undefined) {
    // 享年按实际活了多久算(和编年史的"时年"一样),不是两个年份相减
    const age = ageAt(x, x.died);
    out.push({
      k: '生卒',
      node: (
        <>
          {yearSpanAt(x.born, x.died, era)}
          <em className="cp-num-note">享年 {age} 岁</em>
        </>
      ),
      text: `${yearSpanAt(x.born, x.died, era)}，享年 ${age} 岁`,
    });
  } else out.push({ k: '生卒', node: `${yearAt(x.born, era)}生`, text: `${yearAt(x.born, era)}生` });
  if (x.role === 'prince') {
    const held = heldLine(civ, x, era);
    if (held) out.push(held);
    kinLines(civ, x, out, era);
    princeLines(civ, x, out, era);
    // 放逐到中立地的宗室:「放逐」「结局」(卒于中立地)排在子嗣前面
    const ex = exileLine(civ, x, era);
    if (ex) {
      const rows = [ex];
      if (diedInExile(x) && !out.some((l) => l.k === '结局')) {
        const zone = regionLabel(civ, x.exile!.region);
        const when = yearAt(x.died!, era);
        rows.push({ k: '结局', node: <>卒于{zone}<em className="cp-num-note">{when}</em></>, text: `卒于${zone}，${when}` });
      }
      const at = out.findIndex((l) => l.k === '子嗣');
      out.splice(at >= 0 ? at : out.length, 0, ...rows);
    }
    return out;
  }
  const held = heldLine(civ, x, era);
  if (x.role === 'minister') {
    postLines(x, x.until ?? null, out, era);
    if (held) out.push(held);
    ministerLines(civ, x, out, era);
    return out;
  }
  const foes = commandFoes(civ, x);
  if (x.role === 'ruler') rulerLines(civ, x, out, foes, era, held);
  else {
    const cs = x.commands ?? [];
    if (cs.length) postLines(x, cs[cs.length - 1].until, out, era);
    if (held) out.push(held);
    generalLines(civ, x, out, foes, era);
  }
  return out;
}

/** 小字里的起止:"2585–2587";还没完 "2585起" */
const spanNote = (from: number, until: number | undefined, era: Era | undefined) => (until !== undefined ? yearSpan(from, until, era) : `${yearShort(from, era)}起`);

/**
 * 「掌权」一行(他掌过实权的几段,按先后):引兵入朝 "2585–2587 年  父亲在位时";太子监国 "…  监国，父亲在位时";
 * 别的 "2602–2609 年  辅政懿公胡炜，还政"(名义君主能点)。没掌过 = null
 */
function heldLine(civ: Civ, x: Person, era: Era | undefined): Line | null {
  const gs = x.regencies ?? [];
  if (!gs.length) return null;
  const items = gs.map((g) => {
    const years = g.until !== undefined ? yearSpanAt(g.from, g.until, era) : `${yearAt(g.from, era)}起`;
    const N = g.ruler >= 0 ? civ.people?.[g.ruler] : undefined;
    const verb = REGENCY_VERB[g.kind];
    const end = (g.end && REGENCY_END[g.end]) || '';
    if (g.kind === 'march' || g.kind === 'heir') {
      const kin = N ? kinOf(civ, x, N) : '';
      const t = [verb, `${kin === '父' ? '父亲' : kin || '君主'}在位时`].filter(Boolean).join('，');
      return { node: <>{years}<em className="cp-num-note">{t}</em></>, text: `${years}（${t}）` };
    }
    const nm = N ? personName(civ, N) : '';
    return {
      node: (
        <>
          {years}
          <em className="cp-num-note">
            {verb}
            {N && <Link to={{ kind: 'person', id: N.id }}>{nm}</Link>}
            {end && `，${end}`}
          </em>
        </>
      ),
      text: `${years}（${verb}${nm}${end && `，${end}`}）`,
    };
  });
  return {
    k: '掌权',
    node: items.map((v, i) => (
      <Fragment key={i}>
        {i > 0 && '；'}
        {v.node}
      </Fragment>
    )),
    text: items.map((v) => v.text).join('；'),
  };
}

/** 「实权」一行(君主在位时谁掌着实权):"彭继桓  子，2585–2587" / "孙嵩曜  辅政 2602–2609，还政"(掌权的人能点) */
function heldOverLine(civ: Civ, r: Person, hs: readonly Held[], era: Era | undefined): Line | null {
  if (!hs.length) return null;
  const items = hs.map(({ x, g }) => {
    const o = overlapOf(g, r);
    const kin = g.kind === 'march' || g.kind === 'heir' || g.kind === 'uncle' ? kinOf(civ, r, x) : '';
    const verb = REGENCY_VERB[g.kind];
    // 结局在他在位时才写(专权跨了几位君主的,前几位不写)
    const end = g.end && o.until === g.until ? (REGENCY_END[g.end] ?? '') : '';
    const note = [kin, `${verb}${verb ? ' ' : ''}${spanNote(o.from, o.until, era)}`, end].filter(Boolean).join('，');
    return { x, note };
  });
  return {
    k: '实权',
    node: items.map((v, i) => (
      <Fragment key={i}>
        {i > 0 && '；'}
        <Link to={{ kind: 'person', id: v.x.id }}>{v.x.name}</Link>
        <em className="cp-num-note">{v.note}</em>
      </Fragment>
    )),
    text: items.map((v) => `${v.x.name}（${v.note}）`).join('；'),
  };
}

/**
 * 宗室女一行(不成完整人物,不能点):「配偶」"风氏  大澜德宗之女，2610 年娶"(议和时结的写"和亲");「母亲」不写年份。
 * 国名是简称、能点;她父亲没有人物的写"大澜宗室女";没有姓的语感写"大澜公主"
 */
function brideLine(k: string, civ: Civ, list: readonly PersonSpouse[], era: Era | undefined, when: boolean): Line {
  const items = list.map((s) => {
    const F = s.father >= 0 ? civ.people?.[s.father] : undefined;
    const short = polityShort(civ, s.polity, s.year);
    const who = F ? `${rulerBare(civ, F, s.year)}之女` : '宗室女';
    const tail = when ? `，${yearAt(s.year, era)}${s.peace !== undefined ? '和亲' : '娶'}` : '';
    const name = brideName(civ, s);
    return {
      node: (
        <>
          {name}
          <em className="cp-num-note">
            {civ.polities[s.polity] ? <Link to={{ kind: 'polity', id: s.polity }}>{short}</Link> : short}
            {who}
            {tail}
          </em>
        </>
      ),
      text: `${name}（${short}${who}${tail}）`,
    };
  });
  return {
    k,
    node: items.map((v, i) => (
      <Fragment key={i}>
        {i > 0 && '、'}
        {v.node}
      </Fragment>
    )),
    text: items.map((v) => v.text).join('、'),
  };
}

/** 字号、籍贯(名臣、将领;没有字号的语感不出「字号」这一行) */
function styleLines(civ: Civ, x: Person, out: Line[]) {
  const art = personArt(civ, x);
  const style = [x.courtesy ? `字${x.courtesy}` : '', art ? `号${art}` : ''].filter(Boolean).join('，');
  if (style) out.push({ k: '字号', node: style, text: style });
  const home = x.home !== undefined ? civ.settlements[x.home] : undefined;
  if (home?.name) out.push({ k: '籍贯', node: <Link to={{ kind: 'settlement', id: home.id }}>{home.name}</Link>, text: home.name });
}

/** 官职(做到最高的那个官 + 任期)、历任(之前的官 + 那年);until = 去职 / 最后一次卸任(还在任 = null) */
function postLines(x: Person, until: number | null, out: Line[], era: Era | undefined) {
  const ps = x.posts ?? [];
  const top = ps[ps.length - 1];
  if (!top) return;
  const years = until !== null ? yearSpanAt(top.from, until, era) : `${yearAt(top.from, era)}起`;
  out.push({
    k: '官职',
    node: (
      <>
        {top.title}
        <em className="cp-num-note">{years}</em>
      </>
    ),
    text: `${top.title}(${years})`,
  });
  const before = ps.slice(0, -1);
  if (before.length)
    out.push({
      k: '历任',
      node: before.map((post, i) => (
        <Fragment key={i}>
          {i > 0 && '、'}
          {post.title}
          <em className="cp-num-note">{yearShort(post.from, era)}</em>
        </Fragment>
      )),
      text: before.map((post) => `${post.title}(${yearShort(post.from, era)})`).join('、'),
    });
}

/** 名臣:效力(在朝那几年在位的本国君主)、结局 */
function ministerLines(civ: Civ, x: Person, out: Line[], era: Era | undefined) {
  const from = x.from ?? x.born;
  const until = x.until ?? civ.endYear;
  const served = peopleIndex(civ).rulers[x.polity].filter((r) => (r.from ?? Infinity) < until && (r.until ?? Infinity) > from);
  if (served.length) out.push({ k: '效力', ...peopleLine(civ, served) });
  const fate = x.killed !== undefined && x.died !== undefined ? `${yearAt(x.died, era)}卒（干预）` : ministerFate(civ, x, era);
  if (fate) out.push({ k: '结局', node: fate, text: fate });
}

/** 生平里写到的人:经手的事里的君主,迎立的那件还有遇弑的先君 */
function bioPeople(civ: Civ, x: Person): number[] {
  const out: number[] = [];
  for (const d of x.deeds ?? []) {
    const r = d.person !== undefined ? civ.people?.[d.person] : undefined;
    if (!r) continue;
    out.push(r.id);
    if (d.kind === 'enthrone') {
      const prev = rulerNeighbors(civ, r).prev;
      if (prev) out.push(prev.id);
    }
  }
  return [...new Set(out)];
}

/** 父亲(收养的写「养父」;在别国的小字写那一国)、母亲 / 配偶(联姻的宗室女)、子嗣(世系图里有的人;没即位的小字"未即位") */
function kinLines(civ: Civ, x: Person, out: Line[], era: Era | undefined) {
  const f = fatherOf(civ, x);
  if (f) {
    const away = f.polity !== x.polity ? polityName(civ.polities[f.polity], Math.min(x.from ?? x.born, f.until ?? Infinity) - 1 / 512) : '';
    out.push(personRow(x.adopted ? '养父' : '父亲', civ, f, [f.role === 'prince' ? '未即位' : '', away].filter(Boolean).join('，')));
  }
  if (x.mother) out.push(brideLine('母亲', civ, [x.mother], era, false));
  if (x.spouses?.length) out.push(brideLine('配偶', civ, x.spouses, era, true));
  const ks = kidsOf(civ, x);
  if (ks.length) out.push({ k: '子嗣', ...kidsLine(civ, ks) });
}

function rulerLines(civ: Civ, x: Person, out: Line[], foes: Foe[], era: Era | undefined, held: Line | null) {
  const consul = isConsul(civ, x);
  const from = x.from ?? x.born;
  if (x.until !== undefined) {
    const n = F(x.until) - F(from);
    const len = n >= 1 ? `${n} 年` : '不足一年';
    out.push({
      k: consul ? '在任' : '在位',
      node: (
        <>
          {yearSpanAt(from, x.until, era)}
          <em className="cp-num-note">{len}</em>
        </>
      ),
      text: `${yearSpanAt(from, x.until, era)}，${len}`,
    });
  } else {
    const t = consul ? `${yearAt(from, era)}就任，在任至今` : `${yearAt(from, era)}即位，在位至今`;
    out.push({ k: consul ? '在任' : '在位', node: t, text: t });
  }
  // 掌过实权(即位以前)/ 在位时被谁架空过
  if (held) out.push(held);
  const over = heldOverLine(civ, x, heldOver(civ, x), era);
  if (over) out.push(over);
  const { prev, next } = rulerNeighbors(civ, x);
  // 亲属:同一朝、继位的才写(和编年史的"其子 / 其侄"一致,连不上的是"宗室");换了朝代写"前朝 / 新朝";作者立的君主写"作者的人物"
  const sameDyn = (a: Person, b: Person) => (a.dynasty ?? 0) === (b.dynasty ?? 0);
  if (prev) {
    const ac = authorOf(prev);
    const note = ac ? '作者的人物' : consul ? '' : !sameDyn(prev, x) ? '前朝' : x.rise === 'heir' ? kinOf(civ, x, prev) || '宗室' : '';
    out.push(personRow('前任', civ, prev, note, ac));
  }
  if (next) {
    const ac = authorOf(next);
    const note = ac ? '作者的人物' : consul ? '' : !sameDyn(x, next) ? '新朝' : next.rise === 'heir' ? kinOf(civ, x, next) || '宗室' : '';
    out.push(personRow('继任', civ, next, note, ac));
  }
  if (!consul) kinLines(civ, x, out, era);
  const claim = claimLine(civ, x);
  if (claim) out.push(claim);
  const fate = rulerFateWord(civ, x);
  // 被废徙居、亡国出奔到中立地的:「放逐」/「出奔」一行排在结局前面,结局写"卒于某地"
  const ex = exileLine(civ, x, era);
  if (ex) out.push(ex);
  const diedAt = diedInExile(x) ? `卒于${regionLabel(civ, x.exile!.region)}` : '卒';
  if (x.killed !== undefined && x.died !== undefined) {
    const t = `${yearAt(x.died, era)}去世（干预）`;
    out.push({ k: '结局', node: t, text: t });
  } else if (fate && x.fate === 'yielded' && next) {
    // 让位给作者立的君主:后面写给谁
    const to = `给${personName(civ, next)}`;
    out.push({ k: '结局', node: <>{fate}<em className="cp-num-note">{to}</em></>, text: fate + to });
  } else if (fate) {
    // 失位以后又活了些年(被废、出奔……)的,写上卒年
    const later = x.died !== undefined && x.until !== undefined && x.died - x.until >= 1 ? `，${yearAt(x.died, era)}${diedAt}` : '';
    out.push({ k: '结局', node: fate + later, text: fate + later });
  }
  // 即位以前(做王子时)领的兵单列,和在位时的亲征分开
  const early = (x.commands ?? []).filter((c) => c.from < from);
  if (early.length && !consul) {
    const before = commandFoes(civ, { ...x, commands: early });
    const later = commandFoes(civ, { ...x, commands: (x.commands ?? []).filter((c) => c.from >= from) });
    if (before.length) out.push({ k: '即位前领兵', ...foesLine(civ, before, era) });
    if (later.length) out.push({ k: '亲征', ...foesLine(civ, later, era) });
  } else if (foes.length) out.push({ k: consul ? '领兵' : '亲征', ...foesLine(civ, foes, era) });
  // 在位时本国领兵的将领
  const until = x.until ?? civ.endYear;
  const gens = peopleIndex(civ).generals[x.polity].filter((g) => (g.commands ?? []).some((c) => c.until > from && c.from < until));
  if (gens.length) out.push({ k: '将领', ...peopleLine(civ, gens) });
  // 在位时在朝的名臣
  const mins = peopleIndex(civ).ministers[x.polity].filter((m) => m.from! < until && (m.until ?? Infinity) > from);
  if (mins.length) out.push({ k: '名臣', ...peopleLine(civ, mins) });
}

/** 宗室:领兵、效力(派他出征的君主,小字写父 / 兄)、结局(战死、争储被杀)、对手(杀他的那位新君) */
function princeLines(civ: Civ, x: Person, out: Line[], era: Era | undefined) {
  const cs = x.commands ?? [];
  const foes = commandFoes(civ, x);
  if (foes.length) out.push({ k: '领兵', ...foesLine(civ, foes, era) });
  if (cs.length) {
    const served = peopleIndex(civ).rulers[x.polity].filter((r) => cs.some((c) => (r.from ?? Infinity) < c.until && (r.until ?? Infinity) > c.from));
    if (served.length === 1) out.push(personRow('效力', civ, served[0], kinOf(civ, x, served[0])));
    else if (served.length) out.push({ k: '效力', ...peopleLine(civ, served) });
  }
  const died = x.died !== undefined ? `，${yearAt(x.died, era)}` : '';
  // 摄政的叔父被亲政的幼主诛杀:伏诛(不是争储)
  const ousted = regentPurged(x);
  const lost = ousted ? '伏诛' : '争储被杀';
  if (x.fate === 'battle') out.push({ k: '结局', node: `战死${died}`, text: `战死${died}` });
  else if (x.fate === 'purged') out.push({ k: '结局', node: `${lost}${died}`, text: `${lost}${died}` });
  const r = x.fate === 'purged' && x.rival !== undefined ? civ.people?.[x.rival] : undefined;
  if (r) {
    const how = ousted ? '亲政后诛之' : ({ coup: '杀他即位', intrigue: '谮杀他得立', usurp: '杀他自立', revolt: '他拥兵争位，兵败被杀', march: '引兵还朝杀他' }[r.claim?.how as string] ?? '杀他即位');
    out.push(personRow('对手', civ, r, [kinOf(civ, x, r), how].filter(Boolean).join('，')));
  }
}

/**
 * 放逐到中立地(争储失势的宗室、被废的君主)/ 出奔(亡国之君):「放逐  星河域 2303 年起，桓王所徙」;
 * 中立地撤销时还活着、回了本国的写"2303–2320 年"(出奔的同一年中立地就撤了:只写"2529 年");
 * 出奔邻国的(Person.exile.to)这里还不写;没有 = null
 */
function exileLine(civ: Civ, x: Person, era: Era | undefined): Line | null {
  const e = x.exile;
  if (!e || e.to !== undefined) return null;
  const zone = regionLabel(civ, e.region);
  const by = e.by !== undefined && e.how !== 'fled' ? civ.people?.[e.by] : undefined;
  const back = e.until !== undefined && !diedInExile(x) && (x.died === undefined || x.died > e.until);
  const when = back ? (Math.floor(e.until!) === Math.floor(e.year) ? yearAt(e.year, era) : yearSpanAt(e.year, e.until!, era)) : `${yearAt(e.year, era)}起`;
  const note = by ? `${when}，${rulerShort(civ, by)}所徙` : when;
  return {
    k: e.how === 'fled' ? '出奔' : '放逐',
    node: (
      <>
        <Link to={{ kind: 'region', id: e.region }}>{zone}</Link>
        <em className="cp-num-note">{note}</em>
      </>
    ),
    text: `${zone}（${note}）`,
  };
}

/**
 * 人物卡「放逐」/「出奔」一段(概况下面):徙居(出奔)那一条、卒于中立地(编年史里没有,这里写一句)、
 * 中立地撤销时还活着的,撤销那一条;新的在上
 */
function ExileEvents({ civ, x }: { civ: Civ; x: Person }) {
  const era = useEra();
  const all = useMemo(() => fullChronicle(civ), [civ]);
  const e = x.exile!;
  const rows: { key: string; year: number; ev: string; node: ReactNode; go: () => void }[] = [];
  const come = all.find((c) => c.kind === 'exile' && c.id === e.annal);
  if (come) rows.push({ key: 'come', year: come.year, ev: evType(come), node: <EntryText civ={civ} e={come} />, go: () => pickChronicleEntry(come) });
  const zone = treatyBook(civ).zones[e.zone];
  const pact = zone ? treatyBook(civ).treaties[zone.treaty] : undefined;
  if (diedInExile(x)) {
    const who = x.role === 'prince' ? princeRef(civ, x, x.died!) : rulerRef(civ, x, x.died!);
    const died = x.died!;
    rows.push({ key: 'died', year: died, ev: 'dynasty', node: <EntryText civ={civ} e={{ text: `${who}卒于${regionLabel(civ, e.region)}`, people: [x.id], year: died }} />, go: () => jumpTo(died) });
  } else if (e.until !== undefined && pact) {
    const end = treatyEntries(civ, pact, all).find((c) => Math.abs(c.year - e.until!) < 1e-6);
    if (end) rows.push({ key: 'end', year: end.year, ev: evType(end), node: <EntryText civ={civ} e={end} />, go: () => pickChronicleEntry(end) });
  }
  if (!rows.length) return null;
  return (
    <section className="cp-sec cp-events" data-exile>
      <div className="cp-sec-head cp-events-head">
        <span>{e.how === 'fled' ? '出奔' : '放逐'}</span>
        <button className="ins-link cp-more" data-act="exile-chronicle" onClick={() => openOverview('chronicle', { polity: x.polity, major: false, at: e.year })}>
          在编年史中查看
        </button>
      </div>
      <div className="cp-group">
        {rows
          .slice()
          .reverse()
          .map((r) => (
            <button key={r.key} className="cp-ev" data-ev={r.ev} onClick={r.go}>
              <span className={`cp-ev-year${era ? ' era' : ''}`}>{yearShort(r.year, era)}</span>
              <span className="cp-ev-text">{r.node}</span>
            </button>
          ))}
      </div>
    </section>
  );
}

/** 宗室卡片下面那一段的标题:领过兵 = 领兵时;争储被杀 = 争储;两样都有 = 领兵、争储 */
function princeHead(x: Person): string {
  const led = !!x.commands?.length;
  const purged = x.fate === 'purged' && !regentPurged(x);
  return led && purged ? '领兵、争储' : purged ? '争储' : '领兵时';
}

/** 掌着实权时被诛(摄政的叔父、专权的大臣大将):结局是伏诛,不是争储被杀 */
function regentPurged(x: Person): boolean {
  return x.fate === 'purged' && !!x.regencies?.some((g) => g.end === 'purged');
}

/**
 * 君主即位时争储怎么得的位(Person.claim):「争储  举兵杀其兄 李瑜，即位」;据地自立的开国之君:「争位  不服其侄 李晔 即位，据云西郡自立」。
 * 对手的名字能点
 */
function claimLine(civ: Civ, x: Person): Line | null {
  const c = x.claim;
  if (!c) return null;
  const rs = c.rivals.map((id) => civ.people?.[id]).filter((r): r is Person => !!r);
  if (!rs.length) return null;
  const east = !!civ.polities[x.polity]?.eastern;
  const kin = (r: Person) => kinOf(civ, x, r);
  const list = (lead: boolean) => ({
    node: rs.map((r, i) => (
      <Fragment key={r.id}>
        {i > 0 && '、'}
        {lead && kin(r) ? `其${kin(r)}` : ''}
        <Link to={{ kind: 'person', id: r.id }}>{r.name}</Link>
      </Fragment>
    )),
    text: rs.map((r) => `${lead && kin(r) ? `其${kin(r)}` : ''}${r.name}`).join('、'),
  });
  let pre = '';
  let post = '';
  if (c.how === 'secede') {
    const a = civ.annals.find((e) => e.kind === 'split' && e.cause === 'heir' && e.a === x.polity);
    const place = a && a.region >= 0 && a.region < civ.regions.count ? regionLabel(civ, a.region) : '';
    pre = '不服';
    post = `即位，${place ? `据${place}` : ''}自立`;
  } else if (c.how === 'merit') {
    pre = `以${east ? '军功' : '战功'}越过`;
    post = '得立';
  } else if (c.how === 'coup') {
    pre = east ? '举兵杀' : '起兵入宫，杀';
    post = '，即位';
  } else if (c.how === 'intrigue') {
    pre = east ? '谮杀' : '构陷';
    post = east ? '得立' : '致死，得立';
  } else if (c.how === 'usurp') {
    pre = '杀';
    post = '自立';
  } else if (c.how === 'march') {
    // 先君在位时引兵入朝、杀了兄弟掌权,那时不即位(先君去世后才即位)
    pre = east ? '引兵还朝，杀' : '率军回都，处死';
    post = east ? '，不即位' : '，未即位';
  } else if (c.how === 'seize') {
    // 摄政的叔父废了幼主自立
    pre = '废';
    post = '自立';
  } else post = '拥兵争位，兵败被杀';
  const l = list(true);
  const k = c.how === 'secede' ? '争位' : '争储';
  return { k, node: <>{pre}{l.node}{post}</>, text: pre + l.text + post };
}

function generalLines(civ: Civ, x: Person, out: Line[], foes: Foe[], era: Era | undefined) {
  const cs = x.commands ?? [];
  if (foes.length) out.push({ k: '领兵', ...foesLine(civ, foes, era) });
  // 效力:他领兵那几年在位的本国君主
  const ix = peopleIndex(civ);
  const served = ix.rulers[x.polity].filter((r) => cs.some((c) => (r.from ?? Infinity) < c.until && (r.until ?? Infinity) > c.from));
  if (served.length) out.push({ k: '效力', ...peopleLine(civ, served) });
  // 对手:同一场仗、同一段时间对面的统帅(君主亲征的也算)
  const foesP: Person[] = [];
  for (const o of civ.people ?? []) {
    if (o.id === x.id || o.polity === x.polity || !o.commands) continue;
    if (o.commands.some((oc) => cs.some((c) => c.war === oc.war && oc.side !== c.side && oc.until > c.from && oc.from < c.until))) foesP.push(o);
  }
  if (foesP.length) out.push({ k: '对手', ...peopleLine(civ, foesP) });
  const last = cs.length ? cs[cs.length - 1].until : x.born;
  let fate = '';
  if (x.killed !== undefined && x.died !== undefined) fate = `${yearAt(x.died, era)}卒（干预）`;
  else if (x.fate === 'battle') fate = x.died !== undefined ? `战死，${yearAt(x.died, era)}` : '战死';
  else if (x.fate === 'purged') fate = x.died !== undefined ? `伏诛，${yearAt(x.died, era)}` : '伏诛';
  else if (x.died !== undefined) fate = x.died - last >= 1 ? `卸甲，${yearAt(x.died, era)}卒` : `${yearAt(x.died, era)}卒于军中`;
  if (fate) out.push({ k: '结局', node: fate, text: fate });
}

/** 推演里作者立的君主:作者的人物卡(删掉了 = null) */
function authorOf(p: Person): AuthorCharacter | null {
  return p.author !== undefined ? (getEdits().characters?.find((c) => c.id === p.author) ?? null) : null;
}

/** 前任 / 继任:人名能点,后面小字写亲属;ac = 作者立的君主,名字前面放他的圆头像 */
function personRow(k: string, civ: Civ, y: Person, note: string, ac?: AuthorCharacter | null): Line {
  const n = personName(civ, y);
  return {
    k,
    node: (
      <>
        {ac && <CharAvatar c={ac} size={18} cls="cr-av" />}
        <Link to={{ kind: 'person', id: y.id }}>{n}</Link>
        {note && <em className="cp-num-note">{note}</em>}
      </>
    ),
    text: note ? `${n}(${note})` : n,
  };
}

/**
 * 「掌权时」那几条(按先后):掌权、还政 / 伏诛 / 卒那几条;幼主即位时的摄政、辅政写在即位那一条,
 * 名臣、大臣篡位写在改朝换代那一条,引兵入朝、监国到先君去世接着即位的写即位那一条
 */
export function heldEvents(civ: Civ, x: Person): ChronicleEntry[] {
  const gs = x.regencies ?? [];
  if (!gs.length) return [];
  const near = (a: number, b: number | undefined) => b !== undefined && Math.abs(a - b) < 1e-6;
  return polityEntries(civ, x.polity).filter((e) =>
    gs.some(
      (g) =>
        (e.kind === 'regent' && (e.id === g.annal || e.id === g.endAnnal)) ||
        (e.kind === 'reign' && !!e.people?.includes(x.id) && (near(e.year, g.from) || (g.end === 'succeed' && near(e.year, g.until)))) ||
        (e.kind === 'dynasty' && g.end === 'usurp' && near(e.year, g.until)),
    ),
  );
}

/** 「联姻」那几条(按先后):结亲那一条(互嫁的并在前一门那一条里),那以后两国本为姻亲时的结盟 */
export function marryEvents(civ: Civ, x: Person): ChronicleEntry[] {
  const ss = x.spouses ?? [];
  if (!ss.length) return [];
  return polityEntries(civ, x.polity).filter((e) =>
    ss.some(
      (s) =>
        (e.kind === 'marry' && (e.id === s.annal || (e.id === s.annal - 1 && !!e.people?.includes(x.id)))) ||
        (e.kind === 'alliance' &&
          e.year > s.year &&
          e.polities.slice(0, 2).includes(s.polity) &&
          e.polities.slice(0, 2).includes(x.polity) &&
          kinAt(civ, x.polity, s.polity, e.year, true) >= 0),
    ),
  );
}

/** 在位时 / 在朝时 / 领兵时的事(按先后) */
export function personEvents(civ: Civ, x: Person): ChronicleEntry[] {
  const all = polityEntries(civ, x.polity);
  const eps = 1e-6;
  if (x.role === 'ruler' || x.role === 'minister') {
    const from = x.from ?? x.born;
    const until = x.until ?? civ.endYear;
    return all.filter((e) => e.year >= from - eps && e.year <= until + eps);
  }
  // 宗室:他经手的那几仗 + 争储被杀的,杀他的那位即位那一条
  if (x.role === 'prince') {
    const cs = x.commands ?? [];
    return all.filter(
      (e) =>
        (e.kind !== 'reign' && cs.some((c) => e.id >= c.first && e.id <= c.last && civ.annals[e.id]?.war === c.war)) ||
        (x.fate === 'purged' && e.kind === 'reign' && !!e.people?.includes(x.id)),
    );
  }
  // 将领:他经手的那几件(宣战、战役、攻占:史事下标在他任期的第一件到最后一件之间)
  const cs = x.commands ?? [];
  const mine = all.filter((e) => e.kind !== 'reign' && cs.some((c) => e.id >= c.first && e.id <= c.last && civ.annals[e.id]?.war === c.war));
  if (mine.length) return mine;
  return all.filter((e) => e.kind !== 'reign' && cs.some((c) => e.year >= c.from - eps && e.year <= c.until + eps));
}
