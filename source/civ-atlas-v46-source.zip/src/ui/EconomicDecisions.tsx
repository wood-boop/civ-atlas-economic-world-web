/** Recorded native decisions; these views never schedule work or mutate a model. */
import type { Civ } from '../gen/civ/types';
import { economicStrategyAt } from '../gen/civ/economicStrategy';
import type { EconomicPriority, EconomicReason } from '../gen/civ/economicStrategyTypes';
import { ECONOMY_GOODS } from '../gen/civ/economy';
import { polityName } from '../gen/civ/growth';
import { regionLabel } from '../gen/civ/display';
import { yearAt } from '../gen/era';
import { useEra } from './editsStore';
import { Link } from './panelParts';

const number = (n: number) => n.toLocaleString('zh-CN', { maximumFractionDigits: n < 10 ? 2 : 1 });
const percent = (n: number) => `${number(n * 100)}%`;
const PRIORITIES: Record<EconomicPriority, string> = { 0: '维持民间生产', 1: '粮食供给', 2: '产业设备', 3: '运输设施', 4: '供给韧性' };
const REASONS: Record<EconomicReason, string> = {
  food_shortage: '粮食不足', tool_bottleneck: '工具瓶颈', material_shortage: '原料短缺',
  trade_dependence: '依赖州际来货', fiscal_stress: '国库承压', industry_opportunity: '产业扩建机会',
  logistics_gap: '运输不足', war_risk: '战争与供给风险', manual_policy: '遵循原生发展方针',
  no_observation: '尚无前一年经济观测', idle_capacity: '现有产能闲置',
};

export function EconomicDecisions({ civ, year, country }: { civ: Civ; year: number; country: number }) {
  const era = useEra();
  const snapshot = economicStrategyAt(civ, year);
  const decision = snapshot?.countries.find((d) => d.country === country);
  if (!snapshot || !decision) return <section className="ne-decision" data-economic-decision="missing">
    <div className="ne-minor-head">经济影响决策</div><p className="ne-note">这个年份尚无保留的经济决策记录；上方生产观测不能当作已执行的建设计划。</p>
  </section>;
  const observed = decision.sourceYear !== null;
  const unspent = Math.max(0, decision.plannedBudget - decision.publicSpend);
  const relations = snapshot.relations.filter((r) => r.from === country)
    .sort((a, b) => b.warOpportunityCost - a.warOpportunityCost || b.importValue - a.importValue).slice(0, 3);
  return <section className="ne-decision" data-economic-decision={decision.priority} data-decision-year={decision.year}>
    <div className="ne-decision-head"><strong>经济影响决策</strong><span>{yearAt(decision.year, era)}决策</span></div>
    {snapshot.year < year && <p className="ne-note">时间轴在{yearAt(year, era)}；这里显示此前最近保留的决策，未补造中间年份。</p>}
    <div className="ne-decision-choice">{PRIORITIES[decision.priority]}</div>
    <p className="ne-note"><b>决策依据：</b>{decision.sourceYear !== null ? `${yearAt(decision.sourceYear, era)}已完成的生产观测；` : ''}{decision.reasons.map((r) => REASONS[r]).join('、')}。</p>
    <dl className="ne-facts">
      <div><dt>年度计划额度</dt><dd>{number(decision.plannedBudget)} 千石等值</dd></div>
      <div><dt>实物项目支出</dt><dd>{number(decision.publicSpend)} 千石等值</dd></div>
      <div><dt>计划内未实施</dt><dd>{number(unspent)} 千石等值</dd></div>
    </dl>
    <p className="ne-note">计划额度受原有国库与已承诺开销约束，不能预支未收税款。{unspent > 0.005 ? '本次额度未全部形成项目；' : ''}实际建设还受物料、劳力及生产条件限制；只有实际实施的实物项目支出扣入原有国库。</p>
    {observed && <details className="ne-decision-detail"><summary>供给、战争与外交权重</summary>
      <dl className="ne-facts">
        <div><dt>依据年份粮食满足</dt><dd>{percent(decision.foodAdequacy)}</dd></div>
        <div><dt>调入供给依存</dt><dd>{percent(decision.importDependence)}</dd></div>
        <div><dt>经济续战系数</dt><dd>{number(decision.warReadiness)} 倍</dd></div>
      </dl>
      <p className="ne-note">调入依存从总调入中扣除了已识别的境内调运；未保留批次的来向不详，不能当作完整对外进口率。续战系数把粮食和国库压力带入原生开战判断，衡量经济支撑能力；实际战力另由原生军事模型决定。</p>
      {decision.tradePartner !== undefined && civ.polities[decision.tradePartner] && <p className="ne-note">记录内主要来货伙伴：<Link to={{ kind: 'polity', id: decision.tradePartner }}>{polityName(civ.polities[decision.tradePartner], decision.sourceYear!)}</Link>。</p>}
      {decision.supplyRegion !== undefined && <p className="ne-note">记录内可补 {ECONOMY_GOODS[decision.topScarceGood]} 的州：<Link to={{ kind: 'region', id: decision.supplyRegion }}>{regionLabel(civ, decision.supplyRegion)}</Link>。补充供给的潜力会进入扩张目标估值。</p>}
      {relations.length > 0 && <div className="ne-table-scroll"><table className="ne-table"><caption>对外供给关系（保留运输明细）</caption>
        <thead><tr><th scope="col">国家</th><th scope="col">开战供给代价指数</th><th scope="col">求和 / 结盟权重</th></tr></thead>
        <tbody>{relations.map((r) => <tr key={r.to}><th scope="row"><Link to={{ kind: 'polity', id: r.to }}>{civ.polities[r.to] ? polityName(civ.polities[r.to], decision.sourceYear!) : `国家 ${r.to + 1}`}</Link></th>
          <td>{percent(r.warOpportunityCost)}</td><td>{number(r.peaceValue)} / {number(r.allianceValue)} 倍</td></tr>)}</tbody>
      </table></div>}
      <p className="ne-note">已记录伙伴的来货、中断供给风险及互补性影响开战、求和和结盟权重；权重是判断依据，不能视为已宣战或缔约。运输明细只保留最大批次，未列伙伴不表示没有往来。</p>
    </details>}
  </section>;
}
