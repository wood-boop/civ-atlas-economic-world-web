/**
 * 点选(阶段 4)· 文字层上点到了什么:CivLayer 每次排完地图文字就把结果(放上去的城镇符号、每个字的位置)记在这里,
 * App 单击地图时按屏幕坐标查 —— 城镇符号、城名、国名、地名(海、山、河、湖、岛、荒漠、关隘;关隘的符号也算)。
 * 都没点到时 App 再按地块查国土 / 州。
 */
import { placedMarkBox, type LabelView, type Placement } from '../render/labels/draw';
import { glyphBox } from '../render/labels/layout';
import { placedTextBoxes } from '../render/marks';
import { passOfMark } from '../render/civ/passes';

export interface LabelPick {
  kind: 'polity' | 'settlement' | 'place';
  id: number;
}

interface Snapshot {
  canvas: HTMLCanvasElement;
  placed: Placement;
  view: LabelView;
}

let last: Snapshot | null = null;
/** 每排一次文字加一 */
let ver = 0;
/** placedTextBoxes 按排版结果记一份(同一次排版不重算) */
let boxes: { placed: Placement; list: number[][] } | null = null;

/** CivLayer 排完文字调(没画字时传 null) */
export function setMapPlacement(s: Snapshot | null) {
  last = s;
  ver++;
}

/**
 * 地图上城名、地名、城镇符号占的地方(屏幕坐标的框,见 render/marks.ts 的 placedTextBoxes):作者标记的名字尽量躲开。
 * ver 变了 = 文字重新排过;没有文字层(地球仪、还没画字)= 空
 */
export function mapTextBoxes(): { ver: number; list: number[][] } {
  if (!last || !last.canvas.isConnected) return { ver, list: [] };
  const { canvas, placed } = last;
  const r = canvas.getBoundingClientRect();
  if (!r.width || !canvas.width) return { ver, list: [] };
  if (boxes?.placed !== placed) boxes = { placed, list: placedTextBoxes(placed) };
  const f = r.width / canvas.width;
  return { ver, list: boxes.list.map((b) => [r.left + b[0] * f, r.top + b[1] * f, r.left + b[2] * f, r.top + b[3] * f]) };
}

/** 符号编号 → 点到的是什么:关隘的符号 = 那一处地名,别的 = 城(含故城遗址) */
export function markPick(id: number): LabelPick {
  const p = passOfMark(id);
  return p >= 0 ? { kind: 'place', id: p } : { kind: 'settlement', id };
}

/** 点到符号 / 字的容差(屏幕像素):小符号、细字也好点 */
const SLOP = 4;
/** 城镇符号的点选框至少这么大(屏幕像素,见方) */
const MIN_MARK = 14;

/**
 * 屏幕坐标(clientX / clientY)→ 点到的城镇符号、城名、国名、地名;没点到 = null。
 * 几样都点到时取离字 / 符号中心最近的(文字和符号互相避让,很少重叠)
 */
export function pickLabelAt(clientX: number, clientY: number): LabelPick | null {
  if (!last || !last.canvas.isConnected) return null;
  const { canvas, placed } = last;
  const r = canvas.getBoundingClientRect();
  if (!r.width || !r.height || !canvas.width) return null;
  /** 画布像素 / 屏幕像素 */
  const f = canvas.width / r.width;
  const x = (clientX - r.left) * f;
  const y = (clientY - r.top) * f;
  if (x < 0 || y < 0 || x > canvas.width || y > canvas.height) return null;
  let best: LabelPick | null = null;
  let bestD = Infinity;
  const consider = (pick: LabelPick, b: [number, number, number, number]) => {
    if (x < b[0] || x > b[2] || y < b[1] || y > b[3]) return;
    const d = Math.hypot(x - (b[0] + b[2]) / 2, y - (b[1] + b[3]) / 2);
    if (d < bestD) {
      bestD = d;
      best = pick;
    }
  };
  for (const m of placed.marks) {
    const b = placedMarkBox(m);
    const cx = (b[0] + b[2]) / 2;
    const cy = (b[1] + b[3]) / 2;
    const hw = Math.max((b[2] - b[0]) / 2 + SLOP * f, (MIN_MARK / 2) * f);
    const hh = Math.max((b[3] - b[1]) / 2 + SLOP * f, (MIN_MARK / 2) * f);
    consider(markPick(m.mark.id), [cx - hw, cy - hh, cx + hw, cy + hh]);
  }
  for (const l of placed.labels) {
    const pk = l.item.pick;
    if (!pk || l.alpha < 0.3) continue;
    for (const g of l.glyphs) consider(pk, glyphBox(g, l.px, SLOP * f));
  }
  return best;
}

/** 放标记时点偏一点也算点到关口符号(屏幕像素) */
const PASS_SNAP = 10;

/**
 * 放标记时点到的关:关口符号(放宽到 PASS_SNAP 像素)或关名;返回 civ.places 的下标,没点到 = −1。
 * 几处都点到时取离符号中心最近的
 */
export function passAt(clientX: number, clientY: number): number {
  if (!last || !last.canvas.isConnected) return -1;
  const { canvas, placed } = last;
  const r = canvas.getBoundingClientRect();
  if (!r.width || !r.height || !canvas.width) return -1;
  const f = canvas.width / r.width;
  const x = (clientX - r.left) * f;
  const y = (clientY - r.top) * f;
  let best = -1;
  let bestD = Infinity;
  const shown = new Set<number>();
  for (const m of placed.marks) {
    const p = passOfMark(m.mark.id);
    if (p < 0) continue;
    shown.add(p);
    const b = placedMarkBox(m);
    const hw = (b[2] - b[0]) / 2 + PASS_SNAP * f;
    const hh = (b[3] - b[1]) / 2 + PASS_SNAP * f;
    const dx = Math.abs(x - (b[0] + b[2]) / 2);
    const dy = Math.abs(y - (b[1] + b[3]) / 2);
    if (dx > hw || dy > hh) continue;
    const d = Math.hypot(dx, dy);
    if (d < bestD) [best, bestD] = [p, d];
  }
  if (best >= 0) return best;
  // 关名(符号画出来了的那几处)
  for (const l of placed.labels) {
    const pk = l.item.pick;
    if (!pk || pk.kind !== 'place' || !shown.has(pk.id) || l.alpha < 0.3) continue;
    for (const g of l.glyphs) {
      const b = glyphBox(g, l.px, SLOP * f);
      if (x >= b[0] && x <= b[2] && y >= b[1] && y <= b[3]) return pk.id;
    }
  }
  return -1;
}

/** 这一处地名(civ.places 的下标)的名字现在写在地图上没有(文字层排好的;地球仪、还没画字 = 没有) */
export function placeNameShown(id: number): boolean {
  if (!last || !last.canvas.isConnected) return false;
  return last.placed.labels.some((l) => l.item.pick?.kind === 'place' && l.item.pick.id === id && l.alpha >= 0.3);
}

/**
 * 冒烟检查用:文字层上现在能点的东西(城镇符号 + 文字),屏幕坐标。
 * window.__wfPickables() 返回 [{ kind, id, text, x, y }](符号的 text 为空;城镇符号 kind = 'mark'、id = 城,
 * 关隘的符号 kind = 'pass'、id = civ.places 的下标)
 */
export function pickables(): { kind: string; id: number; text: string; x: number; y: number }[] {
  if (!last || !last.canvas.isConnected) return [];
  const { canvas, placed } = last;
  const r = canvas.getBoundingClientRect();
  const f = r.width / canvas.width;
  const out: { kind: string; id: number; text: string; x: number; y: number }[] = [];
  for (const m of placed.marks) {
    const b = placedMarkBox(m);
    const pass = passOfMark(m.mark.id);
    out.push({ kind: pass >= 0 ? 'pass' : 'mark', id: pass >= 0 ? pass : m.mark.id, text: '', x: r.left + ((b[0] + b[2]) / 2) * f, y: r.top + ((b[1] + b[3]) / 2) * f });
  }
  for (const l of placed.labels) {
    const pk = l.item.pick;
    if (!pk || !l.glyphs.length) continue;
    const g = l.glyphs[Math.floor(l.glyphs.length / 2)];
    out.push({ kind: pk.kind, id: pk.id, text: l.item.text, x: r.left + g.x * f, y: r.top + g.y * f });
  }
  return out;
}

if (typeof window !== 'undefined') (window as unknown as { __wfPickables: typeof pickables }).__wfPickables = pickables;
