/**
 * 界面里指向外面的几个固定网址(世界概览底部的一行小字、AI 设置里的说明)。
 *
 *   SOURCE_URL   源代码仓库(本项目按 AGPL-3.0 开源)
 *   PRIVACY_URL  隐私政策(public/privacy.html)
 *   TERMS_URL    用户协议(public/terms.html)
 *   GUIDE_URL    使用教程(public/guide.html;正文是同目录的 guide.md,改教程只改那份文字)
 *
 * 两个说明页是 public/ 里的静态网页,和地图放在同一个目录下,所以用相对地址(网站放在子目录里也能打开)。
 * 仓库地址改了的话,public/privacy.html、public/terms.html 里写死的仓库地址要一起改(冒烟检查会比对)。
 * 「联系我们」的交流群不在这里:网站根目录的 contact.json,随时能换(见 contact.ts)。
 */
export const SOURCE_URL = './source/';
export const PRIVACY_URL = './privacy.html';
export const TERMS_URL = './terms.html';
export const GUIDE_URL = './guide.html';
