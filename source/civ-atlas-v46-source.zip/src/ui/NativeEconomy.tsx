/** Economic observations belong to the native map selection and historical clock. */
import { useMemo } from 'react';
import type { Civ } from '../gen/civ/types';
import type { EconomySnapshot } from '../gen/civ/economyTypes';
import { economyAt, ECONOMY_GOODS, ECONOMY_SECTORS } from '../gen/civ/economy';
import { regionLabel } from '../gen/civ/display';
import { populationAt } from '../gen/civ/growth';
import { yearAt } from '../gen/era';
import { useEra } from './editsStore';
import { closeOverview } from './overviewStore';
import { setSelection } from './civView';
import { openInfoPage } from './panelStore';
import { Link, Row, Stats } from './panelParts';
import { economyDistribution, economyRegions, summarizeEconomy, type EconomyScope, type EconomySummary } from './economyInfo';
import { EconomicDecisions } from './EconomicDecisions';
import './nativeEconomy.css';

const number = (n: number) => n > 0 && n < 0.005 ? '<0.01' : n.toLocaleString('zh-CN', { maximumFractionDigits: n < 10 ? 2 : 1 });
const percent = (n: number) => `${(n * 100).toLocaleString('zh-CN', { maximumFractionDigits: n > 0 && n < 0.01 ? 2 : 1 })}%`;
const FOOD_SUFFICIENT = 1 - 1e-6;
const quantity = (n: number, good: number) => `${number(n)} ${good === 0 ? '千石' : '单位'}`;

function useEconomy(civ: Civ, year: number, scope: EconomyScope) {
  const id = scope.kind === 'world' ? -1 : scope.id;
  return useMemo(() => {
    const snapshot = economyAt(civ, year);
    if (!snapshot) return null;
    const regions = economyRegions(civ, year, scope, snapshot.count);
    return { snapshot, regions, total: summarizeEconomy(snapshot, regions) };
  }, [civ, year, scope.kind, id]);
}

/** Used in country, region, city and fiscal panels; a city shows its own region's chain, never an invented city balance. */
export function NativeEconomy({ civ, year, scope, city, fiscal = false }: {
  civ: Civ; year: number; scope: EconomyScope; city?: number; fiscal?: boolean;
}) {
  const era = useEra();
  const view = useEconomy(civ, year, scope);
  const snapshot = view?.snapshot;
  const first = civ.development?.economy?.history[0]?.year;
  const missing = first !== undefined && year < first
    ? `${yearAt(year, era)}的经济记录未保留，现有记录始于${yearAt(first, era)}。`
    : '这份历史还没有生产与贸易记录。按原有历史继续推演后可在这里查看。';
  if (!view || !snapshot) return <section className="cp-sec ne-section" data-economy="missing"><div className="cp-sec-head">生产与生计</div><p className="ne-note">{missing}</p></section>;
  const { total, regions } = view;
  const region = scope.kind === 'region' ? scope.id : undefined;
  const cityPresent = city === undefined || populationAt(civ.settlements[city], year) > 0;
  const regionalCities = region === undefined ? [] : civ.settlements.filter((s) => s.region === region && populationAt(s, year) > 0);
  return (
    <section className="ne-section" data-economy={scope.kind} data-economy-year={snapshot.year}>
      <Stats title={fiscal ? '税源与生产' : '生产与生计'} items={[]} more={<span className="ne-record">{yearAt(snapshot.year, era)}记录</span>}>
        <Row k="粮食">
          <span className={total.foodAdequacy < FOOD_SUFFICIENT ? 'ne-short' : ''}>满足 {percent(total.foodAdequacy)}</span>
          <em className="cp-num-note">年产 {quantity(total.output[0], 0)} / 需求 {quantity(total.foodNeed, 0)}</em>
        </Row>
        <Row k="生活需要">{total.livingStandard === null ? '未记录' : `满足 ${percent(total.livingStandard)}`}<em className="cp-num-note">居民实物消费 / 需求，固定折粮加权</em></Row>
        <Row k="已录用工">{number(total.workforce)} 千人<em className="cp-num-note">其中维修建设 {number(total.investmentLabor)} 千人{total.transportLabor !== null && ` · 运输 ${number(total.transportLabor)} 千人`}</em></Row>
        <Row k="产值">{number(total.outputValue)} 千石 / 年<em className="cp-num-note">扣除产业中间投入</em></Row>
        <Row k="税源折算">
          {number(total.taxContribution)} 千石 / 年
          {scope.kind === 'polity' && !fiscal && <button className="ins-link ne-fiscal" onClick={() => openInfoPage('fiscal')}>查看钱粮 ›</button>}
          <em className="cp-num-note">按原有税率折算，实收由钱粮结算</em>
        </Row>
      </Stats>
      <div className="ne-context">
        {snapshot.year < year && <p className="ne-note">时间轴在{yearAt(year, era)}；以下采用此前最近记录，按这一年的疆域汇总。</p>}
        {city !== undefined && <p className="ne-note">{cityPresent ? '这座城参与所在州的生产与消费。' : '这座城在当前年份已无居民。'}以下是 <Link to={{ kind: 'region', id: civ.settlements[city].region }}>{regionLabel(civ, civ.settlements[city].region)}</Link> 的区域账。</p>}
        {regionalCities.length > 0 && city === undefined && <p className="ne-note">城镇与乡村共同生产：{regionalCities.map((s, i) => <span key={s.id}>{i > 0 && '、'}<Link to={{ kind: 'settlement', id: s.id }}>{s.name}</Link></span>)}。</p>}
        <p className={`ne-note${total.foodAdequacy < FOOD_SUFFICIENT ? ' ne-short' : ''}`}>粮食{total.foodAdequacy < FOOD_SUFFICIENT ? `缺口 ${percent(1 - total.foodAdequacy)}` : '需求得到满足'}；生产与供给使下一阶段人口承载上限为基准的 {percent(total.capacityFactor)}。</p>
        <p className="ne-note">观测范围：{regions.length} 州，原生人口 {number(total.population)} 千人。{total.laborComplete ? `已录用工占可用劳力 ${percent(total.laborSupply > 0 ? total.workforce / total.laborSupply : 0)}；劳力上限为原生人口的 52%。` : '这条旧记录未单列运输劳力，用工为已保留项目之和。'}</p>
      </div>
      <HouseholdNeeds total={total} />
      {scope.kind === 'polity' && <EconomicDecisions civ={civ} year={year} country={scope.id} />}
      <details className="ne-details" open={fiscal || undefined}>
        <summary>产业链、物资与贸易</summary>
        <IndustryTable total={total} />
        <div className="ne-tax-breakdown">田赋 {number(total.landTax)} · 工商 {number(total.craftTax)} · 市税 {number(total.tradeTax)} 千石 / 年。无国家的州不征缴；地方截留按原有管辖规则结算。</div>
        <TradeList civ={civ} snapshot={snapshot} regions={regions} />
      </details>
    </section>
  );
}

function HouseholdNeeds({ total }: { total: EconomySummary }) {
  const shortages = total.householdShortages;
  return <details className="ne-details ne-households">
    <summary>居民需求与生计{shortages && ` · ${shortages.length > 0 ? `${shortages.length} 类未满足` : '已满足已录需求'}`}</summary>
    {total.desiredConsumption && total.needSatisfaction ? <div className="ne-table-scroll"><table className="ne-table">
      <caption>居民实物需求（不含产业投入）</caption>
      <thead><tr><th scope="col">物资</th><th scope="col">年需</th><th scope="col">实际消费</th><th scope="col">满足</th></tr></thead>
      <tbody>{ECONOMY_GOODS.map((good, g) => total.desiredConsumption![g] > 0 ? <tr key={good}>
        <th scope="row">{good}</th><td>{number(total.desiredConsumption![g])}</td><td>{number(total.consumption[g])}</td>
        <td className={total.needSatisfaction![g]! < FOOD_SUFFICIENT ? 'ne-short' : undefined}>{percent(total.needSatisfaction![g]!)}</td>
      </tr> : null)}</tbody>
    </table></div> : <p className="ne-note">此条旧记录未保留完整居民需求，无法判断燃料、工具与制品是否充足。</p>}
    {shortages && shortages.length > 0 && <p className="ne-note ne-short">供给最紧：{shortages.slice(0, 3).map((x) => `${ECONOMY_GOODS[x.good]}满足 ${percent(x.satisfaction)}`).join('、')}。</p>}
    <p className="ne-note">生活需要满足度把粮食、燃料、工具与制品等实际居民消费和所需用量按固定价格折粮，比较已满足份额；按需求加权。它衡量同一批原生居民的实物供给，不能解释为家庭财产或货币收入。粮食以千石计，其余为标准实物单位。</p>
  </details>;
}

function IndustryTable({ total }: { total: EconomySummary }) {
  return <>
    <div className="ne-chain">农牧渔供粮 · 林业、采矿与燃料 → 冶炼 → 工具 → 工坊</div>
    <div className="ne-table-scroll">
      <table className="ne-table">
        <caption>年度产业链与期末物资</caption>
        <thead><tr><th scope="col">行业 / 物资</th><th scope="col">年产 / 设备产能</th><th scope="col">投入 / 消费</th><th scope="col">存量 / 超储</th><th scope="col">价格</th><th scope="col">用工</th><th scope="col">经营回报估值</th></tr></thead>
        <tbody>{ECONOMY_GOODS.map((good, g) => <tr key={good}>
          <th scope="row">{ECONOMY_SECTORS[g]}<small>{good}</small></th>
          <td>{number(total.output[g])}<small>/ {number(total.capacity[g])}</small>{total.unmetOutput[g] > 0.005 && <small className="ne-short">缺产 {number(total.unmetOutput[g])}</small>}</td>
          <td>{number(total.inputs[g])}<small>/ {number(total.consumption[g])}</small></td>
          <td>{number(total.inventory[g])}<small>/ {total.unsoldStock ? number(total.unsoldStock[g]) : '未记录'}</small><small>{g === 0 ? '千石' : '单位'}</small></td>
          <td>{number(total.minPrices[g])}{Math.abs(total.maxPrices[g] - total.minPrices[g]) > 0.005 && `–${number(total.maxPrices[g])}`}<small>千石 / 单位</small></td>
          <td>{number(total.labor[g])}<small>千人</small></td>
          <td>{total.operatingSurplus ? number(total.operatingSurplus[g]) : '未记录'}<small>千石等值 / 年</small></td>
        </tr>)}</tbody>
      </table>
    </div>
    {total.bottlenecks.length > 0 && <p className="ne-note ne-short">结构瓶颈：{total.bottlenecks.slice(0, 3).map((x) => `${ECONOMY_GOODS[x.good]}缺产 ${percent(x.share)}`).join('、')}。缺产占本行业期望产出；原料、产能、劳力共同约束，不能单凭此比值判断具体成因。</p>}
    <p className="ne-note">维修建设另用工 {number(total.investmentLabor)} 千人，已计入劳力总数。{total.transportLabor !== null && `运输另用工 ${number(total.transportLabor)} 千人。`}{total.transportCapital !== null && `运输设备 ${number(total.transportCapital)} 标准运力。`}粮食以千石计，其余为各物资的标准实物单位。设备产能按实物年吞吐计，技术会改善利用；农林与木具另有受土地、可用资源、实料和劳力限制的低效手工生产，天然资料的基础吞吐不计为设备，年产可高于设备产能。投入供下游产业使用，消费供居民使用。价格为各州的市价范围。</p>
    <div className="ne-table-scroll"><table className="ne-table">
      <caption>实物去向：当年使用可含往年存货及调入物资</caption>
      <thead><tr><th scope="col">物资</th><th scope="col">产业 / 居民使用</th><th scope="col">维修建设消耗</th><th scope="col">调出</th></tr></thead>
      <tbody>{ECONOMY_GOODS.map((good, g) => <tr key={good}><th scope="row">{good}</th><td>{number(total.inputs[g])} / {number(total.consumption[g])}</td><td>{number(total.investment[g])}</td><td>{number(total.exports[g])}</td></tr>)}</tbody>
    </table></div>
    <p className="ne-note">超储为期末存货超过下一年周转储备的部分。经营回报估值只按当年产出中已使用或售出的部分估价，扣除实际投入、劳力机会成本及设备折耗；积压产出不会全部算作实现回报。这里没有企业现金利润或银行货币账户。</p>
    <p className="ne-note">州际供给依存：{total.importDependence === null ? '未记录' : percent(total.importDependence)}，含本国州际调运，按实物使用折粮加权；不能解释为对外国的进口依赖。{total.publicSpend !== null && `本范围当年实物项目支出 ${number(total.publicSpend)} 千石等值，由所属国家原有国库结算。`}</p>
    <div className="ne-transfers">{ECONOMY_GOODS.map((good, g) => total.imports[g] > 0.005 || total.exports[g] > 0.005 ? <span key={good}>{good}：调入 {number(total.imports[g])} / 调出 {number(total.exports[g])}</span> : null)}</div>
  </>;
}

function TradeList({ civ, snapshot, regions }: { civ: Civ; snapshot: EconomySnapshot; regions: readonly number[] }) {
  const selected = new Set(regions);
  const trades = snapshot.trade.filter((t) => selected.has(t.from) || selected.has(t.to));
  const shown = trades.slice().sort((a, b) => b.value - a.value).slice(0, 6);
  return <div className="ne-trade">
    <div className="ne-minor-head">州际运输记录</div>
    {shown.length === 0 ? <p className="ne-note">本次记录没有涉及这些州的实际调运。</p> : shown.map((t, i) => <div key={`${t.from}-${t.to}-${t.good}-${i}`} className="ne-trade-row">
      <span><Link to={{ kind: 'region', id: t.from }}>{regionLabel(civ, t.from)}</Link> → <Link to={{ kind: 'region', id: t.to }}>{regionLabel(civ, t.to)}</Link></span>
      <span>{ECONOMY_GOODS[t.good]} {quantity(t.quantity, t.good)}<small>货值 {number(t.value)} · 损耗折值 {number(t.cost)} 千石</small></span>
    </div>)}
    <p className="ne-note">调入、调出包含境内州际运输。展示保留的运输记录中货值最高的 {shown.length} 条。</p>
  </div>;
}

/** Compact entry in the existing World Overview, with direct links back to native regions. */
export function WorldEconomySummary({ civ, year }: { civ: Civ; year: number }) {
  const era = useEra();
  const view = useEconomy(civ, year, { kind: 'world' });
  if (!view) return null;
  const { total, snapshot, regions } = view;
  const distribution = economyDistribution(snapshot, regions);
  const shortages = regions.filter((r) => snapshot.foodNeed[r] > 0 && snapshot.foodAdequacy[r] < FOOD_SUFFICIENT).sort((a, b) => snapshot.foodAdequacy[a] - snapshot.foodAdequacy[b]);
  const locate = (r: number) => { closeOverview(); setSelection({ kind: 'region', id: r }); };
  return <section className="ne-world" data-economy="world" data-economy-year={snapshot.year}>
    <div className="ne-world-head"><strong>生产与生计</strong><span>{yearAt(snapshot.year, era)}记录{snapshot.year < year && ` · 时间轴 ${yearAt(year, era)}`}</span></div>
    <div className="ne-world-metrics">
      <span><small>粮食满足</small><b className={total.foodAdequacy < FOOD_SUFFICIENT ? 'ne-short' : ''}>{percent(total.foodAdequacy)}</b></span>
      <span><small>非粮需求不足</small><b>{distribution.nonfoodShortages === null ? '未记录' : distribution.nonfoodShortages.length} <em>{distribution.nonfoodShortages !== null && '州'}</em></b></span>
      <span><small>年净产值</small><b>{number(total.outputValue)} <em>千石</em></b></span>
      <span><small>粮食不足</small><b>{shortages.length} <em>州</em></b></span>
    </div>
    {shortages.length > 0 && <p className="ne-note">供给最紧：{shortages.slice(0, 5).map((r, i) => <span key={r}>{i > 0 && '、'}<button className="ov-link" onClick={() => locate(r)}>{regionLabel(civ, r)}</button> {percent(snapshot.foodAdequacy[r])}</span>)}。点击州名查看产业与运输。</p>}
    {distribution.unmetNeeds && <p className="ne-note">{distribution.inhabited} 个有人居住的州中，{distribution.unmetNeeds.length} 州至少一类居民需求未满足，涉及原生人口 {number(distribution.affectedPopulation!)} 千人。{distribution.unmetNeeds.length > 0 && <>最紧：{distribution.unmetNeeds.slice(0, 4).map((x, i) => <span key={x.region}>{i > 0 && '、'}<button className="ov-link" onClick={() => locate(x.region)}>{regionLabel(civ, x.region)}</button> {ECONOMY_GOODS[x.good]} {percent(x.satisfaction)}</span>)}。</>}</p>}
    {distribution.livingRange && <p className="ne-note">生活需要满足度：需求加权 {total.livingStandard === null ? '未记录' : percent(total.livingStandard)}，各州 {percent(distribution.livingRange[0])}–{percent(distribution.livingRange[1])}。低值州：{distribution.livingLow!.map((x, i) => <span key={x.region}>{i > 0 && '、'}<button className="ov-link" onClick={() => locate(x.region)}>{regionLabel(civ, x.region)}</button> {percent(x.value)}</span>)}。粮食满足仍可能伴随其他物资不足。</p>}
    {!distribution.needs && <p className="ne-note">此条旧记录未保留完整居民需求分布；粮食充足不能据此推断其他生活物资充足。</p>}
  </section>;
}
