/**
 * 图层弹层(LayerPopover.tsx)里的文明开关和图例:
 *
 *   CivToggles     图层面板「叠加」的开关(三个一行):地名、州、城址、道路、战事、宜居度、物产、瘟疫(可以同时开几个,再点一次关闭);
 *                  开着宜居度 / 道路 / 战事 / 瘟疫时下面一行小图例(贫瘠 → 富饶的色带;大路 / 小路 / 航线;战线 / 战时易手 / 交战处 / 疫区 / 荒地)
 *   CultureLegend  选中"民族"图层时:这一年还在的民族,按地盘大小排的紧凑色块列表(族名 + 州数)
 *   FaithLegend    选中"信仰"图层时:这一年的信仰,和侧栏「信仰」一组同样的顺序(大教、跟着它的教派、最后民间信仰)
 *
 * 国家的图例不再单独放:世界概览的"国家"页就是(WorldOverviewCountries.tsx)。
 */
import { useMemo, useSyncExternalStore } from 'react';
import type { Civ } from '../gen/civ/types';
import type { CivShow } from '../render/civ/overlay';
import { HABITAT_RAMP } from '../render/civ/debug';
import { KIND_INFO, cultureLabel } from '../gen/civ/display';
import { ownersAt, type Owners } from '../gen/civ/timeline';
import { faithRows } from '../gen/civ/religionText';
import { yearFull } from '../gen/era';
import { useEra } from './editsStore';
import { getCivTime, setCivShow, setNamesShown, subscribeCivTime, useCivShow } from './civView';
import { civFillOf, namesOn, type CivNameKind } from '../render/civ/show';

const TOGGLES: { key: Exclude<keyof CivShow, 'polities' | 'cultures' | 'faiths' | 'eras' | 'control' | 'names'>; name: string; hint: string }[] = [
  { key: 'labels', name: '地名', hint: '海洋、山脉、大河、湖泊、大岛、荒漠的名字;放大地图显示更多' },
  { key: 'regions', name: '州', hint: '按山脊、大河自然划分的地区,是文明扩张的基本单位' },
  { key: 'sites', name: '城址', hint: '每州最宜居的一块地;圆点越大,这一州能养活的人越多' },
  { key: 'routes', name: '道路', hint: '实线是大城之间的大路,虚线是小路;海上的点线是港口之间的航线' },
  { key: 'wars', name: '战事', hint: '正在打的仗(开着国家时画):红线是战线,斜线是这场仗里易手的州,双剑是打过仗的地方' },
  { key: 'habitat', name: '宜居度', hint: '哪里适合住人:颜色越深越宜居;不上色的是冰原等不可居之地' },
  { key: 'resources', name: '物产', hint: '州治上的圆章:这一州出什么、这一年能用多少;侧栏里能只看一样' },
  { key: 'plague', name: '瘟疫', hint: '正在闹瘟疫的地方(开着国家时画):墨点越密死的人越多,疫过几年淡掉;全球大疫以后人少了的地方地色褪灰(荒地)' },
];

/** "道路"图例:实线大路、虚线小路、点线航线 */
const ROUTE_LEGEND: { name: string; dash?: string; width: number }[] = [
  { name: '大路', width: 2 },
  { name: '小路', dash: '3 2.5', width: 1.3 },
  { name: '航线', dash: '0.1 3.5', width: 2 },
];

const NAME_TOGGLES: { kind: CivNameKind; name: string }[] = [
  { kind: 'polities', name: '国名' },
  { kind: 'cultures', name: '族名' },
  { kind: 'faiths', name: '教名' },
  { kind: 'eras', name: '时代名' },
];

/**
 * 「地图上写」:填色说明下面一行,地图上写哪些名字(每种填色各记各的,换填色时按那种填色记着的勾好;
 * 没勾过的按默认:国家、信仰、时代、管辖写国名,民族写族名,信仰写教名,时代写时代名,不填都不写;管辖填色只有国名可选)
 */
export function NameToggles() {
  const show = useCivShow();
  const only = civFillOf(show) === 'control' ? NAME_TOGGLES.filter((t) => t.kind === 'polities') : NAME_TOGGLES;
  return (
    <div className="lp-names" role="group" aria-label="地图上写">
      <span className="lp-names-k">地图上写</span>
      {only.map(({ kind, name }) => {
        const on = namesOn(show, kind);
        return (
          <button key={kind} className={`lp-tog${on ? ' on' : ''}`} role="checkbox" aria-checked={on} data-names={kind} onClick={() => setNamesShown(kind, !on)}>
            <span className="lp-box" aria-hidden="true">
              {on ? '✓' : ''}
            </span>
            {name}
          </button>
        );
      })}
    </div>
  );
}

export function CivToggles() {
  const show = useCivShow();
  const g = HABITAT_RAMP.realistic.map((c, i, a) => `rgb(${c.join(',')}) ${(i / (a.length - 1)) * 100}%`).join(',');
  return (
    <>
      <div className="lp-toggles" role="group" aria-label="叠加显示">
        {TOGGLES.map((t) => (
          <button
            key={t.key}
            className={`lp-tog${show[t.key] ? ' on' : ''}`}
            role="checkbox"
            aria-checked={show[t.key]}
            data-civ={t.key}
            title={t.hint}
            onClick={() => setCivShow({ [t.key]: !show[t.key] })}
          >
            <span className="lp-box" aria-hidden="true">
              {show[t.key] ? '✓' : ''}
            </span>
            {t.name}
          </button>
        ))}
      </div>
      {show.habitat && (
        <div className="lp-key lp-ramp">
          <span>贫瘠</span>
          <i style={{ background: `linear-gradient(90deg, ${g})` }} />
          <span>富饶</span>
        </div>
      )}
      {show.routes && (
        <div className="lp-key">
          {ROUTE_LEGEND.map((l) => (
            <span key={l.name} className="lp-route">
              <svg width="22" height="6" aria-hidden="true">
                <line x1="1.5" y1="3" x2="20.5" y2="3" stroke="currentColor" strokeWidth={l.width} strokeDasharray={l.dash} strokeLinecap="round" />
              </svg>
              {l.name}
            </span>
          ))}
        </div>
      )}
      {show.wars && show.polities && (
        <div className="lp-key lp-war">
          {/* 和地图上画的一样:战线(短齿朝守方)、易手的州(斜线)、交战处(双剑) */}
          <span className="lp-route">
            <svg width="22" height="10" aria-hidden="true">
              <line x1="1.5" y1="3" x2="20.5" y2="3" stroke="currentColor" strokeWidth={2} strokeLinecap="round" />
              {[4, 9, 14, 19].map((x) => (
                <line key={x} x1={x} y1="3" x2={x} y2="7.5" stroke="currentColor" strokeWidth={1.2} strokeLinecap="round" />
              ))}
            </svg>
            战线
          </span>
          <span className="lp-route">
            <svg width="14" height="12" aria-hidden="true">
              <rect x="0.5" y="0.5" width="13" height="11" rx="2" fill="currentColor" fillOpacity={0.08} stroke="currentColor" strokeOpacity={0.35} />
              {[-6, -1, 4, 9, 14].map((x) => (
                <line key={x} x1={x} y1="12" x2={x + 12} y2="0" stroke="currentColor" strokeWidth={1} opacity={0.7} />
              ))}
            </svg>
            战时易手
          </span>
          <span className="lp-route">
            <svg width="14" height="14" viewBox="-7 -7 14 14" aria-hidden="true">
              <path d="M-5 5L5 -5M5 5L-5 -5M-4.2 1.4L-1.4 4.2M4.2 1.4L1.4 4.2" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" />
            </svg>
            交战处
          </span>
          {show.plague && <PlagueKey />}
        </div>
      )}
      {show.plague && show.polities && !show.wars && (
        <div className="lp-key lp-war">
          <PlagueKey />
        </div>
      )}
    </>
  );
}

/** "瘟疫"图例:和地图上一样的墨点;全球大疫以后的荒地:褪成灰褐的一块,上面一簇枯草 */
function PlagueKey() {
  return (
    <>
      <span className="lp-route lp-plague">
        <b aria-hidden="true" />
        疫区
      </span>
      <span className="lp-route lp-plague lp-waste">
        <svg width="14" height="10" aria-hidden="true">
          <rect x="0" y="0" width="14" height="10" rx="2" fill="rgb(136, 126, 104)" fillOpacity={0.34} />
          <path d="M4.4 3.2L5.9 6.6M7 2.6L7 6.6M9.6 3.2L8.1 6.6" stroke="rgb(104, 86, 62)" strokeOpacity={0.8} strokeWidth={0.9} strokeLinecap="round" />
        </svg>
        荒地
      </span>
    </>
  );
}

let cultureOwners: Owners | undefined;

/** 时间轴当前年份(取整;回放时一年只重算一次) */
const subscribeYear = (f: () => void) => subscribeCivTime(() => f());

/**
 * 民族图例:跟着时间轴走(民族会同化、迁徙、消亡)—— 这一年还在的民族按地盘大小排:色块 + 族名 + 州数;
 * 悬停看类型、出现年份
 */
export function CultureLegend({ civ }: { civ: Civ | null }) {
  const end = civ?.endYear ?? 0;
  const era = useEra();
  const y = useSyncExternalStore(subscribeYear, () => Math.floor(Math.min(end, Math.max(0, getCivTime().year ?? end))));
  const rows = useMemo(() => {
    if (!civ || !civ.cultures.length) return null;
    cultureOwners = ownersAt(civ, y, cultureOwners);
    const own = cultureOwners.culture;
    const count = new Array<number>(civ.cultures.length).fill(0);
    for (let r = 0; r < civ.regions.count; r++) if (own[r] >= 0) count[own[r]]++;
    return civ.cultures
      .filter((cu) => count[cu.id] > 0)
      .map((cu) => ({ cu, n: count[cu.id] }))
      .sort((a, b) => b.n - a.n || a.cu.id - b.cu.id);
  }, [civ, y]);
  if (!civ) return null;
  return (
    <div className="lp-cultures" aria-label={`${yearFull(y, era)}的民族`}>
      {rows && rows.length ? (
        rows.map(({ cu, n }) => (
          <span key={cu.id} className="lp-cu" title={`${KIND_INFO[cu.kind].name}民族 · ${yearFull(cu.born, era)}出现 · ${n} 州`}>
            <i style={{ background: `rgb(${cu.color.join(',')})` }} />
            <b>{cultureLabel(cu)}</b>
            <em>{n}</em>
          </span>
        ))
      ) : (
        <span className="lp-none">{yearFull(y, era)}还没有民族</span>
      )}
    </div>
  );
}

/** 信仰图例:跟着时间轴走 —— 这一年的大教(按信众多少)、跟在后面的教派,最后一行民间信仰:色块 + 教名 + 州数 */
export function FaithLegend({ civ }: { civ: Civ | null }) {
  const end = civ?.endYear ?? 0;
  const era = useEra();
  const y = useSyncExternalStore(subscribeYear, () => Math.floor(Math.min(end, Math.max(0, getCivTime().year ?? end))));
  const rows = useMemo(() => (civ ? faithRows(civ, y, era) : []), [civ, y, era]);
  if (!civ) return null;
  return (
    <div className="lp-cultures" aria-label={`${yearFull(y, era)}的信仰`}>
      {rows.length ? (
        rows.map((r) => (
          <span key={r.id} className="lp-cu" title={`${r.sub} · ${r.n} 州`}>
            <i style={{ background: `rgb(${r.color.join(',')})` }} />
            <b>{r.name}</b>
            <em>{r.n}</em>
          </span>
        ))
      ) : (
        <span className="lp-none">{yearFull(y, era)}还没有人住</span>
      )}
    </div>
  );
}
