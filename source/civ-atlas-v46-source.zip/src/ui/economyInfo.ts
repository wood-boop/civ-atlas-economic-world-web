/** Native history selectors shared by the map's economy sections. No simulation state lives in the UI. */
import type { Civ } from '../gen/civ/types';
import type { EconomySnapshot } from '../gen/civ/economyTypes';
import { ownersAt } from '../gen/civ/timeline';
import { FISCAL_CONSTS } from '../gen/civ/control';
import { ECONOMY_BASE_PRICE } from '../gen/civ/economy';

export type EconomyScope = { kind: 'world' } | { kind: 'polity' | 'region'; id: number };

/** Country totals follow the boundary on the native timeline, including changes between economic observations. */
export function economyRegions(civ: Civ, year: number, scope: EconomyScope, count: number): number[] {
  const n = Math.min(civ.regions.count, count);
  if (scope.kind === 'region') return scope.id >= 0 && scope.id < n ? [scope.id] : [];
  const own = scope.kind === 'polity' ? ownersAt(civ, year).polity : undefined;
  const ids: number[] = [];
  for (let r = 0; r < n; r++) if (!own || (scope.kind === 'polity' && own[r] === scope.id)) ids.push(r);
  return ids;
}

export function summarizeEconomy(snapshot: EconomySnapshot, regions: readonly number[]) {
  const output = new Array<number>(7).fill(0);
  const inputs = new Array<number>(7).fill(0);
  const consumption = new Array<number>(7).fill(0);
  const inventory = new Array<number>(7).fill(0);
  const imports = new Array<number>(7).fill(0);
  const exports = new Array<number>(7).fill(0);
  const capacity = new Array<number>(7).fill(0);
  const labor = new Array<number>(7).fill(0);
  const unmetOutput = new Array<number>(7).fill(0);
  const minPrices = new Array<number>(7).fill(Infinity);
  const maxPrices = new Array<number>(7).fill(0);
  const investment = new Array<number>(7).fill(0);
  const desiredConsumption = optionalGoods(snapshot.desiredConsumption, regions);
  const operatingSurplus = optionalGoods(snapshot.operatingSurplus, regions);
  const unsoldStock = optionalGoods(snapshot.unsoldStock, regions);
  // Weight each good by its own physical household requirement. A small region
  // with a full basket must never hide a large region's unmet needs.
  const needSatisfaction = desiredConsumption && hasValues(snapshot.needSatisfaction, regions, 7)
    ? desiredConsumption.map((need, g) => need > 0
      ? regions.reduce((sum, r) => sum + snapshot.desiredConsumption![r * 7 + g] * snapshot.needSatisfaction![r * 7 + g], 0) / need
      : null)
    : null;
  const transportLabor = optionalTotal(snapshot.transportLabor, regions);
  const transportCapital = optionalTotal(snapshot.transportCapital, regions);
  const publicSpend = optionalTotal(snapshot.publicSpend, regions);
  let foodNeed = 0, supplied = 0, capacityWeight = 0, population = 0, investmentLabor = 0;
  let agriculturalTaxBase = 0, industrialTaxBase = 0, marketTaxBase = 0, outputValue = 0;
  for (const r of regions) {
    for (let g = 0; g < 7; g++) {
      const i = r * 7 + g;
      output[g] += snapshot.output[i];
      inputs[g] += snapshot.inputs[i];
      consumption[g] += snapshot.consumption[i];
      inventory[g] += snapshot.inventory[i];
      imports[g] += snapshot.imports[i];
      exports[g] += snapshot.exports[i];
      capacity[g] += snapshot.capital[i];
      labor[g] += snapshot.labor[i];
      unmetOutput[g] += snapshot.unmetOutput[i];
      investment[g] += snapshot.investment?.[i] ?? 0;
      if (snapshot.population[r] > 0) {
        minPrices[g] = Math.min(minPrices[g], snapshot.prices[i]);
        maxPrices[g] = Math.max(maxPrices[g], snapshot.prices[i]);
      }
    }
    foodNeed += snapshot.foodNeed[r];
    supplied += snapshot.foodNeed[r] * snapshot.foodAdequacy[r];
    capacityWeight += snapshot.population[r] * snapshot.capacityFactor[r];
    population += snapshot.population[r];
    agriculturalTaxBase += snapshot.agriculturalTaxBase[r];
    industrialTaxBase += snapshot.industrialTaxBase[r];
    marketTaxBase += snapshot.marketTaxBase[r];
    outputValue += snapshot.outputValue[r];
    investmentLabor += snapshot.investmentLabor?.[r] ?? 0;
  }
  const landTax = agriculturalTaxBase * FISCAL_CONSTS.LAND;
  const craftTax = industrialTaxBase * FISCAL_CONSTS.CRAFT;
  const tradeTax = marketTaxBase * FISCAL_CONSTS.TRADE;
  const productionLabor = labor.reduce((a, b) => a + b, 0);
  const workforce = productionLabor + investmentLabor + (transportLabor ?? 0);
  const needsValue = (r: number) => ECONOMY_BASE_PRICE.reduce((sum, price, g) => sum + price * (snapshot.desiredConsumption?.[r * 7 + g] ?? 0), 0);
  const needsWeight = regions.reduce((sum, r) => sum + needsValue(r), 0);
  const livingStandard = needsWeight > 0 && desiredConsumption && hasValues(snapshot.livingStandard, regions)
    ? regions.reduce((sum, r) => sum + needsValue(r) * snapshot.livingStandard![r], 0) / needsWeight : null;
  // This is dependency on ALL regional deliveries, including domestic supply.
  // Do not call it foreign-import dependency: retained trade detail is capped.
  const useValue = (r: number) => ECONOMY_BASE_PRICE.reduce((sum, price, g) => {
    const i = r * 7 + g;
    return sum + price * (snapshot.consumption[i] + snapshot.inputs[i] + (snapshot.investment?.[i] ?? 0));
  }, 0);
  const useWeight = regions.reduce((sum, r) => sum + useValue(r), 0);
  const importDependence = useWeight > 0 && hasValues(snapshot.importDependence, regions)
    ? regions.reduce((sum, r) => sum + useValue(r) * snapshot.importDependence![r], 0) / useWeight : null;
  const householdShortages = needSatisfaction?.flatMap((satisfaction, good) => satisfaction !== null && satisfaction < 1 - 1e-6 ? [{ good, satisfaction }] : [])
    .sort((a, b) => a.satisfaction - b.satisfaction) ?? null;
  const bottlenecks = unmetOutput.map((unmet, good) => ({ good, unmet, share: unmet / Math.max(0.001, output[good] + unmet) }))
    .filter((x) => x.unmet > 0.005).sort((a, b) => b.share - a.share || b.unmet - a.unmet);
  return {
    output, inputs, consumption, inventory, imports, exports, capacity, labor, unmetOutput,
    investment, desiredConsumption, needSatisfaction, operatingSurplus, unsoldStock, householdShortages, bottlenecks,
    minPrices: minPrices.map((v) => Number.isFinite(v) ? v : 0), maxPrices,
    foodNeed, foodAdequacy: foodNeed > 0 ? supplied / foodNeed : 1,
    capacityFactor: population > 0 ? capacityWeight / population : 1,
    population, investmentLabor, transportLabor, transportCapital, publicSpend, productionLabor,
    workforce, laborSupply: population * 0.52, laborComplete: transportLabor !== null,
    livingStandard, importDependence,
    agriculturalTaxBase, industrialTaxBase, marketTaxBase, outputValue,
    landTax, craftTax, tradeTax, taxContribution: landTax + craftTax + tradeTax,
  };
}

/** Missing new fields in old saves are unknown, not zero or perfect coverage. */
function hasValues(values: Float32Array | undefined, regions: readonly number[], stride = 1): values is Float32Array {
  return !!values && regions.every((r) => {
    for (let g = 0; g < stride; g++) if (!Number.isFinite(values[r * stride + g])) return false;
    return true;
  });
}

function optionalTotal(values: Float32Array | undefined, regions: readonly number[]): number | null {
  return hasValues(values, regions) ? regions.reduce((sum, r) => sum + values[r], 0) : null;
}

function optionalGoods(values: Float32Array | undefined, regions: readonly number[]): number[] | null {
  return hasValues(values, regions, 7) ? Array.from({ length: 7 }, (_, g) => regions.reduce((sum, r) => sum + values[r * 7 + g], 0)) : null;
}

/** Distribution over inhabited native regions; empty land does not improve it. */
export function economyDistribution(snapshot: EconomySnapshot, regions: readonly number[]) {
  const inhabited = regions.filter((r) => snapshot.population[r] > 0);
  const needsRecorded = hasValues(snapshot.desiredConsumption, inhabited, 7) && hasValues(snapshot.needSatisfaction, inhabited, 7);
  const livingRecorded = hasValues(snapshot.livingStandard, inhabited);
  const needs = needsRecorded ? inhabited.map((region) => {
    let least = 1, good = -1;
    for (let g = 0; g < 7; g++) if (snapshot.desiredConsumption![region * 7 + g] > 0 && snapshot.needSatisfaction![region * 7 + g] < least) {
      least = snapshot.needSatisfaction![region * 7 + g]; good = g;
    }
    return { region, satisfaction: least, good, population: snapshot.population[region] };
  }).sort((a, b) => a.satisfaction - b.satisfaction || a.region - b.region) : null;
  const living = livingRecorded ? inhabited.map((region) => ({ region, value: snapshot.livingStandard![region] })).sort((a, b) => a.value - b.value || a.region - b.region) : null;
  const unmetNeeds = needs?.filter((x) => x.satisfaction < 1 - 1e-6) ?? null;
  const nonfoodShortages = needsRecorded ? inhabited.filter((r) => {
    for (let g = 1; g < 7; g++) if (snapshot.desiredConsumption![r * 7 + g] > 0 && snapshot.needSatisfaction![r * 7 + g] < 1 - 1e-6) return true;
    return false;
  }) : null;
  return {
    inhabited: inhabited.length, needs, unmetNeeds, nonfoodShortages,
    affectedPopulation: unmetNeeds ? unmetNeeds.reduce((sum, x) => sum + x.population, 0) : null,
    livingRange: living?.length ? [living[0].value, living[living.length - 1].value] as const : null,
    livingLow: living?.slice(0, 3) ?? null,
  };
}

export type EconomySummary = ReturnType<typeof summarizeEconomy>;
