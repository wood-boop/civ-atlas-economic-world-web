/**
 * 编辑地形的界面:新建世界卡片里的工具面板(TerrainPanel)、地图上的覆盖层(涂过的地方、放的火山湖河、光标圈)。
 * 地形是世界的根:只在新建世界这一步能改,点"创建世界"后锁住(想换地形用"以它为底稿新建")。
 *
 * - 涂一片(陆地、丘陵、山地、高原、浅海、海、群岛、擦掉):按住拖动涂一笔(画法"圈起来填满" = 画一圈,松手连上起点、圈里整片涂上),
 *   大小是滑条(笔的半径,世界坐标),山地另有高低。每一笔加进草图(editsStore.addSketchStroke,格式见 gen/sketch.ts),
 *   程序照草图重新长出整颗星球。
 * - 放一处:火山 / 湖 = 点一下放一处(拖动照样平移);河 = 从源头画到海边的一条线。大小(河是粗细)是滑条,强度跟着大小在
 *   gen/terrainEdits.ts 的 TERRAIN_PRESETS 三档之间连续取(presetStrength);湖另有湖岸(圆润 / 适中 / 曲折,存成 e)。
 *   加一处 = editsStore.addTerrainOp。旧存档里、或"让助手改"做出来的山脉 / 抬起陆地 / 沉成海照常生效、照常画出来,算在"画了几笔"里。
 * - 「擦掉」除了把涂过的地方交还给程序,还整个去掉碰到的火山、湖、河(画的时候描红;和这一笔算同一步,撤销一起回来)。
 * - 「删河湖」(放一处的第四样):指着程序生成的湖或河描红(河连同流进它的支流,和生成时删的一样,见 gen/terrainEdits.ts 的 lakeAt、riversAt),
 *   点一下存成一处地形修改 delWater(点的位置),生成时删掉;撤销找回来。
 * - 整张草图:海岸线、程序补全(随意发挥 / 只补细节 / 完全照画;新开的草图默认只补细节)、没涂的地方(交给程序 / 不长新陆地 / 都是海)。
 * - 面板分四页:地貌(涂一片 + 放一处)、高度、气候(更湿 / 更干 / 更暖 / 更冷,用法同涂一片,多一个程度;
 *   存成地形修改的气候四种,见 gen/edits.ts 文件头"地形修改")、板块。随机生成和照手绘图一样。
 * - 高度页五支笔(存成地形修改的高度五种,改的是最后的海拔):抬高 / 压低按住涂,按过的每个点各改一下,按住不动也每隔 DAB_MS
 *   记一次(越涂越多),力度是滑条,按住 Alt 涂就反过来;平滑、抹平用法一样;定高写海拔(米),边缘硬 / 适中 / 软,
 *   「从地图上取」点一下地图取那里的海拔。定高时指针旁写"原来多高 → 涂完多高",抬高 / 压低涂的时候写抬了多少(liftAt)。
 *   涂过的高度笔地图上本身就看得出来,不另画记号(还在重新生成的那几笔照样闪着)。
 * - 「板块」页(存在草图的 plates 里,见 gen/plateEdits.ts):地图换成板块配色(App 切过去,离开这一页换回来)。
 *   选中 = 点一块板块选中它,地图上它的漂移箭头变白,拖箭头头上的圈改方向和快慢(松手记一处改动);面板里改陆壳 / 洋壳、
 *   「板块相撞时造山」开关;切开 = 画一条线(松手切开);合并 = 依次点两块挨着的板块。都用点指板块,算在"画了几笔"里,能撤销。
 *   照图分 = 选一张图,按颜色分成一块块铺满整张当板块图(不算一笔,面板里「去掉」;换了分法之前的板块改动清掉)。
 * - 两种新建各一套面板:随机生成的是「编辑地形」(组头"完成"收起;整张草图里海岸线、没涂的地方);
 *   照手绘图生成的是第 2 步「用笔修改」(mode = 'image',没有组头和没涂的地方 —— 没盖到的都是海;海岸线、程序补全排在笔的选项下面)。
 *   照手绘图时认图(ImportImage.tsx)那一步也开着编辑地形(地图事件转给认图);「照这样长出星球」= applyImport,
 *   认出来的格子铺成草图的底子(editsStore.setSketchBase,铺在所有笔画底下),不算一笔、撤销不掉,「全部清除」也只清笔画。
 * - 撤销 / 重做按先后,草图的笔和放的一处混在一起算(Ctrl / ⌘ + Z,Ctrl / ⌘ + Shift + Z 或 Ctrl + Y);全部清除点两下才清。
 *   App 看到地形修改或草图变了就在后台重新生成世界、重推文明(见 App.tsx)。
 * - 地图事件由 App 转给这里:terrainDown / terrainMove / terrainUp(画线、涂、圈)、terrainClick(放点)、terrainCancel(第二根手指按下);
 *   返回 true = 这一下归编辑地形管。按住空格拖动是平移。
 * - 覆盖层(TerrainOverlay)用 SVG,坐标就是世界坐标(viewBox = 地图原图大小),随地图一起缩放平移。
 */
import { useEffect, useId, useMemo, useState, useSyncExternalStore, type ReactNode } from 'react';
import type { TerrainKind, TerrainOp } from '../gen/edits';
import {
  SKETCH_COAST,
  SKETCH_FILL_NEW,
  SKETCH_MAX_PTS,
  SKETCH_R,
  sketchCoast,
  sketchFill,
  type SketchEdit,
  type SketchFill,
  type SketchImage,
  type SketchKind,
  type SketchStroke,
  encodeLayer,
} from '../gen/sketch';
import {
  DEL_WATER_R,
  HEIGHT_M,
  HEIGHT_S,
  TERRAIN_MAX_PTS,
  TERRAIN_R,
  TERRAIN_PRESETS as PRESETS,
  isHeightKind,
  isPointKind,
  lakeAt,
  ownLakeCells,
  liftAt,
  presetStrength,
  riversAt,
  sameTerrain,
} from '../gen/terrainEdits';
import type { World } from '../gen/world';
import type { Raster } from '../gen/raster';
import { PLATE_IMAGE_MAX, PLATE_SPEED, cleanPlateImage, cutsPlate, driftOf, driftText, plateImageCount, type PlateCrust, type PlateOp } from '../gen/plateEdits';
import { placeOnLayer, plateRegions } from '../gen/sketchImage';
import { showToast } from './toastStore';
import { PLATE_ARROW_L, plateArrows } from '../render/layers';
import { Icon, type IconName } from './icons';
import { Seg, Slider } from './tpControls';
import {
  addEraseStroke,
  addPlateOp,
  addSketchStroke,
  addTerrainOp,
  clearTerrainAndSketch,
  editsEra,
  getEdits,
  setSketchBase,
  setSketchCoast,
  setSketchFill,
  setPlateImage,
  setPlateOrogeny,
  setSketchRest,
  undoEraseStroke,
  undoPlateOp,
  undoSketchStroke,
  undoTerrainOp,
  useEdits,
} from './editsStore';
import {
  ImportLayer,
  LayerMark,
  cancelImport,
  coverMaskUrl,
  importCancel,
  importClick,
  importDown,
  importMove,
  importOn,
  importResult,
  importUndoClick,
  importUp,
  keepImport,
  loadImage,
  useImport,
} from './ImportImage';

// ---------------------------------------------------------------------------
// 工具状态

/** 放一处的三样 */
export type PlaceKind = 'volcano' | 'lake' | 'river';
/** 改气候的四支笔 */
export type ClimateKind = 'wet' | 'dry' | 'warm' | 'cold';
/** 高度页的五支笔 */
export type HeightKind = 'lift' | 'lower' | 'smooth' | 'flatten' | 'setHeight';
/** 板块页:选中、切开、合并 */
export type PlateTool = 'plateSelect' | 'plateCut' | 'plateMerge';
export type EditTool = SketchKind | PlaceKind | ClimateKind | HeightKind | PlateTool | 'delWater';

export interface TerrainToolState {
  on: boolean;
  tool: EditTool;
  /** 涂一片、改气候的笔:半径(世界坐标,SKETCH_R 范围) */
  r: number;
  /** 涂一片、改气候的画法:涂抹 / 圈起来填满 */
  method: 'paint' | 'lasso';
  /** 山地的高低:0 低 / 1 中 / 2 高 */
  h: 0 | 1 | 2;
  /** 放一处的大小(世界坐标的半径;河是河谷半宽),范围见 PLACE_R */
  place: Record<PlaceKind, number>;
  /** 湖岸:0 圆润 / 0.5 适中 / 1 曲折 */
  shore: number;
  /** 改气候的程度:0 一点 / 1 明显 / 2 很多 */
  level: 0 | 1 | 2;
  /** 高度笔(抬高、压低、平滑、抹平)的力度(HEIGHT_S 范围) */
  power: number;
  /** 定高的海拔(米,HEIGHT_M 范围) */
  height: number;
  /** 定高的边缘:0 硬 / 1 适中 / 2 软 */
  edge: 0 | 1 | 2;
  /** 定高的「从地图上取」:下一次点地图取那里的海拔 */
  picking: boolean;
  /** 板块页选中的板块(选中:改它;合并:先点的那块):点的位置(世界坐标),没选 = null */
  plateAt: [number, number] | null;
  /** 板块页这一下没做成的原因(合并时点的两块不挨着),写在面板的提示里;没有 = null */
  plateNote: string | null;
  /** 地图上显示草图(涂过的地方、放的火山湖河) */
  show: boolean;
  /** 海岸线的选择(草图还一笔没有时也记着,画第一笔时带上;有草图时以草图里的为准) */
  coast: number;
  /** 程序补全的选择(同海岸线:还没有草图时记着,新开草图时带上) */
  fill: SketchFill | 'free';
}

/** 放一处的大小滑条范围 */
export const PLACE_R: Record<PlaceKind, readonly [number, number]> = { volcano: [8, 60], lake: [4, 60], river: [4, 20] };
const PLACE_DEF: Record<PlaceKind, number> = { volcano: PRESETS.volcano[1][0], lake: PRESETS.lake[1][0], river: PRESETS.river[1][0] };

let tool: TerrainToolState = {
  on: false,
  tool: 'land',
  r: 40,
  method: 'paint',
  h: 1,
  place: PLACE_DEF,
  shore: 0.5,
  level: 1,
  power: 0.4,
  height: 2000,
  edge: 1,
  picking: false,
  plateAt: null,
  plateNote: null,
  show: true,
  coast: SKETCH_COAST,
  fill: SKETCH_FILL_NEW,
};
const toolSubs = new Set<() => void>();
const emitTool = () => toolSubs.forEach((f) => f());

export const isPlaceTool = (t: EditTool): t is PlaceKind => t === 'volcano' || t === 'lake' || t === 'river';
export const isClimateTool = (t: EditTool): t is ClimateKind => t === 'wet' || t === 'dry' || t === 'warm' || t === 'cold';
export const isHeightTool = (t: EditTool): t is HeightKind => t === 'lift' || t === 'lower' || t === 'smooth' || t === 'flatten' || t === 'setHeight';
/** 按住涂、越涂越多的四支(定高不算:涂过的就是那个海拔) */
const isDabTool = (t: EditTool) => isHeightTool(t) && t !== 'setHeight';
export const isPlateTool = (t: EditTool): t is PlateTool => t === 'plateSelect' || t === 'plateCut' || t === 'plateMerge';

export function getTerrainTool(): TerrainToolState {
  return tool;
}
export function setTerrainTool(p: Partial<TerrainToolState>) {
  const next = { ...tool, ...p };
  // 换了笔:「从地图上取」收起;合并先点的那块不带到别的笔
  if (next.tool !== tool.tool && p.picking === undefined) next.picking = false;
  if (next.tool !== tool.tool && p.plateAt === undefined && (tool.tool === 'plateMerge' || next.tool === 'plateMerge')) next.plateAt = null;
  if (next.tool !== tool.tool && p.plateNote === undefined) next.plateNote = null;
  if ((Object.keys(next) as (keyof TerrainToolState)[]).every((k) => next[k] === tool[k])) return;
  tool = next;
  if (!tool.on) {
    setDraft({ draft: null, cursor: null });
    cancelImport();
  }
  emitTool();
}
/** 编辑地形的几页:地貌、高度、气候、板块 */
export type TerrainPage = 'shape' | 'height' | 'climate' | 'plates';
/** 这支笔在哪一页 */
export const pageOf = (t: EditTool): TerrainPage => (isClimateTool(t) ? 'climate' : isHeightTool(t) ? 'height' : isPlateTool(t) ? 'plates' : 'shape');
/** 各页记着上一次用的笔,切回来还是它 */
const lastOnPage: Record<TerrainPage, EditTool> = { shape: 'land', height: 'lift', climate: 'wet', plates: 'plateSelect' };
/** 切到哪一页(换成那一页上次用的笔) */
export function setTerrainPage(p: TerrainPage) {
  const now = tool.tool;
  const cur = pageOf(now);
  if (cur === p) return;
  lastOnPage[cur] = now;
  setTerrainTool({ tool: lastOnPage[p] });
}
export function useTerrainTool(): TerrainToolState {
  return useSyncExternalStore(
    (f) => (toolSubs.add(f), () => toolSubs.delete(f)),
    () => tool,
    () => tool,
  );
}

const PAINT: { id: SketchKind; name: string; hint: string }[] = [
  { id: 'land', name: '陆地', hint: '按住拖动来涂。松手后星球照着草图重新长，海岸线和山河由程序补上。' },
  { id: 'hills', name: '丘陵', hint: '涂过的地方起一片丘陵；涂到海里会先长出陆地。' },
  { id: 'mountain', name: '山地', hint: '涂一道就是一条山脉，山脊顺着涂的方向；涂到海里会先长出陆地。' },
  { id: 'plateau', name: '高原', hint: '涂过的地方抬成一片高原；涂到海里会先长出陆地。' },
  { id: 'shelf', name: '浅海', hint: '涂过的地方是一片浅海，像大陆架那样浅。' },
  { id: 'sea', name: '海', hint: '涂过的地方沉成深海。' },
  { id: 'isles', name: '群岛', hint: '涂过的地方冒出一片大大小小的岛。' },
  { id: 'erase', name: '擦掉', hint: '擦过的地方交还给程序；碰到的火山、湖、河整个去掉（变红的就是松手后会去掉的）。' },
];
const DEL_WATER = { id: 'delWater' as const, name: '删河湖', icon: 'trash' as IconName, hint: '点一下程序生成的河或湖，它就不再出现；撤销能找回。指着的那条描成红色。' };
const PLACE: { id: PlaceKind; name: string; icon: IconName; size: string; hint: string }[] = [
  { id: 'volcano', name: '火山', icon: 'volcano', size: '大小', hint: '点一下放一座火山；点在海里是火山岛。' },
  { id: 'lake', name: '湖', icon: 'lake', size: '大小', hint: '点一下挖一个湖（点在陆地上）。湖岸越曲折，越像天然的湖。' },
  { id: 'river', name: '河', icon: 'river', size: '粗细', hint: '从源头画到海边，河顺着画的线流；全图也看得见。' },
];
const CLIMATE: { id: ClimateKind; name: string; hint: string }[] = [
  { id: 'wet', name: '更湿', hint: '涂过的地方雨水更多：沙漠变草原，草原长出森林。只改气候，不动地形。' },
  { id: 'dry', name: '更干', hint: '涂过的地方雨水更少：森林变草原，草原变荒漠。只改气候，不动地形。' },
  { id: 'warm', name: '更暖', hint: '涂过的地方更暖和：冰雪化开，苔原长出森林。只改气候，不动地形。' },
  { id: 'cold', name: '更冷', hint: '涂过的地方更冷：森林退成苔原，高处积起冰雪。只改气候，不动地形。' },
];
const HEIGHT: { id: HeightKind; name: string; icon: IconName; hint: string; phone: string }[] = [
  { id: 'lift', name: '抬高', icon: 'hLift', hint: '按住涂，越涂越高；涂得越久抬得越多。按住 Alt 涂就是压低。', phone: '按住涂，越涂越高。' },
  { id: 'lower', name: '压低', icon: 'hLower', hint: '按住涂，越涂越低；涂得越久压得越多。按住 Alt 涂就是抬高。', phone: '按住涂，越涂越低。' },
  { id: 'smooth', name: '平滑', icon: 'hSmooth', hint: '按住涂，高低起伏磨得更缓；涂得越久越平缓。', phone: '按住涂，起伏磨得更缓。' },
  { id: 'flatten', name: '抹平', icon: 'hFlatten', hint: '按住涂，涂过的地方抹成按下那一点的高度；涂得越久越平。', phone: '按住涂，抹成按下那一点的高度。' },
  { id: 'setHeight', name: '定高', icon: 'hSet', hint: '按住涂，涂过的地方变成这个海拔。改的就是最后的高度，河流、气候、植被跟着重算。', phone: '涂过的地方变成这个海拔。' },
];
const PLATE: { id: PlateTool; name: string; icon: IconName; hint: string }[] = [
  { id: 'plateSelect', name: '选中', icon: 'plPick', hint: '点一块板块选中它，在地图上拖它的箭头改方向和快慢。山脉、海沟、裂谷照新的板块重新长。' },
  { id: 'plateCut', name: '切开', icon: 'plCut', hint: '从板块一边画到另一边，沿着画的线切成两块。新的那块先跟着原来的方向走，再拖箭头改。' },
  { id: 'plateMerge', name: '合并', icon: 'plMerge', hint: '依次点两块挨着的板块，合成一块。' },
];
const MERGE_NEXT = '再点一块挨着它的板块，两块合成一块。';
const MERGE_FAR = '这两块不挨着，合不了。换一块挨着的点。';
const CUT_SHORT = '这条线没把板块整个切开。要从板块的一边一直画到另一边。';
const CRUSTS: { v: PlateCrust; name: string }[] = [
  { v: 'continental', name: '陆壳' },
  { v: 'oceanic', name: '洋壳' },
];
const EDGES = ['硬', '适中', '软'];
const SHORES: { v: number; name: string }[] = [
  { v: 0, name: '圆润' },
  { v: 0.5, name: '适中' },
  { v: 1, name: '曲折' },
];
const LEVELS = ['一点', '明显', '很多'];
const PAGE_NAME: Record<TerrainPage, string> = { shape: '地貌', height: '高度', climate: '气候', plates: '板块' };
const PICK_HINT = '点一下地图，取那里的海拔。';
/** 海拔写成"2,000""−120"(整数米,千位加逗号,负号用减号) */
export const fmtM = (v: number) => {
  const r = Math.round(v);
  return `${r < 0 ? '−' : ''}${Math.abs(r).toLocaleString('en-US')}`;
};
const LASSO_HINT = '按住画一圈，松手自动连上起点，圈里整片涂满。';
const PHONE_HINT = '一根手指涂，两根手指拖动、放大。';
const FILLS: { v: SketchFill | 'free'; name: string }[] = [
  { v: 'free', name: '随意发挥' },
  { v: 'detail', name: '只补细节' },
  { v: 'exact', name: '完全照画' },
];
const RESTS: { v: SketchEdit['rest']; name: string }[] = [
  { v: 'auto', name: '交给程序' },
  { v: 'noNewLand', name: '不长新陆地' },
  { v: 'sea', name: '都是海' },
];
const COASTS: { v: number; name: string }[] = [
  { v: 0, name: '贴着画' },
  { v: SKETCH_COAST, name: '适中' },
  { v: 1, name: '曲折' },
];
const HEIGHTS = ['低', '中', '高'];

// ---------------------------------------------------------------------------
// 正在画的线、光标(世界坐标),给覆盖层画

interface Draft {
  draft: number[] | null;
  cursor: [number, number] | null;
  /** 按着 Alt(抬高 / 压低反过来) */
  alt?: boolean;
  /** 正在拖选中板块的箭头:箭头头拖到了哪(世界坐标);没在拖 = 不给 */
  tip?: [number, number];
}
let draftNow: Draft = { draft: null, cursor: null };
/** 这一笔按下时按着 Alt */
let draftAlt = false;
/** 按住不动时每隔多少毫秒再记一次这个点(抬高、压低、平滑、抹平越涂越多) */
const DAB_MS = 100;
let dabTimer: ReturnType<typeof setInterval> | null = null;
/** 上一次往这一笔里加点是什么时候 */
let lastDab = 0;
function stopDabs() {
  if (dabTimer !== null) clearInterval(dabTimer);
  dabTimer = null;
}
function startDabs() {
  stopDabs();
  lastDab = performance.now();
  dabTimer = setInterval(() => {
    const d = draftNow.draft;
    const c = draftNow.cursor;
    if (!d || !isDabTool(tool.tool)) return stopDabs();
    if (!c || d.length >= TERRAIN_MAX_PTS * 2 || performance.now() - lastDab < DAB_MS * 0.8) return;
    lastDab = performance.now();
    setDraft({ ...draftNow, draft: [...d, Math.round(near(c[0], d[d.length - 2])), Math.round(c[1])] });
  }, DAB_MS);
}
/** 这一笔是什么时候按下的(第二根手指紧跟着按下 = 想捏合,不是在画) */
let draftT0 = 0;
const draftSubs = new Set<() => void>();
function setDraft(s: Draft) {
  if (!s.draft) stopDabs();
  draftNow = { ...s, alt: s.alt ?? draftNow.alt, tip: s.tip };
  draftSubs.forEach((f) => f());
}
/** 正在画一笔(按着还没松开;拖板块的箭头也算):别的不急的活(样式缩略图)先等着 */
export function terrainStroking(): boolean {
  return draftNow.draft !== null || !!draftNow.tip;
}
function useDraft(): Draft {
  return useSyncExternalStore(
    (f) => (draftSubs.add(f), () => draftSubs.delete(f)),
    () => draftNow,
    () => draftNow,
  );
}

/** 按住空格 = 平移(画线、涂的工具里拖动本来是画) */
let space = false;

/**
 * 世界东西相连的一整圈宽度(世界单位);还没有世界时 0。App 设。
 * 地图给的点 x 在 [0, 宽) 里;画线时每个新点按上一个点展开,跨 180° 经线的线是连着的一笔,原样存下
 * (x 可以超出 [0, 宽);存档、生成都按经纬度解释,见 gen/terrainEdits.ts 的 cleanTerrainOp)
 */
let wrapW = 0;
export function setTerrainWrap(w: number) {
  wrapW = w;
}
const near = (x: number, ref: number) => (wrapW ? x - wrapW * Math.round((x - ref) / wrapW) : x);

/** 地图上现在这个世界(定高的读数、「从地图上取」按它取海拔)。App 设;还没有世界时 null */
let probe: { world: World; raster: Raster } | null = null;
export function setTerrainProbe(d: { world: World; raster: Raster } | null) {
  probe = d;
}
/** 世界坐标点落在哪个地块(那一像素最近的地块);没有世界 = −1 */
function cellAt(x: number, y: number): number {
  if (!probe) return -1;
  const { world, raster } = probe;
  const W = world.width;
  const px = Math.min(raster.w - 1, Math.max(0, Math.floor((x - W * Math.floor(x / W)) * raster.scale)));
  const py = Math.min(raster.h - 1, Math.max(0, Math.floor(y * raster.scale)));
  const c = raster.cell[py * raster.w + px];
  return c >= 0 && c < world.elevation.length ? c : -1;
}
/** 世界坐标点那里的海拔(米;那一像素最近的地块);没有世界 = null */
export function heightAt(x: number, y: number): number | null {
  const c = cellAt(x, y);
  return c < 0 ? null : probe!.world.elevation[c];
}
/** 世界坐标点那里是哪块板块(地图上现在这个世界);没有世界 = null */
export function plateAtPoint(x: number, y: number): number | null {
  const c = cellAt(x, y);
  return c < 0 ? null : probe!.world.tect.plate[c];
}
/** 两块板块挨不挨着(地图上现在这个世界) */
function platesTouch(a: number, b: number): boolean {
  if (!probe) return false;
  const { mesh, tect } = probe.world;
  const { plate } = tect;
  for (let i = 0; i < mesh.n; i++) {
    if (plate[i] !== a) continue;
    for (let k = mesh.adjStart[i]; k < mesh.adjStart[i + 1]; k++) if (plate[mesh.adj[k]] === b) return true;
  }
  return false;
}
/** 选中(或合并先点)的那块板块和它的漂移箭头;没选、没有世界 = null */
function pickedArrow(t: TerrainToolState) {
  if (!t.plateAt || !probe) return null;
  const k = plateAtPoint(t.plateAt[0], t.plateAt[1]);
  if (k === null) return null;
  const a = plateArrows(probe.world)[k];
  return a ? { k, a } : null;
}
/** 箭头写成一句:"每年 4 厘米，往东北" */
function arrowText(a: { dx: number; dy: number; east: number }): string {
  const d = driftOf(a.dx / (a.east * PLATE_ARROW_L), a.dy / PLATE_ARROW_L);
  return driftText(d.dir, d.speed);
}
/** 选中的板块的箭头比地图上画的长这么多倍(地图上的箭头短,慢的板块只有箭头头那么长,拖不住) */
const PICK_ARROW = 5.5;
/** 选中的板块的箭头头在哪(世界坐标) */
const pickedTip = (a: { x: number; y: number; dx: number; dy: number }): [number, number] => [a.x + a.dx * PICK_ARROW, a.y + a.dy * PICK_ARROW];
/** 箭头头拖到 tip 时的漂移:往哪边(整度)、每年几厘米(半厘米一档,最快 PLATE_SPEED[1]) */
function dragDrift(a: { x: number; y: number; east: number }, tip: readonly [number, number]): { dir: number; speed: number } {
  const L = PLATE_ARROW_L * PICK_ARROW;
  const d = driftOf((near(tip[0], a.x) - a.x) / (a.east * L), (tip[1] - a.y) / L);
  return { dir: Math.round(d.dir) % 360, speed: Math.round(Math.min(PLATE_SPEED[1], d.speed) * 2) / 2 };
}
/** 屏幕上一个世界单位多少像素(覆盖层画的时候记下;拖箭头时量手指离箭头头多远用) */
let overlayK = 1;
/** 手指离箭头头的圈不超过这么多屏幕像素算抓住了 */
const HANDLE_PX = 18;
/**
 * 删河湖:世界坐标点指着地图上现在这个世界的哪个湖(那一片湖的地块)或哪几条河(world.rivers 的下标,连同流进它的支流)——
 * 和生成时删的是同一片(gen/terrainEdits.ts 的 lakeAt、riversAt;按存进修改的取整坐标算);没有世界、没指着 = null
 */
let ownLakes: { world: World; ops: readonly TerrainOp[]; cells: Uint8Array } | null = null;
export function waterAt(fx: number, fy: number): { lake: number[] } | { rivers: number[] } | null {
  if (!probe) return null;
  const x = Math.round(fx);
  const y = Math.round(fy);
  const { world } = probe;
  const ops = getEdits().terrain;
  if (ownLakes?.world !== world || ownLakes.ops !== ops) ownLakes = { world, ops, cells: ownLakeCells(world.mesh, ops) };
  const lake = lakeAt(world.mesh, world.water, x, y, ownLakes.cells);
  if (lake) return { lake };
  const rivers = riversAt(world.rivers, world.water, x, y, DEL_WATER_R);
  return rivers.length ? { rivers } : null;
}
/** 画在覆盖层上的点:按上一个点展开(旧存档里跨接缝的线是一个个取模存的,这样也不横穿整张图) */
function displayPts(pts: readonly number[], wrap: number): number[] {
  if (!wrap) return pts as number[];
  const out = [...pts];
  for (let i = 2; i < out.length; i += 2) out[i] = out[i - 2] + (out[i] - out[i - 2]) - wrap * Math.round((out[i] - out[i - 2]) / wrap);
  return out;
}

/** 这支笔现在多大(世界坐标的半径) */
function radiusOf(t: TerrainToolState): number {
  if (isPlaceTool(t.tool)) return t.place[t.tool];
  // 高度、气候的笔存成地形修改,半径最小 TERRAIN_R[0](草图的笔可以更细)
  return isHeightTool(t.tool) || isClimateTool(t.tool) ? Math.max(TERRAIN_R[0], t.r) : t.r;
}
/** 画成一处地形修改的线(河、改气候)最多 TERRAIN_MAX_PTS 个点,草图的笔 SKETCH_MAX_PTS 个 */
const capOf = (t: EditTool) => (t === 'river' || t === 'plateCut' || isClimateTool(t) || isHeightTool(t) ? TERRAIN_MAX_PTS : SKETCH_MAX_PTS);
/** 高度笔、板块页只有涂抹(画线) */
const lassoOn = (t: TerrainToolState) => !isPlaceTool(t.tool) && !isHeightTool(t.tool) && !isPlateTool(t.tool) && t.method === 'lasso';

/** 地图上按下:涂、圈、画河的工具开始画(返回 true = 这一下归编辑地形管,不平移) */
export function terrainDown(w: [number, number] | null, button: number): boolean {
  if (tool.on && importOn()) return !space && importDown(w, button);
  if (!tool.on || !w || button !== 0 || space || tool.tool === 'volcano' || tool.tool === 'lake' || tool.tool === 'delWater' || tool.tool === 'plateMerge') return false;
  // 选中:按在选中板块箭头头的圈上 = 开始拖箭头;按在别处是点,交给 terrainClick(选中那里的板块)
  if (tool.tool === 'plateSelect') {
    const p = pickedArrow(tool);
    if (!p) return false;
    const [tx, ty] = pickedTip(p.a);
    const wx = near(w[0], tx);
    if (Math.hypot(wx - tx, w[1] - ty) * overlayK > HANDLE_PX) return false;
    setDraft({ draft: null, cursor: w, tip: [wx, w[1]] });
    return true;
  }
  // 「从地图上取」:这一下是点,交给 terrainClick
  if (tool.tool === 'setHeight' && tool.picking) return false;
  draftT0 = performance.now();
  draftAlt = !!draftNow.alt;
  setDraft({ draft: [Math.round(w[0]), Math.round(w[1])], cursor: w });
  if (isDabTool(tool.tool)) startDabs();
  return true;
}

/** 地图上移动:更新光标;正在画就把线接长(返回 true = 正在画) */
export function terrainMove(w: [number, number] | null): boolean {
  if (!tool.on) return false;
  if (importOn()) return importMove(w);
  const tip = draftNow.tip;
  if (tip) {
    if (w) setDraft({ draft: null, cursor: w, tip: [near(w[0], tip[0]), w[1]] });
    return true;
  }
  const d = draftNow.draft;
  if (!d) {
    if (w !== draftNow.cursor) setDraft({ draft: null, cursor: w });
    return false;
  }
  if (!w) return true;
  const r = radiusOf(tool);
  const lx = d[d.length - 2];
  const ly = d[d.length - 1];
  // 点和点至少隔开小半个半径(手抖的小折弯不算,线也不会太长);圈的时候点密一点,圈出来的边顺
  const step = lassoOn(tool) ? 4 : tool.tool === 'plateCut' ? 6 : Math.max(tool.tool === 'river' ? 4 : 2, r * 0.4);
  const cap = capOf(tool.tool);
  // 按上一个点展开(跨 180° 经线接着画,不跳到地图另一头)
  const wx = near(w[0], lx);
  const far = (wx - lx) ** 2 + (w[1] - ly) ** 2 >= step * step;
  let next = far && d.length < cap * 2 ? [...d, Math.round(wx), Math.round(w[1])] : d;
  // 抬高、压低、平滑、抹平每个点是一下:鼠标一下挪得远,中间按步长补上,涂出来和画的带子一样连着
  if (next !== d && isDabTool(tool.tool)) {
    const dist = Math.hypot(wx - lx, w[1] - ly);
    const k = Math.min(Math.ceil(dist / step), cap - (d.length >> 1));
    next = [...d];
    for (let j = 1; j <= k; j++) next.push(Math.round(lx + ((wx - lx) * j) / k), Math.round(ly + ((w[1] - ly) * j) / k));
  }
  if (next !== d) lastDab = performance.now();
  setDraft({ draft: next, cursor: [wx, w[1]] });
  return true;
}

/** 松开:画完的一笔加进草图,或者加成一条河 */
export function terrainUp() {
  if (importOn()) return importUp();
  const tip = draftNow.tip;
  if (tip) {
    setDraft({ draft: null, cursor: draftNow.cursor });
    const p = pickedArrow(tool);
    if (p && tool.plateAt) addPlate({ kind: 'set', pts: [...tool.plateAt], ...dragDrift(p.a, tip) });
    return;
  }
  const d = draftNow.draft;
  if (!d) return;
  const c0 = draftNow.cursor;
  setDraft({ draft: null, cursor: c0 });
  const c: [number, number] | null = c0 && [near(c0[0], d[d.length - 2]), c0[1]];
  // 松开的地方离最后一个点还差一小段(不到一步):补上,线画到哪儿就到哪儿
  const cap = capOf(tool.tool);
  const pts = c && d.length < cap * 2 && (c[0] - d[d.length - 2]) ** 2 + (c[1] - d[d.length - 1]) ** 2 >= 4 ? [...d, Math.round(c[0]), Math.round(c[1])] : d;
  if (tool.tool === 'plateCut') {
    // 切开的线至少两个点(点一下不算);没把哪块板块整个切开的不记(提示要从一边画到另一边)
    if (pts.length < 4) return;
    if (probe && !cutsPlate(probe.world.mesh, probe.world.tect.plate, pts)) return setTerrainTool({ plateNote: CUT_SHORT });
    setTerrainTool({ plateNote: null });
    addPlate({ kind: 'cut', pts });
    return;
  }
  if (tool.tool === 'river') {
    // 河至少要有两个点(点一下不算)
    if (pts.length < 4) return;
    const r = tool.place.river;
    addOp({ kind: 'river', pts, r, s: presetStrength('river', r) });
    return;
  }
  if (isPlaceTool(tool.tool) || tool.tool === 'delWater' || isPlateTool(tool.tool)) return;
  if (isHeightTool(tool.tool)) {
    if (tool.tool === 'setHeight') return void addOp({ kind: 'setHeight', pts, r: radiusOf(tool), s: 1, h: tool.height, edge: tool.edge });
    // 按着 Alt:抬高、压低反过来
    const kind = draftAlt && tool.tool === 'lift' ? 'lower' : draftAlt && tool.tool === 'lower' ? 'lift' : tool.tool;
    return void addOp({ kind, pts, r: radiusOf(tool), s: tool.power });
  }
  const fill = lassoOn(tool) && pts.length >= 6;
  if (isClimateTool(tool.tool)) {
    const op: TerrainOp = { kind: tool.tool, pts, r: radiusOf(tool), s: PRESETS[tool.tool][tool.level][1] };
    if (fill) op.f = 1;
    addOp(op);
    return;
  }
  const st: SketchStroke = { kind: tool.tool, r: tool.r, pts };
  if (tool.tool === 'mountain' && tool.h !== 1) st.h = tool.h;
  if (fill) st.fill = 1;
  if (tool.tool === 'erase') {
    const hit = erasedOps(getEdits().terrain, st);
    if (hit.length) return eraseStroke(st, hit);
  }
  addStroke(st);
}

/** 擦掉能整个去掉的几种:放下的火山、湖、河 */
const ERASABLE = (k: TerrainKind) => k === 'volcano' || k === 'lake' || k === 'river';

/** 点 (px, py) 到线段 a–b 的距离的平方(都已按东西相连挪到同一圈) */
function segDist2(px: number, py: number, ax: number, ay: number, bx: number, by: number): number {
  const dx = bx - ax;
  const dy = by - ay;
  const l = dx * dx + dy * dy;
  const t = l > 0 ? Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l)) : 0;
  return (px - ax - t * dx) ** 2 + (py - ay - t * dy) ** 2;
}
/** 点 (px, py) 离擦掉的这一笔多远(涂抹 = 到笔走过的线的距离减去笔的半径;圈起来填满 = 在圈里是 0,圈外是到圈边的距离) */
function eraseGap(st: SketchStroke, px0: number, py: number): number {
  const p = st.pts;
  const px = near(px0, p[0]);
  const m = p.length >> 1;
  let d2 = Infinity;
  let inside = false;
  for (let a = 0; a < m; a++) {
    const b = st.fill ? (a + m - 1) % m : a === 0 ? 0 : a - 1;
    const ax = p[2 * a];
    const ay = p[2 * a + 1];
    const bx = p[2 * b];
    const by = p[2 * b + 1];
    d2 = Math.min(d2, segDist2(px, py, ax, ay, bx, by));
    if (st.fill && ay > py !== by > py && px < ((bx - ax) * (py - ay)) / (by - ay) + ax) inside = !inside;
  }
  if (inside) return 0;
  return Math.max(0, Math.sqrt(d2) - (st.fill ? 0 : st.r));
}
/** 擦掉的这一笔碰到了哪几处放下的火山、湖、河(下标,从小到大):圈碰到圈(火山、湖按半径的一半算),河有一段碰到就算 */
export function erasedOps(ops: readonly TerrainOp[], st: SketchStroke): number[] {
  const out: number[] = [];
  ops.forEach((op, i) => {
    if (!ERASABLE(op.kind)) return;
    if (isPointKind(op.kind)) {
      if (eraseGap(st, op.pts[0], op.pts[1]) < 0.5 * op.r) out.push(i);
      return;
    }
    // 河:每一段按半个笔宽一步取点(两点隔得远时,擦过段的中间也算碰到)
    const p = op.pts;
    const step = Math.max(1, 0.25 * op.r);
    for (let k = 0; k < p.length; k += 2) {
      const bx = k === 0 ? p[0] : near(p[k], p[k - 2]);
      const n = k === 0 ? 1 : Math.min(64, Math.ceil(Math.hypot(bx - p[k - 2], p[k + 1] - p[k - 1]) / step));
      for (let j = 1; j <= n; j++) {
        const t = j / n;
        const x = k === 0 ? p[0] : p[k - 2] + (bx - p[k - 2]) * t;
        const y = k === 0 ? p[1] : p[k - 1] + (p[k + 1] - p[k - 1]) * t;
        if (eraseGap(st, x, y) < 0.5 * op.r) return void out.push(i);
      }
    }
  });
  return out;
}

/** 单击地图:火山、湖在这里放一处(返回 true = 这一下归编辑地形管,不看详情) */
export function terrainClick(w: [number, number] | null): boolean {
  if (!tool.on) return false;
  if (importOn()) {
    importClick(w);
    return true;
  }
  if (w && tool.tool === 'setHeight' && tool.picking) {
    const e = heightAt(w[0], w[1]);
    setTerrainTool(e === null ? { picking: false } : { picking: false, height: Math.round(Math.min(HEIGHT_M[1], Math.max(HEIGHT_M[0], e))) });
    return true;
  }
  if (isPlateTool(tool.tool)) {
    if (w) plateClick(w);
    return true;
  }
  if (w && tool.tool === 'delWater') {
    if (waterAt(w[0], w[1])) addOp({ kind: 'delWater', pts: [Math.round(w[0]), Math.round(w[1])], r: DEL_WATER_R, s: 1 });
    return true;
  }
  if (!w || (tool.tool !== 'volcano' && tool.tool !== 'lake')) return true;
  const r = tool.place[tool.tool];
  const op: TerrainOp = { kind: tool.tool, pts: [Math.round(w[0]), Math.round(w[1])], r, s: presetStrength(tool.tool, r) };
  if (tool.tool === 'lake') op.e = tool.shore;
  addOp(op);
  return true;
}

/** 板块页点了一下地图:选中 = 选中那块;合并 = 先点一块,再点挨着的一块就合成一块(再点先点的那块 = 不选了) */
function plateClick(w: [number, number]) {
  const at: [number, number] = [Math.round(w[0]), Math.round(w[1])];
  const b = plateAtPoint(at[0], at[1]);
  if (b === null) return;
  if (tool.tool === 'plateSelect') return setTerrainTool({ plateAt: at, plateNote: null });
  if (tool.tool !== 'plateMerge') return;
  const a = tool.plateAt ? plateAtPoint(tool.plateAt[0], tool.plateAt[1]) : null;
  if (a === null || !tool.plateAt) return setTerrainTool({ plateAt: at, plateNote: null });
  if (a === b) return setTerrainTool({ plateAt: null, plateNote: null });
  if (!platesTouch(a, b)) return setTerrainTool({ plateNote: MERGE_FAR });
  addPlate({ kind: 'merge', pts: [...tool.plateAt, ...at] });
  setTerrainTool({ plateAt: null, plateNote: null });
}

/**
 * 手机上第二根手指按下:刚按下不久的这一笔不算(是想两根手指拖动、放大),返回 true = 收掉了、可以开始捏合;
 * 已经画了一阵的照旧画完(手掌碰到屏幕不打断)
 */
export function terrainCancel(): boolean {
  if (importOn()) {
    importCancel();
    return true;
  }
  if (draftNow.tip) {
    setDraft({ draft: null, cursor: null });
    return true;
  }
  if (!draftNow.draft) return true;
  if (performance.now() - draftT0 > 400) return false;
  setDraft({ draft: null, cursor: null });
  return true;
}

// ---------------------------------------------------------------------------
// 撤销 / 重做:草图的笔和放的一处按先后混在一起

/**
 * 擦掉的一笔顺带去掉了几处放下的:去掉之前 / 之后的地形修改,和那时的先后记录(撤销 / 重做时整个换回去;
 * 去掉的那几处在 before 里,它们在先后记录里的 'o' 在 orderBefore 里)
 */
interface EraseStep {
  before: readonly TerrainOp[];
  after: readonly TerrainOp[];
  orderBefore: Step[];
  orderAfter: Step[];
}
type Step = 's' | 'o' | 'p' | EraseStep;
type Item = { t: 's'; v: SketchStroke } | { t: 'o'; v: TerrainOp } | { t: 'p'; v: PlateOp } | { t: 'x'; v: SketchStroke; x: EraseStep };
/** 这次编辑里加的先后('s' 草图的一笔,'o' 放的一处,'p' 板块的一处改动,EraseStep 擦掉的一笔连同去掉的几处);和 editsStore 里几份列表的末尾对得上 */
let order: Step[] = [];
/** 撤掉的(最后撤的在最后),和撤完时的样子(之后又改过别的 = 不能重做) */
let redo: Item[] = [];
let redoAt: { terrain: readonly TerrainOp[]; sketch: SketchEdit | undefined } | null = null;

/** 上面几样记录是哪一次整个换掉修改之后记的(换了世界、读档 = 旧记录作废) */
let orderEra = -1;

function trimOrder() {
  if (orderEra !== editsEra()) {
    orderEra = editsEra();
    order = [];
    redo = [];
    redoAt = null;
  }
  const e = getEdits();
  let ns = e.sketch?.strokes.length ?? 0;
  let no = e.terrain.length;
  let np = e.sketch?.plates?.ops.length ?? 0;
  // 从后往前对:多出来的(被别处清掉、撤掉的)去掉
  const keep: Step[] = [];
  for (let i = order.length - 1; i >= 0; i--) {
    if (order[i] === 'o' ? no-- > 0 : order[i] === 'p' ? np-- > 0 : ns-- > 0) keep.push(order[i]);
  }
  order = keep.reverse();
}
function addStroke(st: SketchStroke) {
  trimOrder();
  if (!addSketchStroke(st, tool.coast, tool.fill)) return;
  order.push('s');
  redo = [];
}
function addOp(op: TerrainOp) {
  trimOrder();
  if (!addTerrainOp(op)) return;
  order.push('o');
  redo = [];
}
function addPlate(op: PlateOp) {
  trimOrder();
  if (!addPlateOp(op, tool.coast, tool.fill)) return;
  order.push('p');
  redo = [];
}
/** 去掉照图分(回到程序分的板块;之前的板块改动一起清掉) */
function dropPlateImage() {
  trimOrder();
  if (setPlateImage(null, tool.coast, tool.fill) < 0) return;
  redo = [];
  setTerrainTool({ plateAt: null });
}
/** 照图分:选一张图(选文件框和照手绘图的「换一张」一样放进页面里再点) */
export function pickPlateImage() {
  document.querySelector('input.imp-pick')?.remove();
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.className = 'imp-pick';
  input.hidden = true;
  input.addEventListener('change', () => {
    const f = input.files?.[0];
    input.remove();
    if (f) void plateImageFrom(f);
  });
  document.body.append(input);
  input.click();
}
/**
 * 照这张图分板块:按颜色分成一块块(sketchImage.ts 的 plateRegions),铺满整张当板块图;之前的板块改动清掉(撤销记录里的也作废)。
 * 认不出两块以上出一条提示。返回是否用上了
 */
let plateImageReq = 0;
export async function plateImageFrom(file: File): Promise<boolean> {
  // 读图要等一会:这期间又选了一张、换了世界的,这一张作废
  const req = ++plateImageReq;
  const era = editsEra();
  const l = await loadImage(file);
  if (!l) return false;
  URL.revokeObjectURL(l.url);
  if (req !== plateImageReq || era !== editsEra()) return false;
  const r = plateRegions(l.pic, PLATE_IMAGE_MAX);
  const img = { name: l.name, cells: encodeLayer(placeOnLayer(r.values, l.pic.w, l.pic.h, { fit: 'fill' })) };
  if (!cleanPlateImage(img)) {
    showToast({ id: 'plate-image', kind: 'warn', text: '没从这张图认出几块板块', more: ['每块板块涂一种颜色(或描出分界线)', '至少要两块'] });
    return false;
  }
  trimOrder();
  const dropped = setPlateImage(img, tool.coast, tool.fill);
  if (dropped < 0) return false;
  redo = [];
  setTerrainTool({ tool: 'plateSelect', plateAt: null });
  showToast({ id: 'plate-image', kind: 'ok', text: `照「${l.name}」分成了 ${plateImageCount(img)} 块板块`, more: dropped ? [`之前改的 ${dropped} 处板块清掉了`] : undefined });
  return true;
}
/** 擦掉的一笔,顺带去掉 hit 这几处(地形修改的下标);先后记录里它们的 'o' 一起去掉 */
function eraseStroke(st: SketchStroke, hit: readonly number[]) {
  trimOrder();
  const before = getEdits().terrain;
  const after = before.filter((_, i) => !hit.includes(i));
  // 先后记录里的 'o' 对着地形修改列表的末尾那几处
  let j = before.length - order.filter((x) => x === 'o').length;
  const orderAfter = order.filter((x) => x !== 'o' || !hit.includes(j++));
  const x: EraseStep = { before, after, orderBefore: order, orderAfter };
  if (!addEraseStroke(st, after, tool.coast, tool.fill)) return;
  order = [...orderAfter, x];
  redo = [];
}
/**
 * 「照这样长出星球」:认出来的铺成草图的底子(铺在所有笔画底下,没盖到的地方都是海;换一张时换掉,笔画留着),
 * 这张图和认法留着,收起认的面板。新开的草图程序补全按只补细节(照图这一步的面板没有那一行)。返回是否用上了
 */
export function applyImport(): boolean {
  const r = importResult();
  if (!r || !setSketchBase(r.name, r.layer, tool.coast, SKETCH_FILL_NEW)) return false;
  keepImport();
  return true;
}
const canRedo = (terrain: readonly TerrainOp[], sketch: SketchEdit | undefined) => redo.length > 0 && !!redoAt && redoAt.terrain === terrain && redoAt.sketch === sketch;

/** 撤销最后一笔(这次加的按先后;更早的、助手加的:先撤草图,再撤放的)。照着长的那张图不算一笔,撤不掉 */
export function undoTerrain() {
  trimOrder();
  const e = getEdits();
  const ns = e.sketch?.strokes.length ?? 0;
  const np = e.sketch?.plates?.ops.length ?? 0;
  const popped = order.pop();
  const t = popped ?? (ns ? 's' : e.terrain.length ? 'o' : np ? 'p' : null);
  if (!t) return;
  // 没撤成(被拦下了):撤销、重做的记录都不动
  if (!(t === 's' ? undoSketchStroke() : t === 'p' ? undoPlateOp() : undoTerrainOp())) {
    if (popped) order.push(popped);
    return;
  }
  if (!canRedo(e.terrain, e.sketch)) redo = [];
  if (typeof t === 'object') {
    redo.push({ t: 'x', v: e.sketch!.strokes[ns - 1], x: t });
    if (ns === 1) setTerrainTool({ coast: sketchCoast(e.sketch), fill: sketchFill(e.sketch) });
    undoEraseStroke(t.before);
    order = t.orderBefore.slice();
  } else if (t === 's') {
    redo.push({ t, v: e.sketch!.strokes[ns - 1] });
    // 撤掉最后一笔、草图没了:记下它的海岸线、程序补全,重做时照样
    if (ns === 1) setTerrainTool({ coast: sketchCoast(e.sketch), fill: sketchFill(e.sketch) });
  } else if (t === 'p') {
    redo.push({ t, v: e.sketch!.plates!.ops[np - 1] });
    // 撤掉最后一处、草图没了:同上
    if (!getEdits().sketch) setTerrainTool({ coast: sketchCoast(e.sketch), fill: sketchFill(e.sketch) });
  } else redo.push({ t, v: e.terrain[e.terrain.length - 1] });
  const a = getEdits();
  redoAt = { terrain: a.terrain, sketch: a.sketch };
}
/** 重做刚撤掉的那一笔(撤完以后又改了别的 = 不能重做) */
export function redoTerrain() {
  trimOrder();
  const e = getEdits();
  if (!canRedo(e.terrain, e.sketch)) return;
  const it = redo.pop()!;
  trimOrder();
  if (it.t === 'x') {
    if (addEraseStroke(it.v, it.x.after, tool.coast, tool.fill)) order = [...it.x.orderAfter, it.x];
  } else {
    const ok = it.t === 's' ? addSketchStroke(it.v, tool.coast, tool.fill) : it.t === 'p' ? addPlateOp(it.v, tool.coast, tool.fill) : addTerrainOp(it.v);
    if (ok) order.push(it.t);
  }
  const a = getEdits();
  redoAt = { terrain: a.terrain, sketch: a.sketch };
}
/** 海岸线:贴着画(0)、适中(SKETCH_COAST)、曲折(1);还没画也记着 */
export function setTerrainCoast(v: number) {
  setTerrainTool({ coast: v });
  setSketchCoast(v);
}
/** 程序补全:随意发挥、只补细节、完全照画;还没画也记着 */
export function setTerrainFill(v: SketchFill | 'free') {
  setTerrainTool({ fill: v });
  setSketchFill(v);
}
/** 全部清除:草图、放的火山湖河、旧的地形修改一起清掉,回到程序原来的星球;照手绘图的只清笔画,照着长的那张图留着 */
export function clearAllTerrain() {
  if (!clearTerrainAndSketch(true)) return;
  order = [];
  redo = [];
  redoAt = null;
}

/** 编辑地形画了几笔:草图的笔 + 放的一处(连同旧的地形修改)+ 板块的改动 */
export function terrainCount(e: { terrain: readonly TerrainOp[]; sketch?: SketchEdit }): number {
  return e.terrain.length + (e.sketch?.strokes.length ?? 0) + (e.sketch?.plates?.ops.length ?? 0);
}
/** 入口那一行、创建前确认框里地形那一行右边写什么(none = 一笔没画时) */
export function terrainSide(e: { terrain: readonly TerrainOp[]; sketch?: SketchEdit }, none: string): string {
  const n = terrainCount(e);
  if (e.sketch?.image) return n ? `照一张图，又画了 ${n} 笔` : '照一张图';
  if (e.sketch?.plates?.image) return n ? `照图分板块，又画了 ${n} 笔` : '照图分板块';
  if (n) return `画了 ${n} 笔`;
  // 一笔没画:没涂的地方都是海 / 不长新陆地(整颗星球是海),或者只关了板块相撞造山
  if (e.sketch?.rest === 'sea' || e.sketch?.rest === 'noNewLand') return '都是海';
  return e.sketch?.plates?.orogeny === false ? '相撞不造山' : none;
}

// ---------------------------------------------------------------------------
// 工具面板

/** App 给的状态:重新生成中、上一次重新生成的结果 */
export interface TerrainStatus {
  /** 正在按新地形重新生成 */
  busy: boolean;
  /** 上一次重新生成:花了多久(毫秒)、多少处改名在新历史里对不上、多少条干预没生效(和世界概览"我的干预"页一个口径) */
  last?: { ms: number; lostNames: number; lostInterventions: number } | null;
}

/**
 * 定高的海拔:能直接打字的框(单位"米"浅浅写在框里右边),回车或点别处算数(夹到 HEIGHT_M),Esc 放弃;
 * 右边「从地图上取」(手机上是「取」):再点一下地图取那里的海拔,取的时候链接是按下的样子
 */
function HeightField({ value, picking, phone }: { value: number; picking: boolean; phone: boolean }) {
  const [text, setText] = useState<string | null>(null);
  // 点进框里整个选中,打的数字替换原来的(选中以后不改框里的字,也不让松开鼠标把选中取消)
  const [fresh, setFresh] = useState(false);
  const commit = () => {
    setFresh(false);
    if (text === null) return;
    const v = Number(text.replace(/[,，\s米]/g, '').replace('−', '-'));
    setText(null);
    if (text.trim() && Number.isFinite(v)) setTerrainTool({ height: Math.round(Math.min(HEIGHT_M[1], Math.max(HEIGHT_M[0], v))) });
  };
  return (
    <div className="tp-lbl">
      <b>海拔</b>
      <div className="tp-num">
        <label className="tp-num-box">
          <input
            type="text"
            inputMode="numeric"
            aria-label="海拔(米)"
            data-act="terrain-elev"
            value={text ?? fmtM(value)}
            onFocus={(e) => {
              setText(fmtM(value));
              setFresh(true);
              e.currentTarget.select();
            }}
            onMouseUp={(e) => {
              if (fresh) e.preventDefault();
              setFresh(false);
            }}
            onChange={(e) => setText(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => {
              if (e.key === 'Enter') e.currentTarget.blur();
              else if (e.key === 'Escape') {
                e.stopPropagation();
                setText(null);
                requestAnimationFrame(() => (document.activeElement as HTMLElement | null)?.blur());
              }
            }}
          />
          <span>米</span>
        </label>
        <button className={`sb-link${picking ? ' on' : ''}`} aria-pressed={picking} data-act="terrain-pick" onClick={() => setTerrainTool({ picking: !picking })}>
          {phone ? '取' : '从地图上取'}
        </button>
      </div>
    </div>
  );
}

/** 大小滑条:两头一个小点、一个大点,右边写半径 */
function SizeSlider({ r, min = SKETCH_R[0] }: { r: number; min?: number }) {
  const v = Math.max(min, r);
  return <Slider label="大小" act="terrain-size" min={min} max={SKETCH_R[1]} value={v} onChange={(x) => setTerrainTool({ r: x })} show={v} />;
}

/**
 * 编辑地形开着时的键盘(熟手的加速,功能都有按钮):Esc 收起,Ctrl / ⌘ + Z 撤销,加 Shift(或 Ctrl + Y)重做,按住空格拖动 = 平移。
 * 认图的时候:Ctrl / ⌘ + Z 撤销点的那一下,Esc 不管(照手绘图的这一步收不掉,要点「照这样长出星球」或去别的步)。
 * 新建界面挂一次(两种新建都用)
 */
export function useTerrainKeys() {
  const on = useTerrainTool().on;
  useEffect(() => {
    if (!on) return;
    const typing = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement | null;
      return !!el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable) && (el as HTMLInputElement).type !== 'range';
    };
    const down = (e: KeyboardEvent) => {
      if (typing(e)) return;
      const k = e.key.toLowerCase();
      const mod = e.metaKey || e.ctrlKey;
      if (importOn()) {
        if (mod && (k === 'y' || k === 'z')) {
          e.preventDefault();
          if (k === 'z' && !e.shiftKey) importUndoClick();
        }
      } else if (e.key === 'Escape') setTerrainTool({ on: false });
      else if (mod && (k === 'y' || (k === 'z' && e.shiftKey))) {
        e.preventDefault();
        redoTerrain();
      } else if (mod && k === 'z') {
        e.preventDefault();
        undoTerrain();
      } else if (e.code === 'Space') {
        e.preventDefault();
        if (!space) {
          space = true;
          document.body.classList.add('terrain-pan');
        }
      } else if (e.key === 'Alt') {
        // Alt:抬高、压低反过来(不让浏览器把焦点挪到菜单栏)
        e.preventDefault();
        if (!draftNow.alt) setDraft({ ...draftNow, alt: true });
      }
    };
    const up = (e: KeyboardEvent) => {
      if (e.key === 'Alt') {
        e.preventDefault();
        if (draftNow.alt) setDraft({ ...draftNow, alt: false });
        return;
      }
      if (e.code !== 'Space') return;
      if (!typing(e)) e.preventDefault(); // 焦点停在按钮上时,空格不去按那个按钮
      space = false;
      document.body.classList.remove('terrain-pan');
    };
    // 切走窗口时 Alt 松开收不到
    const blur = () => {
      if (draftNow.alt) setDraft({ ...draftNow, alt: false });
    };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', blur);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', blur);
      blur();
      space = false;
      document.body.classList.remove('terrain-pan');
    };
  }, [on]);
}

/** 这支笔怎么用(随机生成的面板里写在笔下面;照手绘图的写在地图下边,见 terrainHint) */
function toolHint(t: TerrainToolState, phone: boolean): string {
  if (t.tool === 'delWater') return DEL_WATER.hint;
  if (isPlateTool(t.tool)) return t.plateNote ?? (t.tool === 'plateMerge' && t.plateAt ? MERGE_NEXT : PLATE.find((x) => x.id === t.tool)!.hint);
  const place = isPlaceTool(t.tool) ? PLACE.find((x) => x.id === t.tool)! : null;
  if (place) return place.hint;
  const height = HEIGHT.find((x) => x.id === t.tool);
  if (height) return phone ? height.phone : height.hint;
  const climate = CLIMATE.find((x) => x.id === t.tool);
  if (climate) return phone ? `${climate.hint.split('：')[0]}，只改气候、不动地形。` : t.method === 'lasso' ? LASSO_HINT : climate.hint;
  if (t.method === 'lasso') return LASSO_HINT;
  return phone ? PHONE_HINT : PAINT.find((x) => x.id === t.tool)!.hint;
}

/**
 * 照手绘图第 2 步、地图下边的一句(这支笔怎么用;正在圈的时候说松手会怎样)。涂抹的笔都是同一句
 */
export function useTerrainHint(): string {
  const t = useTerrainTool();
  const d = useDraft();
  if (d.draft && lassoOn(t)) return lassoCaption(t);
  if (t.tool === 'setHeight' && t.picking) return PICK_HINT.replace(/。$/, '');
  if (pageOf(t.tool) !== 'shape' || isPlaceTool(t.tool) || t.tool === 'delWater' || t.method === 'lasso') return toolHint(t, false).replace(/。$/, '');
  if (t.tool === 'erase') return '按住拖动来擦；碰到的火山、湖、河整个去掉';
  return '按住拖动来涂；松手后星球照着重新长';
}

/**
 * 编辑地形的面板。
 * 随机生成(新建世界卡片里"编辑地形"点开后的样子):涂一片的八支笔、放一处的三样;这支笔的画法 / 大小 / 高低和一句怎么用;
 * 整张草图的海岸线、没涂的地方、画了几笔(撤销 / 重做 / 全部清除)、在地图上显示草图。组头右边"完成"(收起)。
 * 照手绘图生成(mode = 'image',第 2 步「用笔修改」展开的样子):没有组头;同样分四页,笔、画法 / 大小 / 高低、海岸线 / 程序补全、画了几笔、
 * 显示草图一路排下来,最后是 extra(「让助手改」);没有"没涂的地方"(没盖到的都是海),怎么用写在地图下边。
 * 照图长的陆地整片都算涂过,程序补全不是随意发挥时板块相撞不在陆地上造山:板块页多一句提示。
 * 世界还在生成时"画了几笔"那里写"生成中…"。手机上工具排成一行横着滑,随机生成的海岸线和没涂的地方收进「整张草图」那一行(点开展开)。
 */
export function TerrainPanel({ disabled, phone = false, mode = 'random', extra }: { disabled: boolean; phone?: boolean; mode?: 'random' | 'image'; extra?: ReactNode }) {
  const t = useTerrainTool();
  const edits = useEdits();
  const [confirm, setConfirm] = useState(false);
  const [wholeOpen, setWholeOpen] = useState(false);
  const n = terrainCount(edits);
  const sk = edits.sketch;
  const image = mode === 'image';
  const coast = sk ? sketchCoast(sk) : t.coast;
  const rest = sk?.rest ?? 'auto';
  const fill = sk ? sketchFill(sk) : t.fill;
  const redoOk = canRedo(edits.terrain, sk);

  // 手机上改气候只有涂抹
  useEffect(() => {
    if (phone && isClimateTool(t.tool) && t.method === 'lasso') setTerrainTool({ method: 'paint' });
  }, [phone, t.tool, t.method]);

  useEffect(() => {
    if (!confirm) return;
    const id = setTimeout(() => setConfirm(false), 3000);
    return () => clearTimeout(id);
  }, [confirm]);

  const place = isPlaceTool(t.tool) ? PLACE.find((x) => x.id === t.tool)! : null;
  // 分四页:高度五支笔一页、气候四支笔一页、板块一页,其余(涂一片、放一处)一页
  const page: TerrainPage = pageOf(t.tool);
  const climatePage = page === 'climate';

  const tile = (id: EditTool, name: string, mark: ReactNode) => (
    <button key={id} className={`tp-tile${t.tool === id ? ' on' : ''}`} role="radio" aria-checked={t.tool === id} data-tool={id} onClick={() => setTerrainTool({ tool: id })}>
      {mark}
      {name}
    </button>
  );
  const paintTiles = PAINT.map((x) => tile(x.id, x.name, <i className={`tp-sw k-${x.id}`} />));
  const placeTiles = [...PLACE, DEL_WATER].map((x) => tile(x.id, x.name, <Icon name={x.icon} size={18} />));
  const climateTiles = CLIMATE.map((x) => tile(x.id, x.name, <i className={`tp-sw k-${x.id}`} />));
  const heightTiles = HEIGHT.map((x) => tile(x.id, x.name, <Icon name={x.icon} size={18} />));
  const plateTiles = [
    ...PLATE.map((x) => tile(x.id, x.name, <Icon name={x.icon} size={18} />)),
    <button key="plateImage" className="tp-tile" data-act="terrain-plate-image" onClick={pickPlateImage}>
      <Icon name="plImage" size={18} />
      照图分
    </button>,
  ];
  const pages = (
    <div className="tp-seg tp-pages" role="tablist" aria-label="编辑什么" data-act="terrain-page">
      {(['shape', 'height', 'climate', 'plates'] as const).map((p) => (
        <button key={p} role="tab" aria-selected={page === p} className={page === p ? 'on' : ''} data-v={p} onClick={() => setTerrainPage(p)}>
          {PAGE_NAME[p]}
        </button>
      ))}
    </div>
  );
  const toolList = page === 'height' ? (
    <div className={phone ? 'tp-strip' : 'tp-tools'} role="radiogroup" aria-label="工具">
      {phone ? heightTiles : <div className="tp-tiles c3">{heightTiles}</div>}
    </div>
  ) : page === 'plates' ? (
    <div className={phone ? 'tp-strip' : 'tp-tools'} role="radiogroup" aria-label="工具">
      {phone ? plateTiles : <div className="tp-tiles c4">{plateTiles}</div>}
    </div>
  ) : climatePage ? (
    <div className={phone ? 'tp-strip' : 'tp-tools'} role="radiogroup" aria-label="工具">
      {phone ? climateTiles : <div className="tp-tiles c4">{climateTiles}</div>}
    </div>
  ) : phone ? (
    <div className="tp-strip" role="radiogroup" aria-label="工具">
      {paintTiles}
      <span className="tp-bar" />
      {placeTiles}
    </div>
  ) : (
    <div className="tp-tools" role="radiogroup" aria-label="工具">
      <div className="tp-sub">涂一片</div>
      <div className="tp-tiles c4">{paintTiles}</div>
      <div className="tp-sub">放一处</div>
      <div className="tp-tiles c4">{placeTiles}</div>
    </div>
  );

  const coastSeg = <Seg label="海岸线" act="terrain-coast" items={COASTS} value={coast} onPick={setTerrainCoast} />;
  const picked = page === 'plates' && t.tool === 'plateSelect' && probe ? pickedArrow(t) : null;
  const orogeny = sk?.plates?.orogeny !== false;
  const plImg = sk?.plates?.image;
  const penOpts = (
    <div className="tp-opts">
      {page === 'plates' ? (
        <>
          {plImg && (
            <div className="sb-row tp-image" data-act="terrain-plate-image-row">
              <span className="sb-row-main">
                照「{plImg.name || '图片'}」分了 {plateImageCount(plImg)} 块
              </span>
              <button className="sb-link" data-act="terrain-plate-image-off" onClick={dropPlateImage}>
                去掉
              </button>
            </div>
          )}
          {picked && (
            <>
              <Seg
                label="地壳"
                act="terrain-crust"
                items={CRUSTS}
                value={probe!.world.tect.plateContinental[picked.k] ? 'continental' : 'oceanic'}
                onPick={(v) => t.plateAt && addPlate({ kind: 'set', pts: [...t.plateAt], crust: v })}
              />
              <div className="tp-lbl" data-act="terrain-drift">
                <b>漂移</b>
                <span className="tp-drift">{arrowText(picked.a)}</span>
              </div>
            </>
          )}
          <button className="sb-row tp-show tp-orogeny" role="switch" aria-checked={orogeny} data-act="terrain-orogeny" onClick={() => setPlateOrogeny(!orogeny, t.coast, t.fill)}>
            <span className="sb-row-main">板块相撞时造山</span>
            <span className={`ai-switch${orogeny ? ' on' : ''}`} aria-hidden="true" />
          </button>
        </>
      ) : page === 'height' ? (
        <>
          <SizeSlider r={t.r} min={TERRAIN_R[0]} />
          {t.tool === 'setHeight' ? (
            <>
              <HeightField value={t.height} picking={t.picking} phone={phone} />
              {!phone && <Seg label="边缘" act="terrain-edge" items={EDGES.map((name, i) => ({ v: i as 0 | 1 | 2, name }))} value={t.edge} onPick={(v) => setTerrainTool({ edge: v })} />}
            </>
          ) : (
            <Slider
              label="力度"
              act="terrain-power"
              min={Math.round(HEIGHT_S[0] * 100)}
              max={Math.round(HEIGHT_S[1] * 100)}
              value={Math.round(t.power * 100)}
              onChange={(v) => setTerrainTool({ power: v / 100 })}
              show={`${Math.round(t.power * 100)}%`}
            />
          )}
        </>
      ) : place ? (
        <>
          <Slider
            label={place.size}
            act="terrain-place-size"
            min={PLACE_R[place.id][0]}
            max={PLACE_R[place.id][1]}
            value={t.place[place.id]}
            onChange={(v) => setTerrainTool({ place: { ...t.place, [place.id]: v } })}
            show={t.place[place.id]}
          />
          {place.id === 'lake' && <Seg label="湖岸" act="terrain-shore" items={SHORES} value={t.shore} onPick={(v) => setTerrainTool({ shore: v })} />}
        </>
      ) : (
        <>
          {/* 手机上改气候只有涂抹(卡片矮,少一行) */}
          {!(phone && isClimateTool(t.tool)) && (
            <Seg
              label="画法"
              act="terrain-method"
              items={[
                { v: 'paint' as const, name: '涂抹' },
                { v: 'lasso' as const, name: '圈起来填满' },
              ]}
              value={t.method}
              onPick={(v) => setTerrainTool({ method: v })}
            />
          )}
          <SizeSlider r={t.r} min={isClimateTool(t.tool) ? TERRAIN_R[0] : undefined} />
          {t.tool === 'mountain' && <Seg label="高低" act="terrain-height" items={HEIGHTS.map((name, i) => ({ v: i as 0 | 1 | 2, name }))} value={t.h} onPick={(v) => setTerrainTool({ h: v })} />}
          {isClimateTool(t.tool) && <Seg label="程度" act="terrain-level" items={LEVELS.map((name, i) => ({ v: i as 0 | 1 | 2, name }))} value={t.level} onPick={(v) => setTerrainTool({ level: v })} />}
        </>
      )}
    </div>
  );
  const fillSeg = <Seg label="程序补全" act="terrain-fill" items={FILLS} value={fill} onPick={setTerrainFill} />;
  const penless = t.tool === 'delWater' || t.tool === 'plateCut' || t.tool === 'plateMerge';

  const wholeOpts = (
    <div className="tp-opts">
      {coastSeg}
      {fillSeg}
      <Seg label="没涂的地方" act="terrain-rest" items={RESTS} value={rest} onPick={(v) => setSketchRest(v, t.coast, t.fill)} />
    </div>
  );
  const count = (
    <div className="tp-count">
      <b className="tp-n">{disabled ? '生成中…' : n ? `画了 ${n} 笔` : '还没画'}</b>
      <button className="sb-link" data-act="terrain-undo" disabled={!n} onClick={undoTerrain} title="撤销最后一笔(Ctrl / ⌘ + Z)">
        撤销
      </button>
      <button className="sb-link" data-act="terrain-redo" disabled={!redoOk} onClick={redoTerrain} title="重做(Ctrl / ⌘ + Shift + Z)">
        重做
      </button>
      <button
        className={`sb-link${confirm ? ' danger' : ''}`}
        data-act="terrain-clear"
        disabled={!n && (image || !sk)}
        onClick={() => {
          if (!confirm) return setConfirm(true);
          setConfirm(false);
          clearAllTerrain();
        }}
      >
        {confirm ? '确认清除' : '全部清除'}
      </button>
    </div>
  );
  const showRow = (
    <button className="sb-row tp-show" role="switch" aria-checked={t.show} data-act="terrain-show" onClick={() => setTerrainTool({ show: !t.show })}>
      <span className="sb-row-main">在地图上显示草图</span>
      <span className={`ai-switch${t.show ? ' on' : ''}`} aria-hidden="true" />
    </button>
  );

  if (image)
    return (
      <div className="tp tp-step" role="toolbar" aria-label="用笔修改">
        {pages}
        {toolList}
        {!penless && penOpts}
        <div className="tp-opts">
          {coastSeg}
          {fillSeg}
        </div>
        {page === 'plates' && fill !== 'free' && (
          <div className="tp-hint" data-act="terrain-plate-fill-hint">
            陆地是照图长的：程序补全选「随意发挥」，板块相撞才会在陆地上造山。
          </div>
        )}
        {count}
        {showRow}
        {extra}
      </div>
    );

  const coastName = COASTS.find((x) => x.v === coast)?.name ?? '适中';
  return (
    <div className="tp" role="toolbar" aria-label="编辑地形">
      <section className="sb-sec">
        <div className="sb-sec-head">
          <span>编辑地形</span>
          <button className="sb-link tp-done" data-act="terrain-done" onClick={() => setTerrainTool({ on: false })}>
            完成
          </button>
        </div>
        {pages}
        <div className="sb-group">{toolList}</div>
      </section>
      <div className="sb-group">
        {!penless && penOpts}
        <div className="tp-hint">{t.tool === 'setHeight' && t.picking ? PICK_HINT : toolHint(t, phone)}</div>
      </div>
      {phone ? (
        <div className="sb-group">
          <button className={`sb-row tp-whole${wholeOpen ? ' open' : ''}`} data-act="terrain-whole" aria-expanded={wholeOpen} onClick={() => setWholeOpen((o) => !o)}>
            <Icon name="sketch" size={18} className="sb-ico" />
            <span className="sb-row-main">
              <b>整张草图</b>
            </span>
            {!wholeOpen && <span className="sb-row-side">{`${coastName}，${RESTS.find((x) => x.v === rest)?.name ?? '交给程序'}`}</span>}
            <Icon name={wholeOpen ? 'down' : 'chevron'} size={14} className="sb-chev" />
          </button>
          {wholeOpen && (
            <>
              {wholeOpts}
              {showRow}
            </>
          )}
          {count}
        </div>
      ) : (
        <section className="sb-sec">
          <div className="sb-sec-head">
            <span>整张草图</span>
          </div>
          <div className="sb-group">
            {wholeOpts}
            {count}
            {showRow}
          </div>
        </section>
      )}
    </div>
  );
}

/** 圈起来填满正在画的时候说松手会怎样 */
function lassoCaption(t: TerrainToolState): string {
  if (t.tool === 'erase') return '松手自动连上起点，圈里整片交还给程序';
  return `松手自动连上起点，圈里整片变成${PAINT.find((x) => x.id === t.tool)?.name ?? ''}`;
}

/**
 * 随机生成的编辑地形:圈起来填满正在画的时候,地图底下的一句提示(松手会怎样)。电脑上贴在地图下边(地图放大出了屏幕就贴着窗口底),手机上在卡片上面
 */
export function TerrainCaption({ phone }: { phone: boolean }) {
  const t = useTerrainTool();
  const d = useDraft();
  const on = t.on && !!d.draft && lassoOn(t);
  let style: React.CSSProperties | undefined;
  if (on && !phone) {
    // 地图左右无限接着画,横着看的就是舞台(两边面板中间那一块);竖着取地图下边和舞台下边靠上的那个
    const r = document.querySelector('.terrain-overlay')?.getBoundingClientRect();
    const stage = document.querySelector('.stage')?.getBoundingClientRect();
    if (r && stage) style = { left: (stage.left + stage.right) / 2, top: Math.min(Math.min(r.bottom, stage.bottom) + 22, window.innerHeight - 66), bottom: 'auto' };
  }
  return (
    <div className={`st-cap st-tip tp-cap${on ? '' : ' off'}`} style={style} aria-hidden={!on}>
      {lassoCaption(t)}
    </div>
  );
}

// ---------------------------------------------------------------------------
// 地图覆盖层

const pathOf = (pts: readonly number[]) => {
  let d = `M${pts[0]} ${pts[1]}`;
  for (let i = 2; i < pts.length; i += 2) d += `L${pts[i]} ${pts[i + 1]}`;
  // 只有一个点:画一个零长度的线段,圆头笔画成一个点
  if (pts.length === 2) d += `L${pts[0] + 0.01} ${pts[1]}`;
  return d;
};

/**
 * 一处修改在地图上的记号:圈(火山、湖)、带子 + 中线(山脉)、带子(画笔、改气候;圈起来填满的是一块)、亮蓝的线(河);
 * 线都描一道暗边,浅色、深色的底上都看得清。doomed = 正在擦的这一笔碰到了它(描红,松手就去掉)
 */
function OpMark({ op, pending, doomed = false }: { op: TerrainOp; pending: boolean; doomed?: boolean }) {
  const cls = `tt-mark k-${op.kind}${pending ? ' pending' : ''}${doomed ? ' doomed' : ''}`;
  // 高度笔:只有一条淡白的带子(笔走过的地方)
  if (isHeightKind(op.kind))
    return (
      <g className={`${cls} k-height`}>
        <path className="tt-band" d={pathOf(op.pts)} strokeWidth={op.r * 2} />
      </g>
    );
  if (isPointKind(op.kind))
    return (
      <g className={cls}>
        <circle className="tt-halo" cx={op.pts[0]} cy={op.pts[1]} r={op.r} vectorEffect="non-scaling-stroke" />
        <circle className="tt-line" cx={op.pts[0]} cy={op.pts[1]} r={op.r} vectorEffect="non-scaling-stroke" />
      </g>
    );
  const d = pathOf(op.pts);
  if (op.f)
    return (
      <g className={`${cls} fill`}>
        <path className="tt-area" d={`${d}Z`} />
        <path className="tt-halo" d={`${d}Z`} vectorEffect="non-scaling-stroke" />
        <path className="tt-line" d={`${d}Z`} vectorEffect="non-scaling-stroke" />
      </g>
    );
  if (op.kind === 'river')
    return (
      <g className={cls}>
        <path className="tt-river" d={d} vectorEffect="non-scaling-stroke" />
      </g>
    );
  return (
    <g className={cls}>
      <path className="tt-band" d={d} strokeWidth={op.r * (op.kind === 'range' ? 1.6 : 2)} />
      <path className="tt-halo" d={d} vectorEffect="non-scaling-stroke" />
      <path className="tt-line" d={d} vectorEffect="non-scaling-stroke" />
    </g>
  );
}

/** 草图的一笔:涂抹 = 笔走过的一条宽带子;圈起来填满 = 一块填色的区域描一圈细边;群岛再叠一层小岛的花纹 */
function StrokeMark({ s, pending, pat }: { s: SketchStroke; pending: boolean; pat: string }) {
  const cls = `sk-mark k-${s.kind}${pending ? ' pending' : ''}`;
  if (s.fill)
    return (
      <g className={`${cls} fill`}>
        <path className="sk-area" d={`${pathOf(s.pts)}Z`} />
        {s.kind === 'isles' && <path d={`${pathOf(s.pts)}Z`} style={{ fill: `url(#${pat})`, fillRule: 'evenodd' }} />}
        <path className="sk-edge" d={`${pathOf(s.pts)}Z`} vectorEffect="non-scaling-stroke" />
      </g>
    );
  const d = pathOf(s.pts);
  return (
    <g className={cls}>
      <path className="sk-band" d={d} strokeWidth={s.r * 2} />
      {s.kind === 'isles' && <path d={d} style={{ stroke: `url(#${pat})` }} strokeWidth={s.r * 2} />}
    </g>
  );
}

const sameStroke = (a: SketchStroke, b: SketchStroke) =>
  a === b || (a.kind === b.kind && a.r === b.r && a.h === b.h && a.fill === b.fill && a.pts.length === b.pts.length && a.pts.every((v, i) => v === b.pts[i]));
const NO_STROKES: readonly SketchStroke[] = [];
const NO_HIT: number[] = [];
const disp = (pts: readonly number[], wrap: number) => (wrap ? displayPts(pts, wrap) : (pts as number[]));

/**
 * 草图那一层:按先后叠;遇到擦掉的一笔,把之前叠好的整个用它挖掉(左右各挪一圈也挖,跨 180° 经线的照样擦得掉)。
 * erasing = 正在用擦掉涂的那一笔(跟着一起挖,淡淡描出擦到哪儿)
 */
function sketchLayer(
  strokes: readonly SketchStroke[],
  sameS: number,
  image: { img: SketchImage; pending: boolean } | null,
  erasing: SketchStroke | null,
  uid: string,
  width: number,
  height: number,
  wrap: number,
) {
  const pat = `${uid}-isles`;
  const masks: ReactNode[] = [];
  let body: ReactNode[] = [];
  type Entry = { s: SketchStroke; pending: boolean; draft: boolean } | { img: SketchImage; pending: boolean };
  const list: Entry[] = strokes.map((s, i) => ({ s, pending: i >= sameS, draft: false }));
  // 导入的图铺在第 at 笔之后(前面的笔被它盖住,后面的盖在它上面)
  if (image) list.splice(Math.min(image.img.at ?? 0, list.length), 0, image);
  if (erasing) list.push({ s: erasing, pending: true, draft: true });
  list.forEach((e, i) => {
    if ('img' in e) {
      // 导入的图盖住的格子(海也算)生成时盖掉了前面的笔:前面画好的整个用它挖掉,再画这一层
      const url = body.length ? coverMaskUrl(e.img.cells) : '';
      if (url) {
        const id = `${uid}-i${i}`;
        masks.push(
          <mask key={id} id={id} maskUnits="userSpaceOnUse" x={-width} y={-height} width={width * 4} height={height * 3}>
            <rect x={-width} y={-height} width={width * 4} height={height * 3} fill="#fff" />
            {[0, ...(wrap ? [-wrap, wrap] : [])].map((dx) => (
              <image key={dx} href={url} x={dx} y={0} width={width} height={height} preserveAspectRatio="none" />
            ))}
          </mask>,
        );
        body = [
          <g key={id} mask={`url(#${id})`}>
            {body}
          </g>,
        ];
      }
      return void body.push(<LayerMark key={i} image={e.img} width={width} height={height} pending={e.pending} />);
    }
    const { s, pending, draft } = e;
    if (s.kind !== 'erase') return void body.push(<StrokeMark key={i} s={{ ...s, pts: disp(s.pts, wrap) }} pending={pending} pat={pat} />);
    const id = `${uid}-e${i}`;
    const d = s.fill ? `${pathOf(disp(s.pts, wrap))}Z` : pathOf(disp(s.pts, wrap));
    masks.push(
      <mask key={id} id={id} maskUnits="userSpaceOnUse" x={-width} y={-height} width={width * 4} height={height * 3}>
        <rect x={-width} y={-height} width={width * 4} height={height * 3} fill="#fff" />
        {[0, ...(wrap ? [-wrap, wrap] : [])].map((dx) => (
          <path key={dx} d={d} transform={dx ? `translate(${dx} 0)` : undefined} fill={s.fill ? '#000' : 'none'} stroke={s.fill ? 'none' : '#000'} strokeWidth={s.fill ? undefined : s.r * 2} />
        ))}
      </mask>,
    );
    body = [
      <g key={id} mask={`url(#${id})`}>
        {body}
      </g>,
    ];
    if (draft) body.push(<path key={`${id}-d`} className="sk-erasing" d={d} strokeWidth={s.r * 2} />);
  });
  return { masks, body };
}

/** 两个世界坐标点在球面上的距离(弦长,和生成时 geometry.ts 的 pointDist 同一个算法;只给读数用) */
function chord(ax: number, ay: number, bx: number, by: number): number {
  const W = probe?.world.width ?? 2048;
  const H = probe?.world.height ?? 1024;
  const unit = (x: number, y: number) => {
    const lon = (x / W) * 2 * Math.PI - Math.PI;
    const lat = Math.PI / 2 - (y / H) * Math.PI;
    return [Math.cos(lat) * Math.cos(lon), Math.cos(lat) * Math.sin(lon), Math.sin(lat)];
  };
  const a = unit(ax, ay);
  const b = unit(bx, by);
  return (W / (2 * Math.PI)) * Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
}

/**
 * 高度笔指针旁的读数:定高 = "原来多高 → 涂完多高"(取海拔的时候只写这里多高);
 * 抬高 / 压低涂的时候 = 这一笔在指针处抬了多少("+120 米");别的笔、没有世界时不写
 */
function heightTip(t: TerrainToolState, dr: Draft, arrow: number): string | null {
  const [x, y] = dr.cursor!;
  if (t.tool === 'setHeight') {
    const e = heightAt(x, y);
    if (e === null) return null;
    return t.picking ? `${fmtM(e)} 米` : `${fmtM(e)} 米 → ${fmtM(t.height)} 米`;
  }
  if ((t.tool === 'lift' || t.tool === 'lower') && dr.draft) {
    const d = liftAt({ kind: arrow < 0 ? 'lower' : 'lift', pts: dr.draft, r: radiusOf(t), s: t.power }, x, y, chord);
    return `${d < 0 ? '−' : '+'}${fmtM(Math.abs(d))} 米`;
  }
  return null;
}

/** 光标圈里的箭头(屏幕上 16 像素高):dir 1 朝上、−1 朝下 */
function arrowPath(x: number, y: number, dir: number, k: number): string {
  const u = 1 / k;
  const h = 8 * u * dir;
  return `M${x} ${y + h}V${y - h}M${x - 6 * u} ${y - h + 6 * u * dir}L${x} ${y - h}L${x + 6 * u} ${y - h + 6 * u * dir}`;
}

/** 量字宽(屏幕像素,13px 的界面字体) */
let measure: CanvasRenderingContext2D | null | undefined;
function textWidth(s: string): number {
  if (measure === undefined) {
    measure = typeof document === 'undefined' ? null : document.createElement('canvas').getContext('2d');
    if (measure) measure.font = `13px ${getComputedStyle(document.body).fontFamily}`;
  }
  return measure ? measure.measureText(s).width : s.length * 8;
}

/** 指针旁的读数(世界坐标里画,字和框按屏幕像素定大小:k = 屏幕上一个世界单位多少像素);左边贴着 x、上下居中在 y */
function HeightTip({ x, y, text, scale: k }: { x: number; y: number; text: string; scale: number }) {
  const u = 1 / k;
  const w = textWidth(text) + 20;
  return (
    <g className="tt-tip">
      <rect x={x} y={y - 14 * u} width={w * u} height={28 * u} rx={8 * u} />
      <text x={x + 10 * u} y={y + 0.5 * u} fontSize={13 * u} dominantBaseline="central">
        {text}
      </text>
    </g>
  );
}

/**
 * 选中的板块的漂移箭头:白色粗箭头描暗边,起点一个白点;handle = 箭头头上套一个圈(能拖);text = 箭头头右边的读数。
 * 线宽、点和圈按屏幕像素定大小(k = 屏幕上一个世界单位多少像素)
 */
function PlateArrowMark({ x0, y0, x1, y1, handle, text, scale: k }: { x0: number; y0: number; x1: number; y1: number; handle: boolean; text: string | null; scale: number }) {
  const u = 1 / k;
  const len = Math.hypot(x1 - x0, y1 - y0);
  // 箭头头:沿箭头方向 18 像素长、两边各 9 像素宽的三角,尖顶在圈里(太短时缩短)
  const ux = len > 0 ? (x1 - x0) / len : 0;
  const uy = len > 0 ? (y1 - y0) / len : 0;
  const hl = Math.min(18 * u, len);
  const tx = x1 - ux * Math.min(3 * u, len - hl);
  const ty = y1 - uy * Math.min(3 * u, len - hl);
  const head = `M${tx} ${ty}L${tx - ux * hl - uy * 9 * u} ${ty - uy * hl + ux * 9 * u}L${tx - ux * hl + uy * 9 * u} ${ty - uy * hl - ux * 9 * u}Z`;
  const shaft = `M${x0} ${y0}L${tx - ux * hl * 0.6} ${ty - uy * hl * 0.6}`;
  return (
    <g className="tt-plate">
      <path className="tt-plate-halo" d={shaft} vectorEffect="non-scaling-stroke" />
      <path className="tt-plate-shaft" d={shaft} vectorEffect="non-scaling-stroke" />
      {len > 0 && <path className="tt-plate-head" d={head} />}
      <circle className="tt-plate-dot" cx={x0} cy={y0} r={6 * u} vectorEffect="non-scaling-stroke" />
      {handle && <circle className="tt-plate-ring" cx={x1} cy={y1} r={9 * u} vectorEffect="non-scaling-stroke" />}
      {text && <HeightTip x={x1 + 14 * u} y={y1 - 12 * u} text={text} scale={k} />}
    </g>
  );
}

/**
 * 删河湖指着的湖 / 河描红(x0 = 光标的 x:画在光标那一圈)。湖画成一个虚线椭圆(按湖里地块的位置量出来的,外扩小半个地块),
 * 河(连同流进它的支流)画成红线
 */
function WaterMark({ hit, x0 }: { hit: { lake: number[] } | { rivers: number[] }; x0: number }) {
  if (!probe) return null;
  const { world } = probe;
  const W = world.width;
  const near0 = (x: number, ref: number) => x - W * Math.round((x - ref) / W);
  if ('lake' in hit) {
    const { x, y, spacing } = world.mesh;
    let mx = 0;
    let my = 0;
    const xs = hit.lake.map((c) => near0(x[c], x0));
    hit.lake.forEach((c, k) => {
      mx += xs[k];
      my += y[c];
    });
    const m = hit.lake.length;
    mx /= m;
    my /= m;
    let sxx = 0;
    let syy = 0;
    let sxy = 0;
    hit.lake.forEach((c, k) => {
      const dx = xs[k] - mx;
      const dy = y[c] - my;
      sxx += dx * dx;
      syy += dy * dy;
      sxy += dx * dy;
    });
    sxx /= m;
    syy /= m;
    sxy /= m;
    const half = (sxx + syy) / 2;
    const dev = Math.sqrt(((sxx - syy) / 2) ** 2 + sxy * sxy);
    const a = 2 * Math.sqrt(half + dev) + spacing;
    const b = 2 * Math.sqrt(Math.max(0, half - dev)) + spacing;
    const deg = (Math.atan2(2 * sxy, sxx - syy) * 90) / Math.PI;
    return (
      <g className="tt-del">
        <ellipse className="tt-area" cx={mx} cy={my} rx={a} ry={b} transform={`rotate(${deg} ${mx} ${my})`} />
        <ellipse className="tt-halo" cx={mx} cy={my} rx={a} ry={b} transform={`rotate(${deg} ${mx} ${my})`} vectorEffect="non-scaling-stroke" />
        <ellipse className="tt-line" cx={mx} cy={my} rx={a} ry={b} transform={`rotate(${deg} ${mx} ${my})`} vectorEffect="non-scaling-stroke" />
      </g>
    );
  }
  const d = hit.rivers
    .map((k) => {
      const p = world.rivers[k].pts;
      const pts: number[] = [];
      for (let j = 0; j < p.length; j += 3) pts.push(near0(p[j], j ? pts[pts.length - 2] : x0), p[j + 1]);
      return pathOf(pts);
    })
    .join('');
  return (
    <g className="tt-del">
      <path className="tt-halo" d={d} vectorEffect="non-scaling-stroke" />
      <path className="tt-line" d={d} vectorEffect="non-scaling-stroke" />
    </g>
  );
}

/**
 * 地图上的覆盖层:开着编辑地形时画出草图(各支笔各自的颜色,半透明;擦掉的地方把之前涂的挖掉)、放的火山湖河、
 * 正在画的那一笔(圈起来填满:虚线圈 + 连回起点的点线)、跟着鼠标的大小圈;"在地图上显示草图"关掉时只留正在画的和光标圈。
 * shown / shownSketch = 地图上现在这个世界是带着哪些地形修改、哪份草图生成的(之后加的、还在重新生成的那几笔闪着)。
 * 画好的草图和放的几处只在它们变了时重排(拖动时只动正在画的那一笔和光标)
 */
export function TerrainOverlay({
  width,
  height,
  shown,
  shownSketch,
  wrap = 0,
  scale = 1,
}: {
  width: number;
  height: number;
  shown: readonly TerrainOp[];
  shownSketch?: SketchEdit;
  wrap?: number;
  /** 屏幕上一个世界单位多少像素(导入图片时序号、小方块按屏幕大小画) */
  scale?: number;
}) {
  const uid = useId().replace(/[^a-zA-Z0-9_-]/g, '');
  overlayK = scale;
  const t = useTerrainTool();
  const edits = useEdits();
  const dr = useDraft();
  const importing = !!useImport();
  const img = edits.sketch?.image;
  const shownImg = shownSketch?.image;
  const ops = edits.terrain;
  const strokes = edits.sketch?.strokes ?? NO_STROKES;
  const shownStrokes = shownSketch?.strokes ?? NO_STROKES;
  const erasePts = t.on && dr.draft && t.tool === 'erase' && t.method === 'paint' ? dr.draft : null;
  const layer = useMemo(() => {
    if (!t.on || (!t.show && !erasePts)) return { masks: [], body: [] };
    // 从第几笔开始地图上还没有(按先后比;撤销的不算)
    let sameS = 0;
    while (sameS < strokes.length && sameS < shownStrokes.length && sameStroke(strokes[sameS], shownStrokes[sameS])) sameS++;
    const image = t.show && img ? { img, pending: !shownImg || shownImg.cells !== img.cells || (shownImg.at ?? 0) !== (img.at ?? 0) } : null;
    return sketchLayer(t.show ? strokes : NO_STROKES, sameS, image, erasePts && { kind: 'erase', r: t.r, pts: erasePts }, uid, width, height, wrap);
  }, [t.on, t.show, t.r, strokes, shownStrokes, img, shownImg, erasePts, uid, width, height, wrap]);
  // 正在擦的这一笔碰到了哪几处(涂抹、圈起来都算;圈的时候按连上起点的圈算)
  const erasing = t.on && dr.draft && t.tool === 'erase' ? dr.draft : null;
  const doomed = useMemo(
    () => (erasing ? erasedOps(ops, { kind: 'erase', r: t.r, pts: erasing, ...(t.method === 'lasso' && erasing.length >= 6 ? { fill: 1 as const } : {}) }) : NO_HIT),
    [erasing, ops, t.r, t.method],
  );
  const opMarks = useMemo(() => {
    if (!t.on || (!t.show && !doomed.length)) return null;
    let same = 0;
    while (same < ops.length && same < shown.length && sameTerrain([ops[same]], [shown[same]])) same++;
    // 高度笔涂完地图上本身就看得出来:只画还在重新生成的那几笔
    return ops.map((op, i) =>
      (t.show || doomed.includes(i)) && op.kind !== 'delWater' && !(isHeightKind(op.kind) && i < same) ? <OpMark key={i} op={{ ...op, pts: disp(op.pts, wrap) }} pending={i >= same} doomed={doomed.includes(i)} /> : null,
    );
  }, [t.on, t.show, ops, shown, wrap, doomed]);
  if (!t.on) return null;
  if (importing)
    return (
      <svg className="terrain-overlay" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" aria-hidden="true">
        <g id={uid} className="terrain-marks">
          <ImportLayer width={width} height={height} scale={scale} />
        </g>
        {!!wrap && [-wrap, wrap, 2 * wrap].map((dx) => <use key={dx} href={`#${uid}`} x={dx} />)}
      </svg>
    );
  const r = radiusOf(t);
  const pat = `${uid}-isles`;
  const heightPen = isHeightTool(t.tool);
  // 抬高 / 压低:光标圈里一个箭头(按着 Alt 反过来);1 朝上,−1 朝下
  const up = t.tool === 'lift' ? 1 : t.tool === 'lower' ? -1 : 0;
  const arrow = (dr.draft ? draftAlt : dr.alt) ? -up : up;
  // 删河湖:指着的湖 / 河
  const del = t.tool === 'delWater' && dr.cursor ? waterAt(dr.cursor[0], dr.cursor[1]) : null;
  const tip = del ? `点一下删掉这${'lake' in del ? '个湖' : '条河'}` : dr.cursor ? heightTip(t, dr, arrow) : null;

  const platePage = isPlateTool(t.tool);
  // 板块页:选中(合并先点)的那块板块的箭头变白;选中的能拖,拖的时候箭头跟着手,读数写新的漂移
  let plateMark: ReactNode = null;
  const picked = platePage && t.tool !== 'plateCut' ? pickedArrow(t) : null;
  if (picked) {
    const { a } = picked;
    const tip = t.tool === 'plateSelect' && dr.tip ? dr.tip : null;
    const [x1, y1] = tip ?? pickedTip(a);
    const drag = tip && dragDrift(a, tip);
    const text = t.tool !== 'plateSelect' ? null : drag ? driftText(drag.dir, drag.speed) : arrowText(a);
    plateMark = <PlateArrowMark x0={a.x} y0={a.y} x1={x1} y1={y1} handle={t.tool === 'plateSelect'} text={text} scale={scale} />;
  }

  let draftMark: ReactNode = null;
  if (dr.draft) {
    const pts = dr.draft;
    if (t.tool === 'plateCut') {
      const n = pts.length;
      const end = dr.cursor ? [near(dr.cursor[0], pts[n - 2]), dr.cursor[1]] : [pts[n - 2], pts[n - 1]];
      const d = `${pathOf(pts)}L${end[0]} ${end[1]}`;
      draftMark = (
        <g className="tt-cut">
          <path className="tt-cut-halo" d={d} vectorEffect="non-scaling-stroke" />
          <path className="tt-cut-line" d={d} vectorEffect="non-scaling-stroke" />
          <circle className="tt-cut-end" cx={end[0]} cy={end[1]} r={5 / scale} />
          <HeightTip x={end[0] + 14 / scale} y={end[1]} text="松手切开" scale={scale} />
        </g>
      );
    } else if (t.tool === 'river') draftMark = <OpMark op={{ kind: 'river', pts, r, s: 1 }} pending />;
    else if (isHeightTool(t.tool)) draftMark = <OpMark op={{ kind: t.tool, pts, r, s: 1 }} pending />;
    else if (isClimateTool(t.tool) && t.method !== 'lasso') draftMark = <OpMark op={{ kind: t.tool, pts, r, s: 1 }} pending />;
    else if (!isPlaceTool(t.tool) && t.method === 'lasso') {
      const n = pts.length;
      draftMark = (
        <g className={`sk-lasso k-${t.tool}`}>
          <path className="sk-lasso-area" d={`${pathOf(pts)}Z`} vectorEffect="non-scaling-stroke" />
          {n >= 4 && <path className="sk-lasso-close" d={`M${pts[n - 2]} ${pts[n - 1]}L${pts[0]} ${pts[1]}`} vectorEffect="non-scaling-stroke" />}
        </g>
      );
    } else if (!isPlaceTool(t.tool) && t.tool !== 'erase') {
      const s: SketchStroke = { kind: t.tool as SketchKind, r: t.r, pts };
      draftMark = <StrokeMark s={s} pending pat={pat} />;
    }
  }

  return (
    <svg className="terrain-overlay" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <pattern id={pat} patternUnits="userSpaceOnUse" width="22" height="22" fill="rgba(150, 225, 110, 0.85)">
          <circle cx="5" cy="6" r="3.4" />
          <circle cx="15" cy="4" r="2.2" />
          <circle cx="13" cy="15" r="3.8" />
          <circle cx="3" cy="17" r="1.8" />
        </pattern>
        {layer.masks}
      </defs>
      <g id={uid} className="terrain-marks">
        {layer.body}
        {opMarks}
        {plateMark}
        {draftMark}
        {del && dr.cursor && <WaterMark hit={del} x0={dr.cursor[0]} />}
        {dr.cursor && t.tool !== 'delWater' && !platePage && (!dr.draft || heightPen) && (
          <g className={`tt-cursor${heightPen ? ' k-height' : ''}${arrow ? ' k-arrow' : ''}${dr.draft ? ' on' : ''}`}>
            <circle className="tt-halo" cx={dr.cursor[0]} cy={dr.cursor[1]} r={r} vectorEffect="non-scaling-stroke" />
            <circle className="tt-line" cx={dr.cursor[0]} cy={dr.cursor[1]} r={r} vectorEffect="non-scaling-stroke" />
            {arrow !== 0 && <path className="tt-arrow" d={arrowPath(dr.cursor[0], dr.cursor[1], arrow, scale)} vectorEffect="non-scaling-stroke" />}
          </g>
        )}
        {/* 删河湖的提示在指针右下(不挡住描红的那条),别的读数在光标圈右边 */}
        {dr.cursor && tip && <HeightTip x={dr.cursor[0] + (del ? 16 / scale : r + 9 / scale)} y={dr.cursor[1] + (del ? 22 / scale : 0)} text={tip} scale={scale} />}
      </g>
      {/* 左右各挪一圈再画几份(主图右边还接着一份;跨 180° 经线的线两边都看得到) */}
      {!!wrap && [-wrap, wrap, 2 * wrap].map((dx) => <use key={dx} href={`#${uid}`} x={dx} />)}
    </svg>
  );
}
