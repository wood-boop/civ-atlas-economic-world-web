/**
 * 左边的侧栏(宽屏):界面的主体都在这里,地图在它右边。样子照常见的地图应用。
 *
 *   顶上   "‹ 我的世界";世界名、"种子 7，现存 14 国";存档、更多(写成史书、AI 设置、关于);下面一个搜索框
 *          (用一句话改世界、问问题在右上「助手」打开的助手面板里,见 Assistant.tsx)
 *   下面   三选一 ——
 *          搜索框里有字:搜索结果(点一条 = 选中它,地图飞过去)
 *          地图上选中了东西:它的详情(Inspector:国家 / 城 / 地理实体 / 州的面板);打开了地形大事:它的卡片(UpheavalPanel.tsx)
 *          什么都没选:整个世界(WorldHome:大纲(OutlineSide.tsx;逐年推演里不放)、信仰(只在信仰图层)、国家按大小排、民族按大小排、最近大事、我的干预(干预和地形大事)、
 *          这颗星球(从这里演绎(逐年推演,从时间轴停的这一年起)、回放世界形成、地形大事、在这张地图上打造新文明、世界设定;
 *          从别人的分享另存来的,最后一行是底稿出处,点了在新标签页打开那个分享链接))。
 *          在逐年推演里:副标写"逐年推演,从某某年起演绎"(演一国时"逐年推演,演某国"),"这颗星球"换成"这个故事"(推进设置、存回推演模式,见 Stepwise.tsx)
 * 收起:卡片右上角的侧栏图标 → 卡片往左滑走,左上角留一个小按钮(侧栏图标 + 世界名),点它滑回来;记在浏览器里(sideStore.ts)。
 *       收起时选中了东西,卡片弹出来显示它,取消选中又收回去;收起时搜索框跟着卡片一起收起。
 * 新建世界是另一套界面(studio/Studio.tsx),不用侧栏。
 *
 * 窄屏(手机)不用这个侧栏:同样的内容放进底部的世界卡片(PhoneSheet.tsx),这里的零件(搜索、世界名、"更多"菜单、整个世界)两边共用。
 */
import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import type { Civ } from '../gen/civ/types';
import type { Raster } from '../gen/raster';
import type { World, WorldParams } from '../gen/world';
import { capitalAt, polityAlive, polityName } from '../gen/civ/growth';
import { KIND_INFO, cultureLabel } from '../gen/civ/display';
import { ownersAt, type Owners } from '../gen/civ/timeline';
import { filterChronicle } from '../gen/civ/chronicle';
import { faithRows, fullChronicle } from '../gen/civ/religionText';
import { getCivTime, pickChronicleEntry, setResourceView, setSelection, subscribeCivTime, useCivShow, useResourceView, useSelection } from './civView';
import { controlRows, eraRows, resourceRows } from './devRows';
import { useEdits } from './editsStore';
import { eraLabel, spaced, yearAt, yearFull, yearShort, type Era } from '../gen/era';
import { playFromOf } from '../gen/edits';
import { openStepDialog, useStepwiseOn } from './stepwiseStore';
import { StepSideGroup } from './Stepwise';
import { StepBranches } from './StepBranches';
import { openUpheaval, useUpUi } from './upheavalStore';
import { currentWorld, listWorlds, useSavesVersion } from './saveStore';
import { mapMates } from './mapGroups';
import { startNewCiv } from './newCivAction';
import { SaveMenu } from './SaveMenu';
import { openAiSettings } from './AiSettings';
import { openHistoryBook } from './bookStore';
import { openOverview } from './overviewStore';
import { cultureRegion, searchCiv, searchMarks, type SearchHit } from './searchIndex';
import { cultureAlive } from './WorldOverviewCultures';
import { countUpTo } from './timelineLayout';
import { Icon } from './icons';
import { AiMenuItem, AiSettingsItem, MenuItem, MenuSep, PopMenu } from './PopMenu';
import { GUIDE_URL, PRIVACY_URL, SOURCE_URL, TERMS_URL } from './links';
import { ContactMenuItem } from './ContactLink';
import { VersionMenuFoot } from './VersionNews';
import { PlayQualityItem } from './PlayQualityMenu';
import { useCoarse, useNarrow } from './device';
import { CONTROL_COLORS } from '../render/civ/control';
import { keyLabel } from './shortcuts';
import { openShortcuts } from './ShortcutsDialog';
import { openDiag } from './DiagDialog';
import { EntryText, jumpTo, rgb } from './panelParts';
import { collapseSide, expandSide, useSide } from './sideStore';
import { PolityFlag } from './Flag';
import { useRole } from './roleStore';
import { rolePolity } from './policyInfo';
import { nameAt } from './Interventions';
import { OutlineSide } from './OutlineSide';
import { FoundSide } from './FoundSide';
import { interventionRows } from './outlineInfo';
import './sidebar.css';

export interface SidebarProps {
  data: { world: World; raster: Raster } | null;
  /** 套上改名的历史(界面上显示的那一份) */
  civ: Civ | null;
  /** 没套改名的历史 */
  raw: Civ | null;
  params: WorldParams;
  /** 世界还在生成 */
  generating: boolean;
  /** 回放世界形成:能不能点、正在放 */
  replay: { on: boolean; ready: boolean };
  onReplay: () => void;
  /** 回到"我的世界" */
  onHome: () => void;
  /** 返回那一处写什么(不给 = "我的世界";从作品墙打开的作品是"作品墙",onHome 回作品墙) */
  homeLabel?: string;
  /** 详情面板放进来的空位(面板只挂一份,由 App 挪到这里;见 App 的 inspectorHost) */
  inspectorSlot: (el: HTMLElement | null) => void;
}

const subscribeYear = (f: () => void) => subscribeCivTime(() => f());

/** 时间轴当前年份(取整;播放时一年只重新渲染一次) */
function useYear(civ: Civ | null): number {
  const end = civ?.endYear ?? 0;
  return useSyncExternalStore(subscribeYear, () => Math.floor(Math.min(end, Math.max(0, getCivTime().year ?? end))));
}

const stop = (e: { stopPropagation(): void }) => e.stopPropagation();

export function Sidebar(p: SidebarProps) {
  const { sel } = useSelection();
  const up = useUpUi().on;
  const s = useSearch(p.civ);
  const side = useSide();
  /** 收起了(弹出来显示选中的东西时不算):卡片滑到左边外面,换成左上角的小按钮 */
  const hidden = side.collapsed && !side.peek;
  return (
    <>
      <aside
        className={`sidebar${hidden ? ' side-hidden' : ''}`}
        aria-label="侧栏"
        aria-hidden={hidden || undefined}
        ref={(el) => el?.toggleAttribute('inert', hidden)}
        onPointerDown={stop}
        onDoubleClick={stop}
        onClick={stop}
      >
        <header className="sb-head">
          <BackHome onClick={p.onHome} label={p.homeLabel} />
          <button className="sb-collapse" data-act="side-collapse" aria-label="收起侧栏" data-tip="收起侧栏" data-tip-key="side" data-tip-side="left" onClick={collapseSide}>
            <Icon name="sidebar" size={19} />
          </button>
          <WorldHead {...p} />
          <SearchField s={s} />
        </header>
        <div className="sb-body">
          {s.searching ? (
            <SearchResults q={s.q} hits={s.hits} active={s.active} onActive={s.setActive} onPick={s.pick} />
          ) : (sel || up) && p.civ && p.raw && p.data ? (
            <div className="inspector-slot" ref={p.inspectorSlot} />
          ) : (
            <WorldHome {...p} />
          )}
        </div>
      </aside>
      {hidden && <SideOpen civ={p.civ} data={p.data} />}
    </>
  );
}

/** 卡片收起后左上角的小按钮:侧栏图标 + 世界名,点它卡片滑回来 */
function SideOpen({ civ, data }: Pick<SidebarProps, 'civ' | 'data'>) {
  const { title } = useWorldInfo(civ, data);
  return (
    <button className="side-open glass" data-act="side-expand" aria-label={`展开侧栏:${title}`} onPointerDown={stop} onDoubleClick={stop} onClick={expandSide}>
      <Icon name="sidebar" size={19} />
      <span className="side-open-name">{title}</span>
    </button>
  );
}

// ---------------------------------------------------------------------------
// 搜索框(宽屏侧栏、手机的世界卡片共用)

export interface SearchState {
  q: string;
  setQ: (q: string) => void;
  hits: SearchHit[];
  active: number;
  setActive: (i: number) => void;
  /** 点一条 / 回车:清空搜索框,选中它(地图飞过去) */
  pick: (h: SearchHit) => void;
  searching: boolean;
  /** 搜索框能不能用:有国家的世界;没有国家的世界放了标记、人物也能搜(只搜它们) */
  enabled: boolean;
}

export function useSearch(civ: Civ | null): SearchState {
  const { sel } = useSelection();
  const [q, setQ] = useState('');
  const [active, setActive] = useState(0);
  const { marks, characters, era } = useEdits();
  const civOk = !!civ && (civ.viable || !!marks?.length || !!characters?.length);
  // 年份取开始搜索那一刻的(播放时不跟着每一年重算)
  const searchYear = useMemo(() => (civ ? (getCivTime().year ?? civ.endYear) : 0), [civ, q === '']); // eslint-disable-line react-hooks/exhaustive-deps
  const hits = useMemo(
    () => (!civOk || !q.trim() ? [] : civ!.viable ? searchCiv(civ!, q, searchYear, undefined, marks, characters, era) : searchMarks(q, marks ?? [], undefined, characters ?? [], era)),
    [civOk, civ, q, searchYear, marks, characters, era],
  );
  useEffect(() => setActive(0), [q]);
  // 选中了别的东西(地图上点的):搜索框清空,下面换成它的详情
  useEffect(() => {
    if (sel) setQ('');
  }, [sel]);
  const pick = useCallback((h: SearchHit) => {
    setQ('');
    setSelection(h.select);
  }, []);
  return { q, setQ, hits, active, setActive, pick, searching: q.trim() !== '', enabled: civOk };
}

export function SearchField({ s, onFocus }: { s: SearchState; onFocus?: () => void }) {
  const { q, setQ, hits, active, setActive, pick } = s;
  return (
    <div className="sb-search">
      <Icon name="search" size={17} />
      <input
        className="search-input"
        data-act="search"
        value={q}
        placeholder="搜索国家、城市、人物、山河"
        spellCheck={false}
        autoComplete="off"
        disabled={!s.enabled}
        aria-label="搜索"
        onFocus={onFocus}
        onChange={(e) => setQ(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Escape') {
            e.stopPropagation();
            setQ('');
            (e.target as HTMLInputElement).blur();
          } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            const n = hits.length;
            if (n) setActive((active + (e.key === 'ArrowDown' ? 1 : n - 1)) % n);
          } else if (e.key === 'Enter' && hits[active]) {
            e.preventDefault();
            pick(hits[active]);
          }
        }}
      />
      {s.searching && (
        <button className="sb-clear" onClick={() => setQ('')} aria-label="清空" title="清空">
          <Icon name="close" size={12} />
        </button>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// 顶上:回到我的世界、世界名、存档、更多

/** 卡片左上"‹ 我的世界" */
export function BackHome({ onClick, label }: { onClick: () => void; label?: string }) {
  return (
    <button className="nw-back" data-act={label ? 'gallery-back' : 'home'} onClick={onClick}>
      <Icon name="back" size={18} />
      {label ?? '我的世界'}
    </button>
  );
}

/** 世界名、副标("种子 7,现存 14 国,干预了 2 处") */
export function useWorldInfo(civ: Civ | null, data: SidebarProps['data']): { title: string; sub: string; step: boolean } {
  useSavesVersion();
  const edits = useEdits();
  const year = useYear(civ);
  const step = useStepwiseOn();
  const alive = civ && civ.viable ? civ.polities.filter((x) => polityAlive(x, year)).length : 0;
  const n = interventionRows(edits.interventions);
  const seed = data ? data.world.params.seed : null;
  // 逐年推演:"逐年推演，从 2650 年起演绎";演一国时"逐年推演，演大澜王朝"(roleStore.ts)
  const role = useRole();
  const me = step && civ ? rolePolity(civ, role) : -1;
  const sub =
    seed === null
      ? '正在生成'
      : step
        ? me >= 0 && civ
          ? `逐年推演，演${nameAt(civ.polities[me], Math.min(civ.endYear, year))}`
          : `逐年推演，从${spaced(yearAt(playFromOf(edits), edits.era))}起演绎`
        : `种子 ${seed}，${civ ? (civ.viable ? `现存 ${alive} 国` : '没有文明') : '正在推演历史'}${n ? `，干预了 ${n} 处` : ''}`;
  return { title: currentWorld()?.title || '未命名世界', sub, step };
}

/** "更多"菜单:写成史书(「使用 AI 功能」关着时没有)、AI 设置、播放画面、键盘快捷键(有鼠标时)、问题记录、源代码和两份协议;最底下一行版本号 */
export function WorldMoreMenu({
  civ,
  onBook,
  className = 'sb-pill sb-more',
}: {
  civ: Civ | null;
  /** 点"写成史书"时先做的事(手机:世界卡片收起,写作进度在右上看得到) */
  onBook?: () => void;
  className?: string;
}) {
  // 键盘快捷键只在有鼠标的设备上列出(手机、平板没有键盘)
  const coarse = useCoarse();
  return (
    <PopMenu className={className} icon={<Icon name="more" size={17} />} title="更多" act="world-more" align="right">
      <AiMenuItem
        icon={<Icon name="book" size={16} />}
        act="book"
        disabled={!civ || !civ.viable}
        onClick={() => {
          onBook?.();
          openHistoryBook();
        }}
        note="AI"
      >
        把历史写成史书
      </AiMenuItem>
      <AiSettingsItem onClick={() => openAiSettings()} />
      <PlayQualityItem />
      <MenuSep />
      <MenuItem icon={<Icon name="help" size={16} />} href={GUIDE_URL} act="guide">
        使用教程
      </MenuItem>
      {!coarse && (
        <MenuItem icon={<Icon name="keyboard" size={16} />} act="shortcuts" kbd={keyLabel('help')} onClick={openShortcuts}>
          键盘快捷键
        </MenuItem>
      )}
      <MenuItem icon={<Icon name="log" size={16} />} act="diag" onClick={openDiag}>
        问题记录
      </MenuItem>
      <MenuItem icon={<Icon name="info" size={16} />} href={SOURCE_URL} act="source">
        源代码
      </MenuItem>
      <MenuItem href={PRIVACY_URL} act="privacy">
        隐私政策
      </MenuItem>
      <MenuItem href={TERMS_URL} act="terms">
        用户协议
      </MenuItem>
      <ContactMenuItem />
      <VersionMenuFoot />
    </PopMenu>
  );
}

function WorldHead(p: SidebarProps) {
  const { title, sub } = useWorldInfo(p.civ, p.data);
  return (
    <div className="sb-world">
      <button className="sb-title" data-act="overview" onClick={() => openOverview()} title="世界概览:国家、编年史、干预、世界参数">
        <b className="sb-name">{title}</b>
        <span className="sb-sub">{sub}</span>
      </button>
      <div className="sb-acts">
        <SaveMenu ready={!!p.data && !p.generating} icon={<Icon name="save" size={15} />} />
        <WorldMoreMenu civ={p.civ} />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 搜索结果

export function SearchResults({ q, hits, active, onActive, onPick }: { q: string; hits: SearchHit[]; active: number; onActive: (i: number) => void; onPick: (h: SearchHit) => void }) {
  if (!hits.length) return <div className="sb-empty search-empty">没有找到「{q.trim()}」</div>;
  return (
    <div className="sb-sec">
      <div className="sb-group search-list" role="listbox">
        {hits.map((h, i) => (
          <button
            key={`${h.kind}:${h.id}`}
            className={`sb-row search-row${i === active ? ' on' : ''}`}
            role="option"
            aria-selected={i === active}
            data-kind={h.kind}
            onPointerEnter={() => onActive(i)}
            onClick={() => onPick(h)}
          >
            {h.kind === 'polity' ? (
              <PolityFlag id={h.id} w={21} className="sb-flag" fallback={<i className="sb-sw" style={{ background: h.color }} />} />
            ) : (
              <i className="sb-sw" style={{ background: h.color }} />
            )}
            <span className="sb-row-main">
              <b className="search-name">{h.name}</b>
            </span>
            <span className="sb-row-side">{h.sub}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 什么都没选时:整个世界

/** 国家、民族一栏各列几个 */
const TOP_N = 5;
/** 最近大事列几条 */
const RECENT_N = 3;

let owners: Owners | undefined;

/** 物产图层的列表:十一样物产,点一行只看它(再点、点「全部显示」回到全部);开关「显示未发现的」 */
function ResourceList({ civ, year, era }: { civ: Civ; year: number; era?: Era | null }) {
  const view = useResourceView();
  const rows = useMemo(() => resourceRows(civ, year), [civ, year]);
  const focus = view.focus;
  return (
    <section className="sb-sec">
      <div className="sb-sec-head">
        <span>
          物产{focus === null && <small className="sb-sec-year">{yearFull(year, era)}</small>}
        </span>
        {focus !== null ? (
          <button className="sb-link" data-act="resources-all" onClick={() => setResourceView({ focus: null })}>
            全部显示
          </button>
        ) : (
          <button className={`sb-toggle${view.hidden ? ' on' : ''}`} role="switch" aria-checked={view.hidden} data-act="resources-hidden" onClick={() => setResourceView({ hidden: !view.hidden })}>
            <i aria-hidden="true" />
            显示未发现的
          </button>
        )}
      </div>
      <div className="sb-group sb-res" data-testid="resources">
        {rows.map((r) => (
          <button
            key={r.k}
            className={`sb-row two${r.found ? '' : ' off'}${focus === r.k ? ' on' : ''}`}
            data-resource={r.k}
            aria-pressed={focus === r.k}
            onClick={() => setResourceView({ focus: focus === r.k ? null : r.k })}
          >
            <em className="sb-badge" style={{ background: r.color }}>
              {r.glyph}
            </em>
            <span className="sb-row-main">
              <b>{r.name}</b>
              <small>{r.note}</small>
            </span>
            <span className="sb-row-side sb-res-n">
              {r.has} 州有
              <br />
              {r.found ? `${r.using} 州${r.verb}` : '都还没发现'}
            </span>
          </button>
        ))}
      </div>
      <p className="sb-note">圆章大小是这一年能用多少：矿要发现了才有，技术越高采得越多，采久了会空；林、渔、田、牧人多会吃空，人少了慢慢长回来。拖时间轴就能看到变化。</p>
    </section>
  );
}

/** 什么都没选时的整个世界:信仰(信仰图层)、国家按大小排、民族按大小排、最近大事、我的干预、这颗星球(宽屏侧栏、手机的世界卡片拉到顶时共用) */
export function WorldHome(p: Pick<SidebarProps, 'civ' | 'data' | 'params' | 'generating' | 'replay' | 'onReplay'>) {
  const { civ } = p;
  const year = useYear(civ);
  const edits = useEdits();
  const era = edits.era;
  const ok = !!civ && civ.viable;
  // 这张地图上已有几个文明(连同这个):只有存着的、建好了的世界才有这一行(存不进浏览器的不算:这里数出 0 个)
  const saves = useSavesVersion();
  const now = currentWorld();
  const curId = now?.kind === 'created' ? now.id : null;
  const mates = useMemo(() => (curId ? mapMates(listWorlds(), curId, { map: edits.map }).length : null), [saves, curId, edits.map]);
  // 现存的国家、民族按当年的州数排
  const { top, folks } = useMemo(() => {
    if (!ok) return { top: { list: [], alive: 0 }, folks: { list: [], alive: 0 } };
    owners = ownersAt(civ!, year, owners);
    const n = new Map<number, number>();
    const m = new Map<number, number>();
    for (let r = 0; r < civ!.regions.count; r++) {
      const q = owners.polity[r];
      if (q >= 0) n.set(q, (n.get(q) ?? 0) + 1);
      const c = owners.culture[r];
      if (c >= 0) m.set(c, (m.get(c) ?? 0) + 1);
    }
    const alive = civ!.polities.filter((x) => polityAlive(x, year));
    alive.sort((a, b) => (n.get(b.id) ?? 0) - (n.get(a.id) ?? 0));
    const cus = civ!.cultures.filter((x) => cultureAlive(x, year));
    cus.sort((a, b) => (m.get(b.id) ?? 0) - (m.get(a.id) ?? 0) || a.id - b.id);
    return {
      top: { list: alive.slice(0, TOP_N).map((x) => ({ p: x, n: n.get(x.id) ?? 0 })), alive: alive.length },
      folks: { list: cus.slice(0, TOP_N).map((x) => ({ cu: x, n: m.get(x.id) ?? 0 })), alive: cus.length },
    };
  }, [ok, civ, year]);
  // 一个国家都没有的年份(多半是早年各族还是部落):说一句,给出之后第一个立国的
  const next = useMemo(() => {
    if (!ok || top.alive) return null;
    let first: Civ['polities'][number] | null = null;
    for (const x of civ!.polities) if (x.founded > year && (!first || x.founded < first.founded)) first = x;
    return first;
  }, [ok, civ, year, top.alive]);
  const entries = useMemo(() => (ok ? filterChronicle(fullChronicle(civ!), { major: true }) : []), [ok, civ]);
  // 信仰图层:「国家」上面一组「信仰」(大教按信众多少,教派缩进跟在后面,最后一行民间信仰;数字是这一年的州数)
  const faithOn = useCivShow().faiths && ok && !!civ!.religion;
  const faiths = useMemo(() => (faithOn ? faithRows(civ!, year, era) : []), [faithOn, civ, year, era]);
  // 时代图层:「国家」上面一组「时代」;物产图层:换成「物产」一组(不列国家、最近大事)
  const show = useCivShow();
  const eraOn = show.eras && ok && !!civ!.development;
  const eras = useMemo(() => (eraOn ? eraRows(civ!, year, era) : []), [eraOn, civ, year, era]);
  // 管辖图层:「国家」上面一组「中央管辖」(四档各几州),再一组「现在的割据」(点一行跳过去)
  const narrow = useNarrow();
  const ctlOn = show.control && ok;
  const ctl = useMemo(() => (ctlOn ? controlRows(civ!, year, era, narrow) : null), [ctlOn, civ, year, era, narrow]);
  const resOn = show.resources && ok && !!civ!.development;
  const k = countUpTo(entries, year);
  const recent = entries.slice(Math.max(0, k - RECENT_N), k).reverse();
  // 我的干预:干预和地形大事一起数(概览"我的干预"页列在一起;照大纲硬改的一条情节算一处)
  const nUp = edits.upheavals?.length ?? 0;
  const nIv = interventionRows(edits.interventions) + nUp;
  const nTerrain = edits.terrain.length;
  // 逐年推演:「这颗星球」换成「这个故事」(推进设置、存回推演模式);干预都在「下一步生效的干预」单子里
  const step = useStepwiseOn();
  // 底稿出处:另存进"我的世界"以后才有(打开别人的分享、还只是看看时不显示;地图下的说明讲了是谁的)
  useSavesVersion();
  const cur = currentWorld();
  const origin = cur && cur.kind !== 'visit' && cur.kind !== 'draft' ? cur.origin : undefined;
  return (
    <div className="sb-home">
      {faiths.length > 0 && (
        <section className="sb-sec">
          <div className="sb-sec-head">
            <span>信仰</span>
          </div>
          <div className="sb-group" data-testid="faiths">
            {faiths.map((f) =>
              f.id < 0 ? (
                <div key="folk" className="sb-row two static">
                  <i className="sb-sw" style={{ background: rgb(f.color) }} />
                  <span className="sb-row-main">
                    <b>{f.name}</b>
                    <small>{f.sub}</small>
                  </span>
                  <span className="sb-row-side">{f.n} 州</span>
                </div>
              ) : (
                <button key={f.id} className={`sb-row${f.sect ? ' sect' : ' two'}`} data-faith={f.id} onClick={() => setSelection({ kind: 'faith', id: f.id })}>
                  <i className="sb-sw" style={{ background: rgb(f.color) }} />
                  <span className="sb-row-main">
                    <b>{f.name}</b>
                    {!f.sect && <small>{f.sub}</small>}
                  </span>
                  <span className="sb-row-side">{f.n} 州</span>
                </button>
              ),
            )}
          </div>
        </section>
      )}
      {eras.length > 0 && (
        <section className="sb-sec">
          <div className="sb-sec-head">
            <span>时代</span>
          </div>
          <div className="sb-group" data-testid="eras">
            {eras.map((e) => (
              <div key={e.era} className="sb-row two static" data-era={e.era}>
                <i className="sb-sw" style={{ background: rgb(e.color) }} />
                <span className="sb-row-main">
                  <b>{e.name}</b>
                  {e.sub && <small>{e.sub}</small>}
                </span>
                <span className="sb-row-side">{e.n} 州</span>
              </div>
            ))}
          </div>
          <p className="sb-note">颜色是每州此刻所处的时代。拖时间轴看各地一步步往前走；悬停一州看它走了几成。</p>
        </section>
      )}
      {ctl && (
        <section className="sb-sec">
          <div className="sb-sec-head">
            <span>中央管辖</span>
          </div>
          <div className="sb-group" data-testid="control">
            {ctl.tiers.map((t) => (
              <div key={t.tier} className="sb-row two static" data-tier={t.tier}>
                <i className="sb-sw" style={{ background: rgb(t.color) }} />
                <span className="sb-row-main">
                  <b>{t.name}</b>
                  <small>{t.sub}</small>
                </span>
                <span className="sb-row-side">{t.n} 州</span>
              </div>
            ))}
          </div>
          {!narrow && <p className="sb-note">离国都越远、异族、刚打下来的地方越管不住；国都一带的行政越强，管得越远。割据的州国界照旧画在原国里。</p>}
        </section>
      )}
      {ctl && ctl.lords.length > 0 && (
        <section className="sb-sec">
          <div className="sb-sec-head">
            <span>现在的割据</span>
            <span>{ctl.lords.length} 处</span>
          </div>
          <div className="sb-group" data-testid="lords">
            {ctl.lords.map((w) => (
              <button key={w.region} className="sb-row two" data-region={w.region} onClick={() => setSelection({ kind: 'region', id: w.region })}>
                <i className="sb-sw" style={{ background: rgb(CONTROL_COLORS[3]) }} />
                <span className="sb-row-main">
                  <b>{w.name}</b>
                  <small>{w.sub}</small>
                </span>
                <span className="sb-row-side">{w.years} 年</span>
              </button>
            ))}
          </div>
        </section>
      )}
      {ok && !step && <FoundSide id={now?.id} />}
      {ok && !step && <OutlineSide civ={civ} era={era} />}
      {resOn && <ResourceList civ={civ!} year={year} era={era} />}
      {ok && !resOn && (
        <section className="sb-sec">
          <div className="sb-sec-head">
            <span>国家</span>
            {top.alive > 0 && (
              <button className="sb-link" data-act="all-countries" onClick={() => openOverview('countries')}>
                全部 {top.alive} 国
              </button>
            )}
          </div>
          <div className="sb-group">
            {!top.alive && (
              <div className="sb-empty sb-no-polity">
                {next ? (
                  <>
                    这一年还没有国家，各族还是部落。
                    <br />
                    第一个国家{polityName(next, next.founded)}在{spaced(yearAt(next.founded, era))}立国。
                    <div className="sb-no-polity-act">
                      {/* 立国在年中:往后取整到下一年,那一年列表里才有它(和别处"跳到 N 年"一样) */}
                      <button className="sb-link" data-act="first-polity" onClick={() => jumpTo(Math.ceil(next.founded))}>
                        跳到{spaced(yearAt(Math.ceil(next.founded), era))}
                      </button>
                    </div>
                  </>
                ) : (
                  '这一年没有国家。'
                )}
              </div>
            )}
            {top.list.map(({ p: x, n }) => {
              const cap = civ!.settlements[capitalAt(x, year)];
              return (
                <button key={x.id} className="sb-row two" data-polity={x.id} onClick={() => setSelection({ kind: 'polity', id: x.id })}>
                  <PolityFlag id={x.id} year={year} w={21} className="sb-flag" fallback={<i className="sb-sw" style={{ background: rgb(x.color) }} />} />
                  <span className="sb-row-main">
                    <b>{polityName(x, year)}</b>
                    <small>
                      {yearAt(x.founded, era)}立国{cap ? `，都${cap.name}` : ''}
                    </small>
                  </span>
                  <span className="sb-row-side">{n} 州</span>
                </button>
              );
            })}
          </div>
        </section>
      )}
      {ok && !resOn && folks.alive > 0 && (
        <section className="sb-sec">
          <div className="sb-sec-head">
            <span>民族</span>
            <button className="sb-link" data-act="all-cultures" onClick={() => openOverview('cultures')}>
              全部 {folks.alive} 族
            </button>
          </div>
          <div className="sb-group" data-testid="cultures">
            {folks.list.map(({ cu, n }) => {
              const parent = cu.parent !== undefined ? civ!.cultures[cu.parent] : undefined;
              return (
                <button
                  key={cu.id}
                  className="sb-row two"
                  data-culture={cu.id}
                  onClick={() => setSelection({ kind: 'region', id: cultureRegion(civ!, cu.id, year, ownersAt(civ!, year)) })}
                >
                  <i className="sb-sw as-flag" style={{ background: rgb(cu.color) }} />
                  <span className="sb-row-main">
                    <b>{cultureLabel(cu)}</b>
                    <small>
                      {KIND_INFO[cu.kind].name}民族，{yearAt(cu.born, era)}
                      {parent ? `从${cultureLabel(parent)}分出` : '出现'}
                    </small>
                  </span>
                  <span className="sb-row-side">{n} 州</span>
                </button>
              );
            })}
          </div>
        </section>
      )}
      {ok && !resOn && recent.length > 0 && (
        <section className="sb-sec">
          <div className="sb-sec-head">
            <span>最近大事</span>
            <button className="sb-link" data-act="chronicle" onClick={() => openOverview('chronicle', { polity: null })}>
              编年史
            </button>
          </div>
          <div className="sb-group">
            {recent.map((e) => (
              <button key={e.id} className="sb-row ev" onClick={() => pickChronicleEntry(e)}>
                <span className={`sb-year${era ? ' era' : ''}`}>{yearShort(e.year, era)}</span>
                <span className="sb-ev-text">
                  <EntryText civ={civ!} e={e} />
                </span>
              </button>
            ))}
          </div>
        </section>
      )}
      {nIv > 0 && !step && (
        <section className="sb-sec">
          <div className="sb-group">
            <button className="sb-row" data-act="interventions" onClick={() => openOverview('interventions')}>
              <Icon name="intervene" size={17} className="sb-ico" />
              <span className="sb-row-main">我的干预</span>
              <span className="sb-row-side">{nIv} 处</span>
              <Icon name="chevron" size={14} className="sb-chev" />
            </button>
          </div>
        </section>
      )}
      {step ? (
        <>
          <StepSideGroup />
          <StepBranches civ={civ} />
        </>
      ) : (
        <section className="sb-sec">
          <div className="sb-sec-head">
            <span>这颗星球</span>
          </div>
          <div className="sb-group">
            {ok && (
              <button
                className="sb-row"
                data-act="step-from"
                disabled={!p.data || p.generating || p.replay.on}
                onClick={() => openStepDialog({ kind: 'start', year })}
                title="从时间轴现在停的这一年起，世界一步一步自己往下推"
              >
                <Icon name="book" size={17} className="sb-ico" />
                <span className="sb-row-main">
                  <b>从这里演绎</b>
                </span>
                <span className="sb-row-side">{yearFull(year, era)}</span>
                <Icon name="chevron" size={14} className="sb-chev" />
              </button>
            )}
            <button className="sb-row" data-act="replay" disabled={!p.data || p.generating || p.replay.on} onClick={p.onReplay}>
              <Icon name="replay" size={17} className="sb-ico" />
              <span className="sb-row-main">
                <b>{p.replay.on ? (p.replay.ready ? '正在回放' : '正在准备回放') : '回放世界形成'}</b>
              </span>
              <Icon name="chevron" size={14} className="sb-chev" />
            </button>
            {ok && (
              <button className="sb-row" data-act="upheaval" disabled={!p.data || p.generating || p.replay.on} onClick={openUpheaval} title="选一年让火山喷发、地震抬升、海水漫进来">
                <Icon name="terrain" size={17} className="sb-ico" />
                <span className="sb-row-main">
                  <b>地形大事</b>
                </span>
                <span className="sb-row-side">{nUp ? `${nUp} 件` : '还没有'}</span>
                <Icon name="chevron" size={14} className="sb-chev" />
              </button>
            )}
            {!!mates && (
              <button className="sb-row" data-act="side-new-civ" disabled={p.generating || p.replay.on} onClick={() => curId && startNewCiv(curId)} title="用这张地图一开始的样子，换一个文明种子从第 0 年推演">
                <Icon name="map" size={17} className="sb-ico" />
                <span className="sb-row-main">
                  <b>在这张地图上打造新文明</b>
                </span>
                <span className="sb-row-side">已有 {mates} 个</span>
                <Icon name="chevron" size={14} className="sb-chev" />
              </button>
            )}
            <button className="sb-row" data-act="genesis" onClick={() => openOverview('genesis')} title="创建时定下的种子、参数、地形，还有纪年">
              <Icon name="lock" size={17} className="sb-ico" />
              <span className="sb-row-main">
                <b>世界设定</b>
              </span>
              <span className="sb-row-side">
                种子 {p.params.seed}
                {nTerrain ? `，地形改过 ${nTerrain} 处` : ''}
                {era ? `，${eraLabel(era)}` : ''}
              </span>
              <Icon name="chevron" size={14} className="sb-chev" />
            </button>
            {origin && (
              <a className="sb-row" data-act="origin" href={origin.url} target="_blank" rel="noreferrer noopener" title={origin.gallery ? '打开作品墙上的这个作品' : '打开底稿的分享链接'}>
                <Icon name="link" size={17} className="sb-ico" />
                <span className="sb-row-main">
                  <b>底稿来自</b>
                </span>
                <span className="sb-row-side sb-origin">
                  {origin.by ? `${origin.by}的` : ''}「{origin.title || '未命名世界'}」
                </span>
                <Icon name="chevron" size={14} className="sb-chev" />
              </a>
            )}
          </div>
        </section>
      )}
    </div>
  );
}
