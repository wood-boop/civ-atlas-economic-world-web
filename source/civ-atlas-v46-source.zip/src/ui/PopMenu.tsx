/**
 * 点按钮弹出的小菜单(侧栏顶上的"更多"、面板里的"更多"):按钮 + 一列菜单项。
 * 点菜单项、点外面、按 Esc 收起。样式在 sidebar.css(.pm-*)。
 *
 * 菜单里的一项可以把整个菜单换成一张卡片(usePopMenuPanel;手机上点「测试版新功能」),收起菜单时换回来。
 * 菜单项挂在别处的小卡片(鼠标移上去在菜单旁边出的)带 data-pm-inside:在它上面点不算点外面,在它里面滚不算滚侧栏。
 */
import { createContext, useContext, useEffect, useLayoutEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { useAiOn, useAiStatus } from '../ai/client';
import { noteDismiss } from './dismissClick';
import { Icon } from './icons';

const PanelCtx = createContext<((card: ReactNode) => void) | null>(null);

/** 在菜单里:把整个菜单换成一张卡片(收起菜单时换回来);不在菜单里 = null */
export function usePopMenuPanel(): ((card: ReactNode) => void) | null {
  return useContext(PanelCtx);
}

export function PopMenu({
  label,
  icon,
  className,
  title,
  act,
  align = 'left',
  side,
  disabled,
  children,
}: {
  label?: ReactNode;
  icon?: ReactNode;
  /** 加在外层上(决定按钮长什么样:sb-pill / cp-tile……) */
  className?: string;
  title?: string;
  /** 按钮的 data-act */
  act?: string;
  /** 菜单和按钮左对齐还是右对齐 */
  align?: 'left' | 'right';
  /**
   * 按钮在宽屏的侧栏卡片里时,菜单弹到卡片右边、和按钮顶对齐(不盖住面板里的内容);
   * 不在侧栏里(手机的底部抽屉)照常挂在按钮下面
   */
  side?: boolean;
  disabled?: boolean;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const [at, setAt] = useState<CSSProperties | undefined>(undefined);
  const [panel, setPanel] = useState<ReactNode>(null);
  useEffect(() => {
    if (!open) setPanel(null);
  }, [open]);
  useLayoutEffect(() => {
    const card = side && open ? root.current?.closest('.sidebar') : null;
    if (!card || !root.current) return setAt(undefined);
    setAt({ position: 'fixed', left: card.getBoundingClientRect().right + 8, top: root.current.getBoundingClientRect().top, right: 'auto' });
  }, [open, side]);
  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (root.current?.contains(e.target as Node) || (e.target as Element).closest?.('[data-pm-inside]')) return;
      setOpen(false);
      noteDismiss(e);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      e.stopPropagation();
      setOpen(false);
    };
    // 弹到侧栏右边的菜单不跟着侧栏滚动:侧栏一滚就收起
    const onScroll = (e: Event) => {
      if (!at || (e.target instanceof Node && root.current?.contains(e.target))) return;
      if (e.target instanceof Element && e.target.closest('[data-pm-inside]')) return;
      setOpen(false);
    };
    document.addEventListener('pointerdown', onDown, true);
    window.addEventListener('keydown', onKey, true);
    window.addEventListener('scroll', onScroll, true);
    return () => {
      document.removeEventListener('pointerdown', onDown, true);
      window.removeEventListener('keydown', onKey, true);
      window.removeEventListener('scroll', onScroll, true);
    };
  }, [open, at]);
  return (
    <div className={`pm${className ? ` ${className}` : ''}${open ? ' open' : ''}`} ref={root}>
      <button
        className={`pm-btn${open ? ' on' : ''}`}
        data-act={act}
        aria-haspopup="menu"
        aria-expanded={open}
        title={title}
        disabled={disabled}
        onClick={() => setOpen((o) => !o)}
      >
        {icon}
        {label}
      </button>
      {open && (
        <div
          className={`pm-menu pm-${align}${at ? ' pm-side' : ''}${panel ? ' pm-panel' : ''}`}
          style={at}
          role="menu"
          onClick={(e) => {
            if ((e.target as HTMLElement).closest('.pm-item:not(:disabled)')) setOpen(false);
          }}
        >
          <PanelCtx.Provider value={setPanel}>{panel ?? children}</PanelCtx.Provider>
        </div>
      )}
    </div>
  );
}

/** 菜单里的一项:按钮,或者给了 href 就是新标签页打开的链接 */
export function MenuItem({
  icon,
  note,
  kbd,
  href,
  act,
  ain,
  disabled,
  onClick,
  children,
}: {
  icon?: ReactNode;
  /** 右边的灰色小字("需设置") */
  note?: ReactNode;
  /** 右边的快捷键(灰字,和菜单项一样大) */
  kbd?: string;
  href?: string;
  act?: string;
  /** 名字由来 / AI 起名(data-ain) */
  ain?: string;
  disabled?: boolean;
  onClick?: () => void;
  children: ReactNode;
}) {
  const body = (
    <>
      {icon}
      <span className="pm-text">{children}</span>
      {note && <small className="pm-note">{note}</small>}
      {kbd && <kbd className="pm-kbd">{kbd}</kbd>}
    </>
  );
  if (href)
    return (
      <a className="pm-item" role="menuitem" href={href} target="_blank" rel="noreferrer" data-link={act}>
        {body}
      </a>
    );
  return (
    <button className="pm-item" role="menuitem" data-act={act} data-ain={ain} disabled={disabled} onClick={onClick}>
      {body}
    </button>
  );
}

/** 要用 AI 的一项:还没设置 AI 时右边的小字是"需设置";「使用 AI 功能」关着时不显示 */
export function AiMenuItem(props: Parameters<typeof MenuItem>[0]) {
  const ai = useAiStatus();
  const on = useAiOn();
  if (!on) return null;
  return <MenuItem {...props} note={ai.ready ? props.note : '需设置'} />;
}

/** "AI 设置"那一项:「使用 AI 功能」关着时右边写"已关"(要再打开就从这里进) */
export function AiSettingsItem({ onClick }: { onClick: () => void }) {
  const on = useAiOn();
  return (
    <MenuItem icon={<Icon name="sparkle" size={16} />} act="ai-settings" note={on ? undefined : '已关'} onClick={onClick}>
      AI 设置
    </MenuItem>
  );
}

export function MenuSep() {
  return <hr className="pm-sep" />;
}
